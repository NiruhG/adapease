<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\CollegeModel;
use App\Models\CommentModel;
use App\Models\CorrectAnswersModel;
use CodeIgniter\HTTP\ResponseInterface;
use App\Models\CourseModel;
use App\Models\LibraryModel;
use App\Models\MaterialsModel;
use App\Models\OptionsModel;
use App\Models\QuestionsModel;
use App\Models\UseranswerModel;
use App\Models\UserModel;
use App\Models\VdriveModel;

class MainController extends BaseController
{
    public function index()
    {
        return view('/index');
    } 

    public function loginAs()
    {
        $data = [
            "title" => "Login as",
            "roles" => [
                [
                    "subTitle" => "Admin",
                    "description" => "Login as administrator to have full access privileges to manage the system and other user accounts.",
                    "image" => base_url('images/admin.png'),
                    "link" => base_url('admin/login')
                ],
                [
                    "subTitle" => "Instructors",
                    "description" => "Login as Instructor for access to the e-Library. Browse our vast collection of digital books, journals, and other resources.",
                    "image" => base_url('images/teacher.png'),
                    "link" => base_url('instructor/login')
                ],
                [
                    "subTitle" => "Student",
                    "description" => "Welcome back, students! Access your account to view assigned readings, submit coursework, and explore additional learning resources in the e-Library.",
                    "image" => base_url('images/student.png'),
                    "link" => base_url('student/login')
                ],
                [
                    "subTitle" => "Guest",
                    "description" => "Guests are welcome to browse a limited selection from our e-Library collection. Login in as a guest to sample our digital resources.",
                    "image" => base_url('images/guest.png'),
                    "link" => base_url('guest/login')
                ]
            ]
        ];
        return view('/loginAs', $data);
    }

    public function registerAs()
    {
        $data1 = [
            "title" => "Register as",
            "roles" => [
                [
                    "subTitle" => "Admin",
                    "description" => "Register as administrator to hall full access privileges to manage the system and other user accounts.",
                    "image" => base_url('images/admin.png'),
                    "link" => base_url('admin/register')
                ],
                [
                    "subTitle" => "Instructors",
                    "description" => "Register as Instructor for access to the e-Library. Browse our vast collection of digital books, journals, and other resources.",
                    "image" => base_url('images/teacher.png'),
                    "link" => base_url('instructor/register')
                ],
                [
                    "subTitle" => "Student",
                    "description" => "Register as students! Access your account to view assigned readings, submit coursework, and explore additional learning resources in the e-Library.",
                    "image" => base_url('images/student.png'),
                    "link" => base_url('student/register')
                ],
                [
                    "subTitle" => "Guest",
                    "description" => "Guests are welcome to browse a limited selection from our e-Library collection. Register as a guest to sample our digital resources.",
                    "image" => base_url('images/guest.png'),
                    "link" => base_url('guest/register')
                ]
            ]
          
        ];
        return view('/registerAs', $data1);
    }

    public function dashboard() {

        $user = session('user');
    
        if (!$user || $user['id'] < 1) {
            return redirect()->to('loginAs');
        } else {

            $role = $user['role'];

            $fetchCourse = new CourseModel();
            $fetchUser = new UserModel();
            $fetchMaterials = new MaterialsModel();
            $fetchLibrary = new LibraryModel();
            $fetchComment = new CommentModel();
            
            if($role == 'instructor'){
                $fetchData['materials'] = $fetchMaterials->where('created_by', $user['id'])->findAll();
            } else {
                $fetchData['materials'] = $fetchMaterials->findAll();
            }
            
            $materialCount = count($fetchData['materials']);

            $comment = $fetchComment->findAll();
            $collabCount = count($comment);

            $libraryCount = $fetchLibrary->where('user_id', $user['id'])->countAllResults();

            $courses = $fetchCourse->findAll();
            $courseCount = count($courses);

            $roles = ['instructor', 'student', 'guest'];

            $roleCounts = [];
            foreach ($roles as $roleName) {
                $roleCounts[$roleName] = $fetchUser->where('role', $roleName)->countAllResults();
            }

            $title = 'Guest Dashboard';
            $link = base_url('images/guest.png');

            switch ($role) {
                case 'admin':
                    $title = 'Admin Dashboard';
                    $link = base_url('images/admin.png');
                    break;
                case 'student':
                    $title = 'Student Dashboard';
                    $link = base_url('images/student.png');
                    break;
                case 'instructor':
                    $title = 'Instructor Dashboard';
                    $link = base_url('images/teacher.png');
                    break;
            }

            $profileLink = isset($user['profile']) && !empty($user['profile']) ? base_url('uploads/' . $user['profile']) : $link;

            $data = [
                'title' => $title,
                'role' => $role,
                'link' => $profileLink,
                'courseCount' => $courseCount,
                'guestCount' => $roleCounts['guest'],
                'instructorCount' => $roleCounts['instructor'],
                'studentCount' => $roleCounts['student'],
                'user' => $user,
                'materials' => $fetchData['materials'],
                'materialCount' => $materialCount,
                'libraryCount' => $libraryCount,
                'collabCount' => $collabCount
            ];

            return view("main/dashboard", $data);

        }
    }
    
    public function viewProfile(){
        $user = session('user');
        if (!$user || $user['id'] < 1) {
            return redirect()->to('loginAs');
        } else {

            $role = $user['role'];
            $title = 'Profile';
            $link = base_url('images/guest.png');

            switch ($role) {
                case 'admin':
                    $link = base_url('images/admin.png');
                    break;
                case 'student':
                    $link = base_url('images/student.png');
                    break;
                case 'instructor':
                    $link = base_url('images/teacher.png');
                    break;
            }

            $profileLink = isset($user['profile']) && !empty($user['profile']) ? base_url('uploads/' . $user['profile']) : $link;
            
            $data = [
                'title' => $title,
                'role' => $role,
                'link' => $profileLink,
                'user' => $user,
            ];

            return view("main/profile", $data);
        }
    }

    public function updateProfile($id) {
        $user = session('user');
        $updateProfile = new UserModel();
        $db = db_connect();
    
        if ($img = $this->request->getFile('userProfile')) {
            if ($img->isValid() && !$img->hasMoved()) {
                $imageName = $img->getRandomName();
                $img->move('uploads/', $imageName);
            }
        }
    
        if (!empty($_FILES['userProfile']['name'])) {
            $db->query("UPDATE user SET profile = '$imageName' WHERE id= '$id'");
        }
    

        $data = [
            'first_name' => $this->request->getPost('firstName'),
            'last_name' => $this->request->getPost('lastName'),
            'email' => $this->request->getPost('email'),
            'password' => password_hash($this->request->getPost('password'), PASSWORD_BCRYPT),
            'login_first' => '1'
        ];
    
        if ($updateProfile->update($id, $data)) {
            $updatedUserData = $updateProfile->find($id);
            session()->set('user', $updatedUserData);
            return $this->response->setJSON(['status' => 'success', 'message' => 'Profile updated successfully']);
        } else {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Failed to update profile']);
        }
    }
    

    public function saveToLibrary(){
        $user = session('user');
        $libraryModel = new LibraryModel();
    
        $materialId = $this->request->getPost('material_id');
    
       
        $existingEntry = $libraryModel->where('user_id', $user['id'])
                                      ->where('material_id', $materialId)
                                      ->first();
        
        if ($existingEntry) {
            return $this->response->setJSON(['status' => 'warning', 'message' => 'You have already saved this material to your Library.']);
        }
    
       
        $data = [
            'user_id' => $user['id'],
            'material_id' => $materialId,
        ];
    
        
        if ($libraryModel->insert($data)) {
            return $this->response->setJSON(['status' => 'success', 'message' => 'Saved to Library successfully']);
        } else {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Failed to save to Library.']);
        }
    }

    public function saveToVdrive(){
        $user = session('user');
        $virtualModel = new VdriveModel();
    
        $materialTitle = $this->request->getPost('material_title');
    
       
        $existingEntry = $virtualModel->where('user_id', $user['id'])
                                      ->where('title', $materialTitle)
                                      ->first();
        
        if ($existingEntry) {
            return $this->response->setJSON(['status' => 'warning', 'message' => 'You have already saved this material to your Virtual Drive.']);
        }
    
       
        $data = [
            'user_id' => $user['id'],
            'material_id' => $this->request->getPost('material_id'),
            'title' => $materialTitle,
            'author' => $this->request->getPost('material_author'),
            'subject' => $this->request->getPost('material_subject'),
            'course' => $this->request->getPost('material_course'),
            'file' => $this->request->getPost('material_file'),
            
        ];
    
        
        if ($virtualModel->insert($data)) {
            return $this->response->setJSON(['status' => 'success', 'message' => 'Saved to Virtual Drive successfully']);
        } else {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Failed to save to Virtual Drive.']);
        }
    }
    
    public function viewMaterialsDash($id){
        $user = session('user');
    
        if (!$user || $user['id'] < 1) {
            return redirect()->to('loginAs');
        } else {
            $role = $user['role'];

            $fetchMaterials = new MaterialsModel();
            $data['materials'] = $fetchMaterials->where('id', $id)->first();
            
            if ($role === 'student' || $role === 'admin' || $role === 'instructor') {
                return redirect()->to('/error')->with('error', 'Access denied: You do not have permission to view this page.');
            }

            $title = 'Instructional Materials';
            $link = base_url('images/guest.png');

            $profileLink = isset($user['profile']) && !empty($user['profile']) ? base_url('uploads/' . $user['profile']) : $link;

            $data = [
                'title' => $title,
                'role' => $role,
                'link' => $profileLink,
                'materials' => $data['materials'],
                'user' => $user,
            ];
            return view('main/dashboard/view', $data);
        }
    }

    public function search(){
            $user = session('user');
            $searchTitle = $this->request->getVar('search');
            $materialsModel = new MaterialsModel();
            $materials = $materialsModel->searchByTitle($searchTitle);
            $role = $user['role'];
            $title = 'Guest Dashboard';
            $link = base_url('images/guest.png');

            $profileLink = isset($user['profile']) && !empty($user['profile']) ? base_url('uploads/' . $user['profile']) : $link;
            
            return view('main/dashboard', [
                'materials' => $materials,
                'role' => $role,
                'title' => $title,
                'role' => $role,
                'link' => $profileLink,
                'user' => $user,
            ]);
    }

    public function searchFilter(){
        $user = session('user');
        $materialsModel = new MaterialsModel();
    
        $searchCollege = $this->request->getVar('college');
        $searchCourse = $this->request->getVar('course');
        $searchSubject = $this->request->getVar('subject');
    
        $materials = $materialsModel;
    
        if (!empty($searchCollege)) {
            $materials = $materials->like('college', $searchCollege);
        }
    
        if (!empty($searchCourse)) {
            $materials = $materials->like('course', $searchCourse);
        }

        if (!empty($searchSubject)) {
            $materials = $materials->like('subject', $searchSubject);
        }
    
        $materials = $materials->findAll();
    
        $role = $user['role'];
        $title = 'Instructional Materials';
        $link = base_url('images/admin.png');
        $fetchMaterials = new MaterialsModel();
        $fetchCourse = new CourseModel();
        $fetchCollege = new CollegeModel();
        $fetchData1['courses'] = $fetchCourse->select('course_name')->findAll();
        $fetchData2['college'] = $fetchCollege->select('name')->findAll();
        $fetchData3['subject'] = $fetchMaterials->select('subject')->findAll();
        $profileLink = isset($user['profile']) && !empty($user['profile']) ? base_url('uploads/' . $user['profile']) : $link;
    
        return view('main/materials', [
            'materials' => $materials,
            'role' => $role,
            'title' => $title,
            'link' => $profileLink,
            'user' => $user,
            'colleges' => $fetchData2['college'],
            'courses' => $fetchData1['courses'],
            'subjects' => $fetchData3['subject']
        ]);
    }
    
    public function search1(){
        $user = session('user');
        
        // Retrieve the search title from the GET request
        $searchTitle = $this->request->getGet('search'); 
    
        // Initialize the materials model
        $materialsModel = new MaterialsModel();
    
        // Call the search method in the model
        $materials = $materialsModel->searchByTitle($searchTitle);
    
        // Prepare data for the view
        $role = $user['role'];
        $title = 'Instructional Materials';
        $link = base_url('images/student.png');
        
        $profileLink = isset($user['profile']) && !empty($user['profile']) ? base_url('uploads/' . $user['profile']) : $link;

        // Fetch courses
        $fetchCourse = new CourseModel();
        $courses = $fetchCourse->select('course_name')->findAll();
    
        return view('main/materials', [
            'materials' => $materials, // materials matching the search
            'role' => $role,
            'title' => $title,
            'link' => $profileLink,
            'user' => $user,  
            'courses' => $courses,
        ]);
    }
    
    public function viewMaterialsContent($id) {
        $user = session('user');
    
        if (!$user || $user['id'] < 1) {
            return redirect()->to('loginAs');
        } else {
            $role = $user['role'];
    
            $fetchMaterials = new MaterialsModel();
            $material = $fetchMaterials->where('id', $id)->first();
    
            if (!$material) {
                return redirect()->to('/error')->with('error', 'Material not found.');
            }
    
            $fetchQuestions = new QuestionsModel();
            $fetchOptions = new OptionsModel();
            $fetchUserAnswers = new UseranswerModel(); 
    
            $questionsByMaterial = [];
            $optionsByQuestion = [];
        
            $questionsByMaterial[$material['id']] = $fetchQuestions->select('questions.*')
                ->where('materials_id', $material['id'])
                ->findAll();
    
          
            $questionIds = array_column($questionsByMaterial[$material['id']], 'id');
    
            if (!empty($questionIds)) {
              
                $options = $fetchOptions->select('options.*')
                    ->whereIn('question_id', $questionIds)
                    ->findAll();
    
                foreach ($options as $option) {
                    $optionsByQuestion[$option['question_id']][] = $option;
                }
            }
    

            $userAnswer = $fetchUserAnswers->where([
                'answer_by' => $user['id'],
                'materials_id' => $material['id']
            ])->first();
    
            $hasAnswered = !is_null($userAnswer); 
    
            if ($role === 'guest' || $role === 'admin' || $role === 'instructor') {
                return redirect()->to('/error')->with('error', 'Access denied: You do not have permission to view this page.');
            }
    
            $title = 'Instructional Materials';
            $link = base_url('images/student.png');
    
            $profileLink = isset($user['profile']) && !empty($user['profile']) ? base_url('uploads/' . $user['profile']) : $link;
    
            $data = [
                'title' => $title,
                'role' => $role,
                'link' => $profileLink,
                'material' => $material,
                'user' => $user,
                'questionsByMaterial' => $questionsByMaterial,
                'optionsByQuestion' => $optionsByQuestion,
                'hasAnswered' => $hasAnswered,
            ];
            return view('main/materials/content', $data);
        }
    }
    
    public function storeAssessment(){
        $user = session('user');
        $insertUserAnswer = new UseranswerModel();

        $data = array(
            'answer_by' => $user['id'],
            'materials_id' => $this->request->getPost('materials_id'),
            'answer1' => $this->request->getPost('answer1'),
            'answer2' => $this->request->getPost('answer2'),
            'answer3' => $this->request->getPost('answer3'),
        );

        if ($insertUserAnswer->insert($data)) {
            return $this->response->setJSON(['status' => 'success', 'message' => 'Assessment done']);
        } else {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Failed to finish assessment']);
        }
    }
    
    public function course(){
        $user = session('user');
    
        if (!$user || $user['id'] < 1) {
            return redirect()->to('loginAs');
        } else {

            $role = $user['role'];

            if ($role === 'student' || $role === 'guest') {
                return redirect()->to('/error')->with('error', 'Access denied: You do not have permission to view this page.');
            }

            // Get all course
            $fetchCourse = new CourseModel();
            $fetchData['course'] = $fetchCourse->findAll();
            
            $title = 'Course Management';
            $link = base_url('images/guest.png');

            if ($role === 'admin') { 
                $link = base_url('images/admin.png');
            }  
            if ($role === 'instructor') {
                $link = base_url('images/teacher.png');
            } 

            $profileLink = isset($user['profile']) && !empty($user['profile']) ? base_url('uploads/' . $user['profile']) : $link;

            $data = [
                'title' => $title,
                'role' => $role,
                'link' => $profileLink,
                'courses' => $fetchData['course'],
                'user' => $user,
            ];
            return view("main/course", $data);
        }
    }

    public function storeCourse() {
        $insertCourse = new CourseModel();
        $imageName = '';
    
        if ($img = $this->request->getFile('courseProfile')) {
            if ($img->isValid() && !$img->hasMoved()) {
                $imageName = $img->getRandomName();
                $img->move('uploads/', $imageName);
            }
        }
    
        $data = array(
            'profile' => $imageName,
            'course_name' => $this->request->getPost('courseName'),
            'course_abbre' => $this->request->getPost('courseAbbre'),
            'schedule' => $this->request->getPost('courseSchedule'),
            'description' => $this->request->getPost('courseDescription'),
        );
    
        if ($insertCourse->insert($data)) {
            return $this->response->setJSON(['status' => 'success', 'message' => 'Course added successfully']);
        } else {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Failed to add course']);
        }
    }

    public function editCourse($id){
        $user = session('user');
    
        if (!$user || $user['id'] < 1) {
            return redirect()->to('loginAs');
        } else {

            $role = $user['role'];

            if ($role === 'student' || $role === 'guest') {
                return redirect()->to('/error')->with('error', 'Access denied: You do not have permission to view this page.');
            }

            $fetchCourse = new CourseModel();
            $data['course'] = $fetchCourse->where('id', $id)->first();

            $title = 'Course Management';

            if ($role === 'admin') { 
                $link = base_url('images/admin.png');
            }  
            if ($role === 'instructor') {
                $link = base_url('images/teacher.png');
            }

            $profileLink = isset($user['profile']) && !empty($user['profile']) ? base_url('uploads/' . $user['profile']) : $link;

            $data = [
                'title' => $title,
                'role' => $role,
                'link' => $profileLink,
                'course' => $data['course'],
                'user' => $user,
            ];
            return view('main/course/edit', $data);
        }
    }

    public function viewCourse($id){
        $user = session('user');
    
        if (!$user || $user['id'] < 1) {
            return redirect()->to('loginAs');
        } else {
            $role = $user['role'];

            $fetchCourse = new CourseModel();
            $data['course'] = $fetchCourse->where('id', $id)->first();
            
            if ($role === 'student' || $role === 'guest') {
                return redirect()->to('/error')->with('error', 'Access denied: You do not have permission to view this page.');
            }

            $title = 'Course Management';
            $link = base_url('images/guest.png');

            if ($role === 'admin') { 
                $link = base_url('images/admin.png');
            }  
            if ($role === 'instructor') {
                $link = base_url('images/teacher.png');
            }

            $profileLink = isset($user['profile']) && !empty($user['profile']) ? base_url('uploads/' . $user['profile']) : $link;

            $data = [
                'title' => $title,
                'role' => $role,
                'link' => $profileLink,
                'course' => $data['course'],
                'user' => $user,
            ];
            return view('main/course/view', $data);
        }
    }

    public function updateCourse($id){
        $updateCourse = new CourseModel();
        $db = db_connect();
    
        if ($img = $this->request->getFile('courseProfile')) {
            if ($img->isValid() && !$img->hasMoved()) {
                $imageName = $img->getRandomName();
                $img->move('uploads/', $imageName);
            }
        }

        if(!empty($_FILES['courseProfile']['name'])){
            $db->query("UPDATE course SET profile = '$imageName' WHERE id= '$id'");
        }
    
        $data = array(
            'course_name' => $this->request->getPost('courseName'),
            'course_abbre' => $this->request->getPost('courseAbbre'),
            'schedule' => $this->request->getPost('courseSchedule'),
            'description' => $this->request->getPost('courseDescription'),
        );
    
        if ($updateCourse->update($id, $data)) {
            return $this->response->setJSON(['status' => 'success', 'message' => 'Course update successfully']);
        } else {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Failed to update course']);
        }
    }
    
    public function deleteCourse($id){
        $deleteCourse = new CourseModel();
        if ($deleteCourse->delete($id)) {
            return $this->response->setJSON(['status' => 'success', 'message' => 'Course deleted successfully']);
        } else {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Failed to delete course']);
        }
    }

    public function materials(){
        $user = session('user');
    
        if (!$user || $user['id'] < 1) {
            return redirect()->to('loginAs');
        } else {

            $role = $user['role'];

            if ($role === 'guest') {
                return redirect()->to('/error')->with('error', 'Access denied: You do not have permission to view this page.');
            }

            // Get all material
            $fetchMaterials = new MaterialsModel();
            $fetchCourse = new CourseModel();
            $fetchCollege = new CollegeModel();
            $fetchUser = new UserModel();
            
            $fetchData1['courses'] = $fetchCourse->select('course_name')->findAll();
            $fetchData2['college'] = $fetchCollege->select('name')->findAll();
            $fetchData3['subject'] = $fetchMaterials->select('subject')->findAll();
            $emails = array_column($fetchUser->where('role', 'student')->select('email')->findAll(), 'email');

            if ($role === 'admin') {
                $fetchData['materials'] = $fetchMaterials->findAll();
            } elseif ($role === 'instructor') {
                $fetchData['materials'] = $fetchMaterials->where('created_by', $user['id'])->findAll();
            } 
            elseif ($role === 'student') {
                $fetchData['materials'] = $fetchMaterials->where("CONCAT(',', emails, ',') LIKE '%," . $user['email'] . ",%'")->findAll();
            } 
            else {
                $fetchData['materials'] = [];
            }            
           
            $title = 'Instructional Materials';
            $link = base_url('images/guest.png');

            if ($role === 'admin') { 
                $link = base_url('images/admin.png');
            }  
            if ($role === 'instructor') {
                $link = base_url('images/teacher.png');
            } 
            if ($role === 'student') {
                $link = base_url('images/student.png');
            } 

            $profileLink = isset($user['profile']) && !empty($user['profile']) ? base_url('uploads/' . $user['profile']) : $link;

            $data = [
                'title' => $title,
                'role' => $role,
                'link' => $profileLink,
                'materials' => $fetchData['materials'],
                'courses' => $fetchData1['courses'],
                'colleges' => $fetchData2['college'],
                'subjects' => $fetchData3['subject'],
                'emails' => $emails,
                'user' => $user,
            ];
            return view("main/materials", $data);
        }
    }

    public function updateStudents($id){
        $insertEmails = new MaterialsModel();

        $data = array(
            'emails' => $this->request->getPost('emails'),
        );
    
        if ($insertEmails->update($id, $data)) {
            return $this->response->setJSON(['status' => 'success', 'message' => 'Add/Update Students successfully']);
        } else {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Failed to Add/Update Students']);
        }
    }

    public function storeMaterials() {
        $user = session('user');
        $insertMaterials = new MaterialsModel();
        $fileName = '';
    
        if ($file = $this->request->getFile('courseFile')) {
            if ($file->isValid() && !$file->hasMoved()) {
                $fileName = $file->getRandomName();
                $file->move('uploads/', $fileName);
            }
        }
        $data = array(
            'file' => $fileName,
            'title' => $this->request->getPost('title'),
            'author' => $this->request->getPost('author'),
            'subject' => $this->request->getPost('subject'),
            'course' => $this->request->getPost('course'),
            'college' => $this->request->getPost('college'),
            'created_by' => $user['id'],
            'status' => 0,
        );
        
        if ($insertMaterials->insert($data)) {
            return $this->response->setJSON(['status' => 'success', 'message' => 'Instructional Materials added successfully']);
        } else {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Failed to add instructional materials']);
        }
    }

    public function editMaterials($id){
        $user = session('user');
    
        if (!$user || $user['id'] < 1) {
            return redirect()->to('loginAs');
        } else {

            $role = $user['role'];

            if ($role === 'student' || $role === 'guest') {
                return redirect()->to('/error')->with('error', 'Access denied: You do not have permission to view this page.');
            }
            
            $fetchMaterials = new MaterialsModel();
            $data['materials'] = $fetchMaterials->where('id', $id)->first();
            $fetchCourse = new CourseModel();
            $fetchData1['courses'] = $fetchCourse->select('course_name')->findAll();
            $fetchCollege = new CollegeModel();
            $fetchData2['college'] = $fetchCollege->select('name')->findAll();

            $title = 'Instructional Materials';

            if ($role === 'admin') { 
                $link = base_url('images/admin.png');
            }  
            if ($role === 'instructor') {
                $link = base_url('images/teacher.png');
            }

            $profileLink = isset($user['profile']) && !empty($user['profile']) ? base_url('uploads/' . $user['profile']) : $link;
            $data = [
                'title' => $title,
                'role' => $role,
                'link' => $profileLink,
                'materials' => $data['materials'],
                'courses' => $fetchData1['courses'],
                'colleges' => $fetchData2['college'],
                'user' => $user,
            ];
            return view('main/materials/edit', $data);
        }
    }

    public function viewMaterials($id){
        $user = session('user');
    
        if (!$user || $user['id'] < 1) {
            return redirect()->to('loginAs');
        } else {
            $role = $user['role'];

            $fetchMaterials = new MaterialsModel();
            $data['materials'] = $fetchMaterials->where('id', $id)->first();
            
            if ($role === 'student' || $role === 'guest') {
                return redirect()->to('/error')->with('error', 'Access denied: You do not have permission to view this page.');
            }

            $title = 'Instructional Materials';
            $link = base_url('images/guest.png');

            if ($role === 'admin') { 
                $link = base_url('images/admin.png');
            }  
            if ($role === 'instructor') {
                $link = base_url('images/teacher.png');
            }

            $profileLink = isset($user['profile']) && !empty($user['profile']) ? base_url('uploads/' . $user['profile']) : $link;

            $data = [
                'title' => $title,
                'role' => $role,
                'link' => $profileLink,
                'materials' => $data['materials'],
                'user' => $user,
            ];
            return view('main/materials/view', $data);
        }
    }

    public function updateMaterials($id){
        $updateMaterials = new MaterialsModel();
        $db = db_connect();

        if ($file = $this->request->getFile('courseFile')) {
            if ($file->isValid() && !$file->hasMoved()) {
                $fileName = $file->getRandomName();
                $file->move('uploads/', $fileName);
            }
        }

        if(!empty($_FILES['courseFile']['name'])){
            $db->query("UPDATE course SET file = '$fileName' WHERE id= '$id'");
        }

        $data = array(
            'title' => $this->request->getPost('title'),
            'author' => $this->request->getPost('author'),
            'subject' => $this->request->getPost('subject'),
            'college' => $this->request->getPost('college'),
            'course' => $this->request->getPost('course'),
        );
    
        if ($updateMaterials->update($id, $data)) {
            return $this->response->setJSON(['status' => 'success', 'message' => 'Instructional Materials update successfully']);
        } else {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Failed to update instructional materials']);
        }
    }

    public function updateMaterialsStatus1($id){
        $materialsModel = new MaterialsModel();

        $data = [
            'status' => 1,
        ];

        if ($materialsModel->update($id, $data)) {
            return $this->response->setJSON([
                'status' => 'success', 
                'message' => 'Instructional materials approved successfully.'
            ]);
        } else {
            return $this->response->setJSON([
                'status' => 'error', 
                'message' => 'Failed to approve instructional materials.'
            ]);
        }
    }

    public function updateMaterialsStatus2($id){
        $materialsModel = new MaterialsModel();

        $data = [
            'status' => 2,
        ];

        if ($materialsModel->update($id, $data)) {
            return $this->response->setJSON([
                'status' => 'success', 
                'message' => 'Instructional materials archived successfully.'
            ]);
        } else {
            return $this->response->setJSON([
                'status' => 'error', 
                'message' => 'Failed to archive instructional materials.'
            ]);
        }
    }

    public function updateMaterialsCount($id) {
        $user = session('user');
        $userId = $user['id'];   
    
        $updateMaterials = new MaterialsModel();

        $material = $updateMaterials->find($id);
    
        if ($material) {

            if ($material['created_by'] !== $userId) { 
                $data = [
                    'view_count' => $material['view_count'] + 1
                ];
    
                if ($updateMaterials->update($id, $data)) {
                    return $this->response->setJSON(['status' => 'success', 'message' => 'View count updated successfully']);
                } else {
                    return $this->response->setJSON(['status' => 'error', 'message' => 'Failed to update view count']);
                }
            } else {
                return $this->response->setJSON(['status' => 'success', 'message' => 'View count not incremented for material created by the user']);
            }
        } else {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Material not found']);
        }
    }
 
    public function deleteMaterials($id){
        $deleteMaterials = new MaterialsModel();

        $item = $deleteMaterials->find($id);
        if (!$item) {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Item not found']);
        }

        $commentModel = new CommentModel();
        $commentModel->where('material_id', $id)->delete();

        $libraryModel = new LibraryModel(); 
        $libraryModel->where('material_id', $id)->delete();
        


        if ($deleteMaterials->delete($id)) {
            return $this->response->setJSON(['status' => 'success', 'message' => 'Instructional Materials deleted successfully']);
        } else {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Failed to delete instructional materials']);
        }
    }

    public function logout() {
        $this->session = \Config\Services::session();
        
        log_message('info', 'Logout method triggered.');
        session_destroy();
        return redirect()->to('loginAs');
    }
}
