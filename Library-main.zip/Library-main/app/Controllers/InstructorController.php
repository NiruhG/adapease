<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\CorrectAnswersModel;
use App\Models\InstructorModel;
use App\Models\MaterialsModel;
use App\Models\OptionsModel;
use App\Models\QuestionsModel;
use App\Models\UserModel;
use CodeIgniter\HTTP\ResponseInterface;

class InstructorController extends BaseController
{  
    public function register()
    {
        return view('instructor/register');
    }

    public function storeInstructor()
    {
        $insertInstructor = new UserModel();
        $role = 'instructor';
        $status = '0';
        $login_first = '1';

        $validation = \Config\Services::validation();
        
        $validation->setRules([
            'email' => 'required|valid_email',
            'password' => 'required|min_length[8]',
        ]);
    
        if (!$this->validate($validation->getRules())) {
            return $this->response
                        ->setJSON(['status' => 'error', 'message' => 'Invalid input data'])
                        ->setStatusCode(ResponseInterface::HTTP_BAD_REQUEST);
        }

        $data = array(
            'email' => $this->request->getPost('email'),
            'password' => password_hash($this->request->getPost('password'), PASSWORD_DEFAULT), 
            'role' => $role,
            'status' => $status,
        );
    
        if ($insertInstructor->insert($data)) {
            return $this->response
                        ->setJSON(['status' => 'success', 'message' => 'Instructor Registered successfully'])
                        ->setStatusCode(ResponseInterface::HTTP_OK);
        } else {
            return $this->response
                        ->setJSON(['status' => 'error', 'message' => 'Failed to register student'])
                        ->setStatusCode(ResponseInterface::HTTP_BAD_REQUEST);
        }
    }

    public function login()
    {
        return view('instructor/login');
    }

    function generateRandomString($length = 8) {
        $characters = 'abcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()_+-=<>?';
        $randomString = '';

        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[random_int(0, strlen($characters) - 1)];
        }

        return $randomString;
    }

    public function doLogin() {
        // Load the session service
        $this->session = \Config\Services::session();
        
        // Load the user model
        $login = new UserModel();

        // Get posted email and password
        $email = $this->request->getPost('email');
        $password = $this->request->getPost('password');

        $result = $login->where('email', $email)->first();

        if ($result && isset($result['id']) && $result['id'] > 0) {
            if ($result['role'] == "instructor" && $result['status'] == '0') {
                if (password_verify($password, $result['password'])) {
                    if ($result['login_first'] == '1') {
                        $randomString = $this->generateRandomString();
                        if ($login->update($result['id'], ['code' => $randomString])) {
                            log_message('info', 'Code updated successfully for user ID: ' . $result['id']);

                            // Send verification email with the generated code
                            if ($this->sendVerificationEmail($email, $randomString)) {
                                // Set session data and redirect to verification page
                                $this->session->set("user", $result);
                                return redirect()->to('instructor/verification');
                            } else {
                                return $this->response->setJSON(['status' => 'error', 'message' => 'Failed to send verification email']);
                            }
                        } else {
                            // Log failure if code update failed
                            log_message('error', 'Failed to update code for user ID: ' . $result['id']);
                            return $this->response->setJSON(['status' => 'error', 'message' => 'Failed to update user code']);
                        }
                    } else {
                        $this->session->set("user", $result);
                        return redirect()->to('/main/dashboard');
                    }
                } else {
                    return $this->response->setJSON(['status' => 'error', 'message' => 'Invalid password']);
                }
            } else {
                return $this->response->setJSON(['status' => 'error', 'message' => 'User is not an instructor or not eligible to login']);
            }
        } else {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Email not found']);
        }
    }

    public function sendVerificationEmail($email, $code) {
        // Load the email service
        $emailService = \Config\Services::email();

        // Set the sender details
        $emailService->setFrom('podongbacala@gmail.com', 'AdapEase');
        $emailService->setTo($email);
        $emailService->setSubject('Verification Code');

        // Compose the email content
        $message = "Your verification code is: " . $code;
        $emailService->setMessage($message);

        // Attempt to send the email
        if ($emailService->send()) {
            log_message('info', 'Verification email sent successfully to: ' . $email);
            return true;
        } else {
            // Log the error if email sending fails
            log_message('error', 'Failed to send email: ' . $emailService->printDebugger());
            return false;
        }
    }

    public function verify()
    {
        $user = session('user');
    
        if (!$user || $user['id'] < 1) {
            return redirect()->to('loginAs');
        } else {
            return view('instructor/verification');
        }
    }

    public function doVerify()
    {
       
        $user = session('user');
        
        $code = $this->request->getPost('code'); 
        
        if (!$user) {
            return redirect()->to('/login')->with('error', 'You must be logged in to verify your account.');
        }

        $userModel = new UserModel();
        
        $userData = $userModel->find($user['id']);

        if ($userData && $userData['code'] === $code) {
            $updatedLoginCount = $userData['login_count'] + 1;
            $userModel->update($user['id'], [
                'code' => null,
                'login_count' => $updatedLoginCount
            ]);

            session()->set('user', $user);
        
            return redirect()->to('/main/dashboard')->with('success', 'Email verified successfully!');
        } else {
            return redirect()->to('/verification')->with('error', 'Invalid verification code.');
        }
    }

    public function assessment()
    {
        $user = session('user');
        
        if (!$user || $user['id'] < 1) {
            return redirect()->to('loginAs');
        } else {
            $role = $user['role'];
    

            if ($role === 'guest' || $role === 'admin' || $role === 'student') {
                return redirect()->to('/error')->with('error', 'Access denied: You do not have permission to view this page.');
            }
    
            $fetchMaterials = new MaterialsModel();
            $fetchQuestions = new QuestionsModel();
            $fetchOptions = new OptionsModel();
            $fetchAnswer = new CorrectAnswersModel();
    
            
            // $fetchData['materials'] = $fetchMaterials->findAll();
            $fetchData['materials'] = $fetchMaterials->where('created_by', $user['id'])->findAll();
            $questionsByMaterial = [];
            $correctAnswersByQuestion = []; 
    
            
            foreach ($fetchData['materials'] as $material) {
                $questionsByMaterial[$material['id']] = $fetchQuestions->select('questions.*')
                    ->where('created_by', $user['id'])
                    ->where('materials_id', $material['id']) 
                    ->findAll();
            }
    
         
            $questionIds = array_column(array_merge(...array_values($questionsByMaterial)), 'id');
    
            $optionsByQuestion = [];
    
           
            if (!empty($questionIds)) {
                $options = $fetchOptions->select('options.*')
                    ->whereIn('question_id', $questionIds)
                    ->findAll();
    
                
                foreach ($options as $option) {
                    $optionsByQuestion[$option['question_id']][] = $option;
                }
    
                
                $correctAnswers = $fetchAnswer->whereIn('question_id', $questionIds)->findAll();
                
                foreach ($correctAnswers as $answer) {
                    $correctAnswersByQuestion[$answer['question_id']] = $answer;
                }
            }
    
            $title = 'Assessment Management';
            $link = base_url('images/teacher.png');
            $profileLink = isset($user['profile']) && !empty($user['profile']) ? base_url('uploads/' . $user['profile']) : $link;
    
          
            $data = [
                'title' => $title,
                'role' => $role,
                'link' => $profileLink,
                'user' => $user,
                'materials' => $fetchData['materials'],
                'questionsByMaterial' => $questionsByMaterial,
                'optionsByQuestion' => $optionsByQuestion,
                'correctAnswersByQuestion' => $correctAnswersByQuestion 
            ];
    
            return view("instructor/assessment", $data);
        }
    }
    
    public function storeAssessment()
    {
        $user = session('user');
        $material_id = $this->request->getPost('material_id');
        $questions = $this->request->getPost('question_text');
        $correct_options = $this->request->getPost('correct_option');
    
        $questionsModel = new QuestionsModel();
        $optionsModel = new OptionsModel();
        $correctAnswersModel = new CorrectAnswersModel();
    
        try {
            foreach ($questions as $index => $question_text) {
                // Insert the question into the questions table
                $question_id = $questionsModel->insert([
                    'materials_id' => $material_id,
                    'created_by' => $user['id'],
                    'question_text' => $question_text
                ]);
    
                if (!$question_id) {
                    throw new \Exception("Failed to insert question.");
                }
    
                // Get dynamically added options for this question
                $options = $this->request->getPost("option[{$index}]");
    
                if (empty($options)) {
                    throw new \Exception("No options provided for question {$index}.");
                }
    
                foreach ($options as $optIndex => $option_text) {
                    // Insert each option into the options table
                    $option_id = $optionsModel->insert([
                        'question_id' => $question_id,
                        'option_text' => $option_text
                    ]);
    
                    if (!$option_id) {
                        throw new \Exception("Failed to insert option: {$option_text}");
                    }
    
                    // Check if this option is the correct answer
                    if ($optIndex == $correct_options[$index]) {
                        $correctAnswersModel->insert([
                            'question_id' => $question_id,
                            'correct_option_id' => $option_id
                        ]);
                    }
                }
            }
    
            return $this->response->setJSON([
                'status' => 'success',
                'message' => 'Assessments added successfully'
            ]);
        } catch (\Exception $e) {
            return $this->response->setJSON([
                'status' => 'error',
                'message' => 'Failed to add assessments: ' . $e->getMessage()
            ], 500);
        }
    }
    

    public function deleteAssessment($id)
    {
        $questionsModel = new QuestionsModel();
        $optionsModel = new OptionsModel();
        $correctAnswersModel = new CorrectAnswersModel(); 
    
        try {
            $questions = $questionsModel->where('materials_id', $id)->findAll();
            
            
            if (!empty($questions)) {
                
                $questionIds = array_column($questions, 'id');
                
                
                $optionsModel->whereIn('question_id', $questionIds)->delete();
                
                
                $correctAnswersModel->whereIn('question_id', $questionIds)->delete();
                
                $questionsModel->where('materials_id', $id)->delete();
            }
            
            return $this->response->setJSON([
                'status' => 'success',
                'message' => 'Assessment deleted successfully'
            ]);
        } catch (\Exception $e) {
            return $this->response->setJSON([
                'status' => 'error',
                'message' => 'Failed to delete questions: ' . $e->getMessage()
            ], 500);
        }
    }
    
}