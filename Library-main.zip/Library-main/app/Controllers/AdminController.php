<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\AdminModel;
use App\Models\UserModel;
use CodeIgniter\HTTP\ResponseInterface;
use App\Controllers\InstructorController;

class AdminController extends BaseController
{
    public function register()
    {
        return view('admin/register');
    }
    
    public function storeAdmin()
    {
        $insertAdmin = new UserModel();
        $role = 'admin';
        $status = '0';
        $login_first = '1';

        $existingAdminCount = $insertAdmin->where('role', $role)->countAllResults();

        if ($existingAdminCount >= 1) {
            return $this->response
                        ->setJSON(['status' => 'error', 'message' => 'Only one admin can be registered'])
                        ->setStatusCode(ResponseInterface::HTTP_BAD_REQUEST);
        }

        $validation = \Config\Services::validation();
        
        $validation->setRules([
            'email' => 'required|valid_email',
            'password' => 'required|min_length[8]',
        ]);

        if (!$this->validate($validation->getRules())) {
            return $this->response
                        ->setJSON(['status' => 'error', 'message' => 'Invalid input data'])
                        ->setStatusCode(ResponseInterface::HTTP_BAD_REQUEST);
        }

        $data = array(
            'email' => $this->request->getPost('email'),
            'password' => password_hash($this->request->getPost('password'), PASSWORD_BCRYPT),
            'role' => $role,
            'status' => $status,
            'login_first' => $login_first
        );

        if ($insertAdmin->insert($data)) {
            return $this->response
                        ->setJSON(['status' => 'success', 'message' => 'Admin Registered successfully'])
                        ->setStatusCode(ResponseInterface::HTTP_OK);
        } else {
            return $this->response
                        ->setJSON(['status' => 'error', 'message' => 'Failed to register admin'])
                        ->setStatusCode(ResponseInterface::HTTP_BAD_REQUEST);
        }
    }

    public function login()
    {
        return view('admin/login');
    }

    function generateRandomString($length = 8) {
        $characters = 'abcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()_+-=<>?';
        $randomString = '';

        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[random_int(0, strlen($characters) - 1)];
        }

        return $randomString;
    }

    public function doLogin() {
        // Load the session service
        $this->session = \Config\Services::session();
        
        // Load the user model
        $login = new UserModel();

        // Get posted email and password
        $email = $this->request->getPost('email');
        $password = $this->request->getPost('password');

        $result = $login->where('email', $email)->first();

        if ($result && isset($result['id']) && $result['id'] > 0) {
            if ($result['role'] == "admin" && $result['status'] == '0') {
                if (password_verify($password, $result['password'])) {
                    if ($result['login_first'] == '1') {
                        $randomString = $this->generateRandomString();
                        if ($login->update($result['id'], ['code' => $randomString])) {
                            log_message('info', 'Code updated successfully for user ID: ' . $result['id']);

                            // Send verification email with the generated code
                            if ($this->sendVerificationEmail($email, $randomString)) {
                                // Set session data and redirect to verification page
                                $this->session->set("user", $result);
                                return redirect()->to('admin/verification');
                            } else {
                                return $this->response->setJSON(['status' => 'error', 'message' => 'Failed to send verification email']);
                            }
                        } else {
                            // Log failure if code update failed
                            log_message('error', 'Failed to update code for user ID: ' . $result['id']);
                            return $this->response->setJSON(['status' => 'error', 'message' => 'Failed to update user code']);
                        }
                    } else {
                        $this->session->set("user", $result);
                        return redirect()->to('/main/dashboard');
                    }
                } else {
                    return $this->response->setJSON(['status' => 'error', 'message' => 'Invalid password']);
                }
            } else {
                return $this->response->setJSON(['status' => 'error', 'message' => 'User is not an admin or not eligible to login']);
            }
        } else {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Email not found']);
        }
    }

    public function sendVerificationEmail($email, $code) {
        // Load the email service
        $emailService = \Config\Services::email();

        // Set the sender details
        $emailService->setFrom('podongbacala@gmail.com', 'AdapEase');
        $emailService->setTo($email);
        $emailService->setSubject('Verification Code');

        // Compose the email content
        $message = "Your verification code is: " . $code;
        $emailService->setMessage($message);

        // Attempt to send the email
        if ($emailService->send()) {
            log_message('info', 'Verification email sent successfully to: ' . $email);
            return true;
        } else {
            // Log the error if email sending fails
            log_message('error', 'Failed to send email: ' . $emailService->printDebugger());
            return false;
        }
    }

    public function verify()
    {
        $user = session('user');
    
        if (!$user || $user['id'] < 1) {
            return redirect()->to('loginAs');
        } else {
            return view('admin/verification');
        }
    }

    public function doVerify()
    {
       
        $user = session('user');
        
        $code = $this->request->getPost('code'); 
        
        if (!$user) {
            return redirect()->to('/login')->with('error', 'You must be logged in to verify your account.');
        }

        $userModel = new UserModel();
        
        $userData = $userModel->find($user['id']);

        if ($userData && $userData['code'] === $code) {
            $userModel->update($user['id'], [
                'code' => null,
                'login_first' => '0'
            ]);

            session()->set('user', $user);
        
            return redirect()->to('/main/dashboard')->with('success', 'Email verified successfully!');
        } else {
            return redirect()->to('/verification')->with('error', 'Invalid verification code.');
        }
    }

    public function accountManagement(){
        $user = session('user');
    
        if (!$user || $user['id'] < 1) {
            return redirect()->to('loginAs');
        } else {

            $role = $user['role'];

            if ($role === 'student' || $role === 'guest' || $role === 'instructor') {
                return redirect()->to('/error')->with('error', 'Access denied: You do not have permission to view this page.');
            }

            $fetchUser = new UserModel();
           
            $roles = ['instructor', 'student', 'guest'];

            $roleCounts = [];
            foreach ($roles as $roleName) {
                $roleCounts[$roleName] = $fetchUser->where('role', $roleName)->countAllResults();
            }

            $freq_user = $fetchUser->where('login_count >=', 3)->findAll();

            $title = 'Account Management';
            $link = base_url('images/admin.png');

            $profileLink = isset($user['profile']) && !empty($user['profile']) ? base_url('uploads/' . $user['profile']) : $link;

            $data = [
                'title' => $title,
                'role' => $role,
                'link' => $profileLink,
                'instructorCount' => $roleCounts['instructor'],
                'studentCount' => $roleCounts['student'],
                'guestCount' => $roleCounts['guest'],
                'user' => $user,
                'freq_user' => $freq_user
            ];

            return view('admin/account', $data);
        }
    }

    public function allInstructor(){
        $user = session('user');
    
        if (!$user || $user['id'] < 1) {
            return redirect()->to('loginAs');
        } else {

            $role = $user['role'];
            $title = 'Account Management';
            $link = base_url('images/admin.png');

            if ($role === 'student' || $role === 'guest' || $role === 'instructor') {
                return redirect()->to('/error')->with('error', 'Access denied: You do not have permission to view this page.');
            }

            $fetchUser = new UserModel();
            $instructors = $fetchUser->where('role', 'instructor')->findAll();
            $profileLink = isset($user['profile']) && !empty($user['profile']) ? base_url('uploads/' . $user['profile']) : $link;
            $data = [
                'title' => $title,
                'role' => $role,
                'link' => $profileLink,
                'user' => $user,
                'instructors' => $instructors,
            ];

        return view('admin/account/instructor/list', $data);
        }
    }

    public function registerInstructor()
    {
        $user = session('user');
    
        if (!$user || $user['id'] < 1) {
            return redirect()->to('loginAs');
        } else {

            $role = $user['role'];

            if ($role === 'student' || $role === 'guest' || $role === 'instructor') {
                return redirect()->to('/error')->with('error', 'Access denied: You do not have permission to view this page.');
            }

            $title = 'Account Management';
            $link = base_url('images/admin.png');
            $profileLink = isset($user['profile']) && !empty($user['profile']) ? base_url('uploads/' . $user['profile']) : $link;

            $data = [
                'title' => $title,
                'role' => $role,
                'link' => $profileLink,
                'user' => $user,
            ];
            return view('admin/account/instructor/add', $data);
        }
    }

    public function editInstructor($id){
        $user = session('user');
    
        if (!$user || $user['id'] < 1) {
            return redirect()->to('loginAs');
        } else {
            $role = $user['role'];

            if ($role === 'student' || $role === 'guest') {
                return redirect()->to('/error')->with('error', 'Access denied: You do not have permission to view this page.');
            }

            $fetchInstructor = new UserModel();
            $data['user'] = $fetchInstructor->where('id', $id)->first();

            $title = 'Account Management';
            $link = base_url('images/admin.png');
            $profileLink = isset($user['profile']) && !empty($user['profile']) ? base_url('uploads/' . $user['profile']) : $link;
            $data = [
                'title' => $title,
                'role' => $role,
                'link' => $profileLink,
                'user' => $user,
                'instructor' => $data['user']
            ];
            return view('admin/account/instructor/edit', $data);
        }
    }

    public function viewInstructor($id){
        $user = session('user');
    
        if (!$user || $user['id'] < 1) {
            return redirect()->to('loginAs');
        } else {
            $role = $user['role'];

            if ($role === 'student' || $role === 'guest') {
                return redirect()->to('/error')->with('error', 'Access denied: You do not have permission to view this page.');
            }

            $fetchInstructor = new UserModel();
            $data['user'] = $fetchInstructor->where('id', $id)->first();

            $title = 'Account Management';
            $link = base_url('images/admin.png');
            $profileLink = isset($user['profile']) && !empty($user['profile']) ? base_url('uploads/' . $user['profile']) : $link;
            $data = [
                'title' => $title,
                'role' => $role,
                'link' => $profileLink,
                'user' => $user,
                'instructor' => $data['user']
            ];
            return view('admin/account/instructor/view', $data);
        }
    }

    public function updateInstructor($id){
        $updateInstructor = new UserModel();
        $db = db_connect();

        if ($img = $this->request->getFile('userProfile')) {
            if ($img->isValid() && !$img->hasMoved()) {
                $imageName = $img->getRandomName();
                $img->move('uploads/', $imageName);
            }
        }

        if(!empty($_FILES['userProfile']['name'])){
            $db->query("UPDATE user SET profile = '$imageName' WHERE id= '$id'");
        }

        $data = array(
            'first_name' => $this->request->getPost('firstName'),
            'last_name' => $this->request->getPost('lastName'),
            'email' => $this->request->getPost('email'),
            'password' => password_hash($this->request->getPost('password'), PASSWORD_BCRYPT),
        );

        if($updateInstructor->update($id, $data)){
            return $this->response->setJSON(['status' => 'success', 'message' => 'Instructor update successfully']);
        } else {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Failed to update instructor']);
        }
    }
    
    public function updateStatusInstructor($id) {
        $db = db_connect();
        
        $currentStatusQuery = $db->query("SELECT status FROM user WHERE id = ?", [$id]);
        $currentStatus = $currentStatusQuery->getRow()->status;
    
        $newStatus = $currentStatus == 0 ? 1 : 0;
    
        $updateQuery = $db->query("UPDATE user SET status = ? WHERE id = ?", [$newStatus, $id]);
    
        if ($db->affectedRows() > 0) {
            return $this->response->setJSON(['status' => 'success', 'message' => 'Instructor status updated successfully']);
        } else {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Failed to update instructor status or no changes made']);
        }
    }
    
    public function deleteInstructor($id){
        $deleteInstructor = new UserModel();
        if ($deleteInstructor->delete($id)) {
            return $this->response->setJSON(['status' => 'success', 'message' => 'Instructor deleted successfully']);
        } else {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Failed to delete instructor']);
        }
    }

    public function viewUploadInstructors()
    {
        $user = session('user');
    
        if (!$user || $user['id'] < 1) {
            return redirect()->to('loginAs');
        } else {

            $role = $user['role'];

            if ($role === 'student' || $role === 'guest' || $role === 'instructor') {
                return redirect()->to('/error')->with('error', 'Access denied: You do not have permission to view this page.');
            }

            $title = 'Account Management';
            $link = base_url('images/admin.png');
            $profileLink = isset($user['profile']) && !empty($user['profile']) ? base_url('uploads/' . $user['profile']) : $link;
            $data = [
                'title' => $title,
                'role' => $role,
                'link' => $profileLink,
                'user' => $user,
            ];
            return view('admin/account/instructor/upload', $data);
        }
    }

    public function uploadInstructors()
    {
        // Get the uploaded file
        $file = $this->request->getFile('csv_file');
        
        // Check if the file is uploaded successfully
        if ($file && $file->isValid() && !$file->hasMoved()) {
            // Check if the file is a CSV file
            if ($file->getMimeType() !== 'text/csv' && $file->getMimeType() !== 'application/vnd.ms-excel') {
                return $this->response->setJSON([
                    'status' => 'error', 
                    'message' => 'File must be a valid CSV'
                ])->setStatusCode(400);
            }

            // Open the file and process its contents
            if (($handle = fopen($file->getTempName(), 'r')) !== false) {
                // Skip the first line if it's the header
                $header = fgetcsv($handle);

                // Expected columns in CSV: first_name, last_name, email, password
                $expectedColumns = ['first_name', 'last_name', 'email', 'password'];
                if ($header !== $expectedColumns) {
                    return $this->response->setJSON([
                        'status' => 'error', 
                        'message' => 'CSV columns must match: first_name, last_name, email, password'
                    ])->setStatusCode(400);
                }

                // Process each row of the CSV file
                $instructors = [];
                while (($data = fgetcsv($handle)) !== false) {
                    // Assuming the CSV columns are in the correct order
                    $instructors[] = [
                        'first_name' => $data[0],
                        'last_name'  => $data[1],
                        'email'      => $data[2],
                        'password'   => password_hash($data[3], PASSWORD_BCRYPT), // Hash password
                        'role' => 'instructor'
                    ];
                }

                fclose($handle);

                // Insert the instructors into the database
                $instructorModel = new \App\Models\UserModel();
                if ($instructorModel->insertBatch($instructors)) {
                    return $this->response->setJSON([
                        'status' => 'success', 
                        'message' => 'Imported Instructors successfully'
                    ])->setStatusCode(200);
                } else {
                    return $this->response->setJSON([
                        'status' => 'error', 
                        'message' => 'Failed to insert instructors into the database'
                    ])->setStatusCode(500);
                }
            } else {
                return $this->response->setJSON([
                    'status' => 'error', 
                    'message' => 'Unable to read the file'
                ])->setStatusCode(400);
            }
        } else {
            return $this->response->setJSON([
                'status' => 'error', 
                'message' => 'Invalid file'
            ])->setStatusCode(400);
        }
    }

    public function allStudent(){
        $user = session('user');
    
        if (!$user || $user['id'] < 1) {
            return redirect()->to('loginAs');
        } else {

            $role = $user['role'];
            $title = 'Account Management';
            $link = base_url('images/admin.png');

            if ($role === 'student' || $role === 'guest' || $role === 'instructor') {
                return redirect()->to('/error')->with('error', 'Access denied: You do not have permission to view this page.');
            }
            
            $fetchUser = new UserModel();
            $students = $fetchUser->where('role', 'student')->findAll();
            $profileLink = isset($user['profile']) && !empty($user['profile']) ? base_url('uploads/' . $user['profile']) : $link;
            $data = [
                'title' => $title,
                'role' => $role,
                'link' => $profileLink,
                'user' => $user,
                'students' => $students,
            ];

        return view('admin/account/student/list', $data);
        }
    }

    public function registerStudent()
    {
        $user = session('user');
    
        if (!$user || $user['id'] < 1) {
            return redirect()->to('loginAs');
        } else {

            $role = $user['role'];

            if ($role === 'student' || $role === 'guest' || $role === 'instructor') {
                return redirect()->to('/error')->with('error', 'Access denied: You do not have permission to view this page.');
            }

            $title = 'Account Management';
            $link = base_url('images/admin.png');
            $profileLink = isset($user['profile']) && !empty($user['profile']) ? base_url('uploads/' . $user['profile']) : $link;
            $data = [
                'title' => $title,
                'role' => $role,
                'link' => $profileLink,
                'user' => $user,
            ];
            return view('admin/account/student/add', $data);
        }
    }

    public function editStudent($id){
        $user = session('user');
    
        if (!$user || $user['id'] < 1) {
            return redirect()->to('loginAs');
        } else {
            $role = $user['role'];

            if ($role === 'student' || $role === 'guest') {
                return redirect()->to('/error')->with('error', 'Access denied: You do not have permission to view this page.');
            }

            $fetchStudent = new UserModel();
            $data['user'] = $fetchStudent->where('id', $id)->first();

            $title = 'Account Management';
            $link = base_url('images/admin.png');
            $profileLink = isset($user['profile']) && !empty($user['profile']) ? base_url('uploads/' . $user['profile']) : $link;
            $data = [
                'title' => $title,
                'role' => $role,
                'link' => $profileLink,
                'user' => $user,
                'student' => $data['user']
            ];
            return view('admin/account/student/edit', $data);
        }
    }

    public function viewStudent($id){
        $user = session('user');
    
        if (!$user || $user['id'] < 1) {
            return redirect()->to('loginAs');
        } else {
            $role = $user['role'];

            if ($role === 'student' || $role === 'guest') {
                return redirect()->to('/error')->with('error', 'Access denied: You do not have permission to view this page.');
            }

            $fetchStudent = new UserModel();
            $data['user'] = $fetchStudent->where('id', $id)->first();

            $title = 'Account Management';
            $link = base_url('images/admin.png');
            $profileLink = isset($user['profile']) && !empty($user['profile']) ? base_url('uploads/' . $user['profile']) : $link;
            $data = [
                'title' => $title,
                'role' => $role,
                'link' => $profileLink,
                'user' => $user,
                'student' => $data['user']
            ];
            return view('admin/account/student/view', $data);
        }
    }

    public function updateStudent($id){
        $updateStudent = new UserModel();
        $db = db_connect();

        if ($img = $this->request->getFile('userProfile')) {
            if ($img->isValid() && !$img->hasMoved()) {
                $imageName = $img->getRandomName();
                $img->move('uploads/', $imageName);
            }
        }

        if(!empty($_FILES['userProfile']['name'])){
            $db->query("UPDATE user SET profile = '$imageName' WHERE id= '$id'");
        }

        $data = array(
            'first_name' => $this->request->getPost('firstName'),
            'last_name' => $this->request->getPost('lastName'),
            'email' => $this->request->getPost('email'),
            'password' => password_hash($this->request->getPost('password'), PASSWORD_BCRYPT),
        );

        if($updateStudent->update($id, $data)){
            return $this->response->setJSON(['status' => 'success', 'message' => 'Student update successfully']);
        } else {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Failed to update student']);
        }
    }

    public function updateStatusStudent($id) {
        $db = db_connect();
        
        $currentStatusQuery = $db->query("SELECT status FROM user WHERE id = ?", [$id]);
        $currentStatus = $currentStatusQuery->getRow()->status;
    
        $newStatus = $currentStatus == 0 ? 1 : 0;
    
        $updateQuery = $db->query("UPDATE user SET status = ? WHERE id = ?", [$newStatus, $id]);
    
        if ($db->affectedRows() > 0) {
            return $this->response->setJSON(['status' => 'success', 'message' => 'Student status updated successfully']);
        } else {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Failed to update student status or no changes made']);
        }
    }
    
    public function deleteStudent($id){
        $deleteStudent = new UserModel();
        if ($deleteStudent->delete($id)) {
            return $this->response->setJSON(['status' => 'success', 'message' => 'Student deleted successfully']);
        } else {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Failed to delete student']);
        }
    }

    public function viewUploadStudents()
    {
        $user = session('user');
    
        if (!$user || $user['id'] < 1) {
            return redirect()->to('loginAs');
        } else {

            $role = $user['role'];

            if ($role === 'student' || $role === 'guest' || $role === 'instructor') {
                return redirect()->to('/error')->with('error', 'Access denied: You do not have permission to view this page.');
            }

            $title = 'Account Management';
            $link = base_url('images/admin.png');
            $profileLink = isset($user['profile']) && !empty($user['profile']) ? base_url('uploads/' . $user['profile']) : $link;
            $data = [
                'title' => $title,
                'role' => $role,
                'link' => $profileLink,
                'user' => $user,
            ];
            return view('admin/account/student/upload', $data);
        }
    }

    public function uploadStudents()
    {
        // Get the uploaded file
        $file = $this->request->getFile('csv_file');
        
        // Check if the file is uploaded successfully
        if ($file && $file->isValid() && !$file->hasMoved()) {
            // Check if the file is a CSV file
            if ($file->getMimeType() !== 'text/csv' && $file->getMimeType() !== 'application/vnd.ms-excel') {
                return $this->response->setJSON([
                    'status' => 'error', 
                    'message' => 'File must be a valid CSV'
                ])->setStatusCode(400);
            }

            // Open the file and process its contents
            if (($handle = fopen($file->getTempName(), 'r')) !== false) {
                // Skip the first line if it's the header
                $header = fgetcsv($handle);

                // Expected columns in CSV: first_name, last_name, email, password
                $expectedColumns = ['first_name', 'last_name', 'email', 'password'];
                if ($header !== $expectedColumns) {
                    return $this->response->setJSON([
                        'status' => 'error', 
                        'message' => 'CSV columns must match: first_name, last_name, email, password'
                    ])->setStatusCode(400);
                }

                // Process each row of the CSV file
                $students = [];
                while (($data = fgetcsv($handle)) !== false) {
                    // Assuming the CSV columns are in the correct order
                    $students[] = [
                        'first_name' => $data[0],
                        'last_name'  => $data[1],
                        'email'      => $data[2],
                        'password'   => password_hash($data[3], PASSWORD_BCRYPT), // Hash password
                        'role' => 'student'
                    ];
                }

                fclose($handle);

                // Insert the students into the database
                $studentModel = new \App\Models\UserModel();
                if ($studentModel->insertBatch($students)) {
                    return $this->response->setJSON([
                        'status' => 'success', 
                        'message' => 'Imported Students successfully'
                    ])->setStatusCode(200);
                } else {
                    return $this->response->setJSON([
                        'status' => 'error', 
                        'message' => 'Failed to insert students into the database'
                    ])->setStatusCode(500);
                }
            } else {
                return $this->response->setJSON([
                    'status' => 'error', 
                    'message' => 'Unable to read the file'
                ])->setStatusCode(400);
            }
        } else {
            return $this->response->setJSON([
                'status' => 'error', 
                'message' => 'Invalid file'
            ])->setStatusCode(400);
        }
    }

    public function allGuest(){
        $user = session('user');
    
        if (!$user || $user['id'] < 1) {
            return redirect()->to('loginAs');
        } else {

            $role = $user['role'];
            $title = 'Account Management';
            $link = base_url('images/admin.png');

            if ($role === 'student' || $role === 'guest' || $role === 'instructor') {
                return redirect()->to('/error')->with('error', 'Access denied: You do not have permission to view this page.');
            }
            
            $fetchUser = new UserModel();
            $guests = $fetchUser->where('role', 'guest')->findAll();
            $profileLink = isset($user['profile']) && !empty($user['profile']) ? base_url('uploads/' . $user['profile']) : $link;
            $data = [
                'title' => $title,
                'role' => $role,
                'link' => $profileLink,
                'user' => $user,
                'guests' => $guests,
            ];

        return view('admin/account/guest/list', $data);
        }
    }

    public function registerGuest()
    {
        $user = session('user');
    
        if (!$user || $user['id'] < 1) {
            return redirect()->to('loginAs');
        } else {

            $role = $user['role'];

            if ($role === 'student' || $role === 'guest' || $role === 'instructor') {
                return redirect()->to('/error')->with('error', 'Access denied: You do not have permission to view this page.');
            }

            $title = 'Account Management';
            $link = base_url('images/admin.png');
            $profileLink = isset($user['profile']) && !empty($user['profile']) ? base_url('uploads/' . $user['profile']) : $link;

            $data = [
                'title' => $title,
                'role' => $role,
                'link' => $profileLink,
                'user' => $user,
            ];
            return view('admin/account/guest/add', $data);
        }
    }

    public function editGuest($id){
        $user = session('user');
    
        if (!$user || $user['id'] < 1) {
            return redirect()->to('loginAs');
        } else {
            $role = $user['role'];

            if ($role === 'student' || $role === 'guest') {
                return redirect()->to('/error')->with('error', 'Access denied: You do not have permission to view this page.');
            }

            $fetchGuest = new UserModel();
            $data['user'] = $fetchGuest->where('id', $id)->first();

            $title = 'Account Management';
            $link = base_url('images/admin.png');
            $profileLink = isset($user['profile']) && !empty($user['profile']) ? base_url('uploads/' . $user['profile']) : $link;
            $data = [
                'title' => $title,
                'role' => $role,
                'link' => $profileLink,
                'user' => $user,
                'guest' => $data['user']
            ];
            return view('admin/account/guest/edit', $data);
        }
    }

    public function viewGuest($id){
        $user = session('user');
    
        if (!$user || $user['id'] < 1) {
            return redirect()->to('loginAs');
        } else {
            $role = $user['role'];

            if ($role === 'student' || $role === 'guest') {
                return redirect()->to('/error')->with('error', 'Access denied: You do not have permission to view this page.');
            }

            $fetchGuest = new UserModel();
            $data['user'] = $fetchGuest->where('id', $id)->first();

            $title = 'Account Management';
            $link = base_url('images/admin.png');
            $profileLink = isset($user['profile']) && !empty($user['profile']) ? base_url('uploads/' . $user['profile']) : $link;
            $data = [
                'title' => $title,
                'role' => $role,
                'link' => $profileLink,
                'user' => $user,
                'guest' => $data['user']
            ];
            return view('admin/account/guest/view', $data);
        }
    }

    public function updateGuest($id){
        $updateGuest = new UserModel();
        $db = db_connect();

        if ($img = $this->request->getFile('userProfile')) {
            if ($img->isValid() && !$img->hasMoved()) {
                $imageName = $img->getRandomName();
                $img->move('uploads/', $imageName);
            }
        }

        if(!empty($_FILES['userProfile']['name'])){
            $db->query("UPDATE user SET profile = '$imageName' WHERE id= '$id'");
        }

        $data = array(
            'first_name' => $this->request->getPost('firstName'),
            'last_name' => $this->request->getPost('lastName'),
            'email' => $this->request->getPost('email'),
            'password' => password_hash($this->request->getPost('password'), PASSWORD_BCRYPT),
        );

        if($updateGuest->update($id, $data)){
            return $this->response->setJSON(['status' => 'success', 'message' => 'Guest update successfully']);
        } else {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Failed to update guest']);
        }
    }

    public function updateStatusGuest($id) {
        $db = db_connect();
        
        $currentStatusQuery = $db->query("SELECT status FROM user WHERE id = ?", [$id]);
        $currentStatus = $currentStatusQuery->getRow()->status;
    
        $newStatus = $currentStatus == 0 ? 1 : 0;
    
        $updateQuery = $db->query("UPDATE user SET status = ? WHERE id = ?", [$newStatus, $id]);
    
        if ($db->affectedRows() > 0) {
            return $this->response->setJSON(['status' => 'success', 'message' => 'Guest status updated successfully']);
        } else {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Failed to update guest status or no changes made']);
        }
    }
    
    public function deleteGuest($id){
        $deleteGuest = new UserModel();
        if ($deleteGuest->delete($id)) {
            return $this->response->setJSON(['status' => 'success', 'message' => 'Guest deleted successfully']);
        } else {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Failed to delete guest']);
        }
    }

    public function viewUploadGuests()
    {
        $user = session('user');
    
        if (!$user || $user['id'] < 1) {
            return redirect()->to('loginAs');
        } else {

            $role = $user['role'];

            if ($role === 'student' || $role === 'guest' || $role === 'instructor') {
                return redirect()->to('/error')->with('error', 'Access denied: You do not have permission to view this page.');
            }

            $title = 'Account Management';
            $link = base_url('images/admin.png');
            $profileLink = isset($user['profile']) && !empty($user['profile']) ? base_url('uploads/' . $user['profile']) : $link;

            $data = [
                'title' => $title,
                'role' => $role,
                'link' => $profileLink,
                'user' => $user,
            ];
            return view('admin/account/guest/upload', $data);
        }
    }

    public function uploadGuests()
    {
        // Get the uploaded file
        $file = $this->request->getFile('csv_file');
        
        // Check if the file is uploaded successfully
        if ($file && $file->isValid() && !$file->hasMoved()) {
            // Check if the file is a CSV file
            if ($file->getMimeType() !== 'text/csv' && $file->getMimeType() !== 'application/vnd.ms-excel') {
                return $this->response->setJSON([
                    'status' => 'error', 
                    'message' => 'File must be a valid CSV'
                ])->setStatusCode(400);
            }

            // Open the file and process its contents
            if (($handle = fopen($file->getTempName(), 'r')) !== false) {
                // Skip the first line if it's the header
                $header = fgetcsv($handle);

                // Expected columns in CSV: first_name, last_name, email, password
                $expectedColumns = ['first_name', 'last_name', 'email', 'password'];
                if ($header !== $expectedColumns) {
                    return $this->response->setJSON([
                        'status' => 'error', 
                        'message' => 'CSV columns must match: first_name, last_name, email, password'
                    ])->setStatusCode(400);
                }

                // Process each row of the CSV file
                $guests = [];
                while (($data = fgetcsv($handle)) !== false) {
                    // Assuming the CSV columns are in the correct order
                    $guests[] = [
                        'first_name' => $data[0],
                        'last_name'  => $data[1],
                        'email'      => $data[2],
                        'password'   => password_hash($data[3], PASSWORD_BCRYPT), // Hash password
                        'role' => 'guest'
                    ];
                }

                fclose($handle);

                // Insert the guests into the database
                $guestModel = new \App\Models\UserModel();
                if ($guestModel->insertBatch($guests)) {
                    return $this->response->setJSON([
                        'status' => 'success', 
                        'message' => 'Imported Guests successfully'
                    ])->setStatusCode(200);
                } else {
                    return $this->response->setJSON([
                        'status' => 'error', 
                        'message' => 'Failed to insert guests into the database'
                    ])->setStatusCode(500);
                }
            } else {
                return $this->response->setJSON([
                    'status' => 'error', 
                    'message' => 'Unable to read the file'
                ])->setStatusCode(400);
            }
        } else {
            return $this->response->setJSON([
                'status' => 'error', 
                'message' => 'Invalid file'
            ])->setStatusCode(400);
        }
    }

}
