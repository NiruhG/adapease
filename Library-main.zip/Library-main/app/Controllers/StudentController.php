<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\CollegeModel;
use App\Models\CommentModel;
use App\Models\LibraryModel;
use App\Models\MaterialsModel;
use App\Models\OptionsModel;
use App\Models\QuestionsModel;
use App\Models\UseranswerModel;
use App\Models\UserModel;
use App\Models\VdriveModel;
use App\Models\VimageModel;
use App\Models\VtextModel;
use App\Models\VvideoModel;
use CodeIgniter\HTTP\ResponseInterface;

class StudentController extends BaseController
{
    public function register()
    {
        $fetchCollege = new CollegeModel();
        $fetchData2['college'] = $fetchCollege->select('name')->findAll();
        return view('student/register', [
            'colleges' => $fetchData2['college']
        ]);
    }

    public function storeStudent()
    {
        $insertStudent = new UserModel();
        $role = 'student';
        $status = '0';
        $login_first = '1';
        
        $validation = \Config\Services::validation();
        
        $validation->setRules([
            'email' => 'required|valid_email',
            'password' => 'required|min_length[8]',
        ]);
    
        if (!$this->validate($validation->getRules())) {
            return $this->response
                        ->setJSON(['status' => 'error', 'message' => 'Invalid input data'])
                        ->setStatusCode(ResponseInterface::HTTP_BAD_REQUEST);
        }

        $data = array(
            'email' => $this->request->getPost('email'),
            'password' => password_hash($this->request->getPost('password'), PASSWORD_DEFAULT), 
            'role' => $role,
            'status' => $status,
            'college' => $this->request->getPost('college'),
            'login_first' => $login_first
        );
    
        if ($insertStudent->insert($data)) {
            return $this->response
                        ->setJSON(['status' => 'success', 'message' => 'Student Registered successfully'])
                        ->setStatusCode(ResponseInterface::HTTP_OK);
        } else {
            return $this->response
                        ->setJSON(['status' => 'error', 'message' => 'Failed to register student'])
                        ->setStatusCode(ResponseInterface::HTTP_BAD_REQUEST);
        }
    }
    
    public function login()
    {
        return view('student/login');
    }

    function generateRandomString($length = 8) {
        $characters = 'abcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()_+-=<>?';
        $randomString = '';

        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[random_int(0, strlen($characters) - 1)];
        }

        return $randomString;
    }

    public function doLogin() {
        // Load the session service
        $this->session = \Config\Services::session();
        
        // Load the user model
        $login = new UserModel();

        // Get posted email and password
        $email = $this->request->getPost('email');
        $password = $this->request->getPost('password');

        $result = $login->where('email', $email)->first();

        if ($result && isset($result['id']) && $result['id'] > 0) {
            if ($result['role'] == "student" && $result['status'] == '0') {
                if (password_verify($password, $result['password'])) {
                    if ($result['login_first'] == '1') {
                        $randomString = $this->generateRandomString();
                        if ($login->update($result['id'], ['code' => $randomString])) {
                            log_message('info', 'Code updated successfully for user ID: ' . $result['id']);

                            // Send verification email with the generated code
                            if ($this->sendVerificationEmail($email, $randomString)) {
                                // Set session data and redirect to verification page
                                $this->session->set("user", $result);
                                return redirect()->to('student/verification');
                            } else {
                                return $this->response->setJSON(['status' => 'error', 'message' => 'Failed to send verification email']);
                            }
                        } else {
                            // Log failure if code update failed
                            log_message('error', 'Failed to update code for user ID: ' . $result['id']);
                            return $this->response->setJSON(['status' => 'error', 'message' => 'Failed to update user code']);
                        }
                    } else {
                        $this->session->set("user", $result);
                        return redirect()->to('/main/dashboard');
                    }
                } else {
                    return $this->response->setJSON(['status' => 'error', 'message' => 'Invalid password']);
                }
            } else {
                return $this->response->setJSON(['status' => 'error', 'message' => 'User is not an student or not eligible to login']);
            }
        } else {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Email not found']);
        }
    }

    public function sendVerificationEmail($email, $code) {
        // Load the email service
        $emailService = \Config\Services::email();

        // Set the sender details
        $emailService->setFrom('podongbacala@gmail.com', 'AdapEase');
        $emailService->setTo($email);
        $emailService->setSubject('Verification Code');

        // Compose the email content
        $message = "Your verification code is: " . $code;
        $emailService->setMessage($message);

        // Attempt to send the email
        if ($emailService->send()) {
            log_message('info', 'Verification email sent successfully to: ' . $email);
            return true;
        } else {
            // Log the error if email sending fails
            log_message('error', 'Failed to send email: ' . $emailService->printDebugger());
            return false;
        }
    }

    public function verify()
    {
        $user = session('user');
    
        if (!$user || $user['id'] < 1) {
            return redirect()->to('loginAs');
        } else {
            return view('student/verification');
        }
    }

    public function doVerify()
    {
       
        $user = session('user');
        
        $code = $this->request->getPost('code'); 
        
        if (!$user) {
            return redirect()->to('/login')->with('error', 'You must be logged in to verify your account.');
        }

        $userModel = new UserModel();
        
        $userData = $userModel->find($user['id']);

        if ($userData && $userData['code'] === $code) {
            $updatedLoginCount = $userData['login_count'] + 1;
            $userModel->update($user['id'], [
                'code' => null,
                'login_count' => $updatedLoginCount
            ]);

            session()->set('user', $user);
        
            return redirect()->to('/main/dashboard')->with('success', 'Email verified successfully!');
        } else {
            return redirect()->to('/verification')->with('error', 'Invalid verification code.');
        }
    }

    public function virtual(){
        $user = session('user');
    
        if (!$user || $user['id'] < 1) {
            return redirect()->to('loginAs');
        } else {

            $role = $user['role'];
            $fetchLibrary = new LibraryModel();
            $fetchVirtual = new VdriveModel();

            if ($role === 'guest' || $role === 'admin' || $role === 'instructor') {
                return redirect()->to('/error')->with('error', 'Access denied: You do not have permission to view this page.');
            }
            
            $libraryCount = $fetchLibrary->where('user_id', $user['id'])->countAllResults();
            $virtualCount = $fetchVirtual->where('user_id', $user['id'])->countAllResults();

            $title = 'Student Virtual Drive';
            $link = base_url('images/student.png');
            $profileLink = isset($user['profile']) && !empty($user['profile']) ? base_url('uploads/' . $user['profile']) : $link;
            $data = [
                'title' => $title,
                'role' => $role,
                'link' => $profileLink,
                'user' => $user,
                'libraryCount' => $libraryCount,
                'virtualCount' => $virtualCount
            ];
            return view("student/virtual-drive", $data);
        }
    }

    public function virtualAll(){
        $user = session('user');
    
        if (!$user || $user['id'] < 1) {
            return redirect()->to('loginAs');
        } else {

            $role = $user['role'];
            $fetchVirtual = new VdriveModel();

            $vData = $fetchVirtual->select('vdrive.id AS vdrive_id, vdrive.user_id, vdrive.title, vdrive.author, vdrive.subject, vdrive.course ')
                             ->where('user_id', $user['id'])
                             ->findAll();

            if ($role === 'guest' || $role === 'admin' || $role === 'instructor') {
                return redirect()->to('/error')->with('error', 'Access denied: You do not have permission to view this page.');
            }
            
            $title = 'Student Annotation Tools';
            $link = base_url('images/student.png');
            $profileLink = isset($user['profile']) && !empty($user['profile']) ? base_url('uploads/' . $user['profile']) : $link;
            $data = [
                'title' => $title,
                'role' => $role,
                'link' => $profileLink,
                'user' => $user,
                'virtual' => $vData
            ];
            return view("student/virtual-drive/all", $data);
        }
    }

    public function viewVirtual($id){
        $user = session('user');
    
        if (!$user || $user['id'] < 1) {
            return redirect()->to('loginAs');
        } else {
            $role = $user['role'];

            $fetchVirtual = new VdriveModel();
            $data['virtual'] = $fetchVirtual->where('id', $id)->first();

            if ($role === 'guest' || $role === 'admin' || $role === 'instructor') {
                return redirect()->to('/error')->with('error', 'Access denied: You do not have permission to view this page.');
            }

            $title = 'Student Annotation Tools';
            $link = base_url('images/student.png');
            $profileLink = isset($user['profile']) && !empty($user['profile']) ? base_url('uploads/' . $user['profile']) : $link;
            $data = [
                'title' => $title,
                'role' => $role,
                'link' => $profileLink,
                'virtuals' => $data['virtual'],
                'user' => $user,
            ];
            return view('student/virtual-drive/view', $data);
        }
    }

    public function contentVirtual($id) {
        $user = session('user');
    
        if (!$user || $user['id'] < 1) {
            return redirect()->to('loginAs');
        } else {
            $role = $user['role'];
    
            if ($role === 'guest' || $role === 'admin' || $role === 'instructor') {
                return redirect()->to('/error')->with('error', 'Access denied: You do not have permission to view this page.');
            }
            
            $fetchVirtual = new VdriveModel();
            $data['virtual'] = $fetchVirtual->where('id', $id)->first();
    
            $textModel = new VtextModel();
            $data1['texts'] = $textModel->select('vtext.*, user.first_name, user.last_name, user.profile, user.email')
                                         ->join('user', 'vtext.user_id = user.id')
                                         ->where('virtual_id', $id)
                                         ->where('vtext.user_id', $user['id'])
                                         ->findAll();
            $imageModel = new VimageModel();
            $data2['images'] = $imageModel->select('vimage.*, user.first_name, user.last_name, user.profile, user.email')
                                         ->join('user', 'vimage.user_id = user.id')
                                         ->where('virtual_id', $id)
                                         ->where('vimage.user_id', $user['id'])
                                         ->findAll();
            $videoModel = new VvideoModel();
            $data3['videos'] = $videoModel->select('vvideo.*, user.first_name, user.last_name, user.profile, user.email')
                                         ->join('user', 'vvideo.user_id = user.id')
                                         ->where('virtual_id', $id)
                                         ->where('vvideo.user_id', $user['id'])
                                         ->findAll();
            
            $title = 'Student Annotation Tools';
            $link = base_url('images/student.png');
            $profileLink = isset($user['profile']) && !empty($user['profile']) ? base_url('uploads/' . $user['profile']) : $link;
    
            $questionsModel = new QuestionsModel();
            $data['questions'] = $questionsModel->where('materials_id', $data['virtual']['material_id'])->findAll();
           
            $optionsModel = new OptionsModel();
            foreach ($data['questions'] as &$question) {
                $question['options'] = $optionsModel->where('question_id', $question['id'])->findAll();
            }

            $userAnswerModel = new UseranswerModel();
            $data['user_answers'] = $userAnswerModel->where('materials_id', $data['virtual']['material_id'])
                                                 ->where('answer_by', $user['id'])
                                                 ->first();
            $data = [
                'title' => $title,
                'role' => $role,
                'link' => $profileLink,
                'virtuals' => $data['virtual'],
                'texts' => $data1['texts'],
                'images' => $data2['images'],
                'videos' => $data3['videos'],
                'questions' => $data['questions'],
                'user' => $user,
                'user_answers' => $data['user_answers'],
            ];
            
            return view('student/virtual-drive/content', $data);
        }
    }
    

    public function addText(){
        $user = session('user');
        $textModel = new VtextModel();
    
        $virtualId = $this->request->getPost('virtual_id');
        $description = $this->request->getPost('description');

        $data = [
            'user_id' => $user['id'],
            'virtual_id' => $virtualId,
            'description' => $description
        ];
    
        
        if ($textModel->insert($data)) {
            return $this->response->setJSON(['status' => 'success', 'message' => 'Add text successfully']);
        } else {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Failed to add text.']);
        }
    }

    public function addImage() {
        $user = session('user');
        $insertImages = new VimageModel();
        $fileName = '';
    
        if ($file = $this->request->getFile('vImage')) {
            if ($file->isValid() && !$file->hasMoved()) {
                $fileName = $file->getRandomName();
                $file->move('uploads/', $fileName);
            }
        }

        $virtualId = $this->request->getPost('virtual_id');

        $data = array(
            'image' => $fileName,
            'user_id' => $user['id'],
            'virtual_id' => $virtualId,
        );
        
        if ($insertImages->insert($data)) {
            return $this->response->setJSON(['status' => 'success', 'message' => 'Image added successfully']);
        } else {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Failed to add image']);
        }
    }

    public function addVideo() {
        $user = session('user');
        $insertVideos = new VvideoModel();
        $fileName = '';
    
        if ($file = $this->request->getFile('vVideo')) {
            if ($file->isValid() && !$file->hasMoved()) {
                $fileName = $file->getRandomName();
                $file->move('uploads/', $fileName);
            }
        }

        $virtualId = $this->request->getPost('virtual_id');

        $data = array(
            'video' => $fileName,
            'user_id' => $user['id'],
            'virtual_id' => $virtualId,
        );
        
        if ($insertVideos->insert($data)) {
            return $this->response->setJSON(['status' => 'success', 'message' => 'Video added successfully']);
        } else {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Failed to add video']);
        }
    }
    
    public function deleteVirtual($id) {
    
        $deleteVirtual = new VdriveModel();
        
        $item = $deleteVirtual->find($id);
        if (!$item) {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Item not found']);
        }

        $textModel = new VtextModel();
        $textModel->where('virtual_id', $id)->delete();

        $imageModel = new VimageModel(); 
        $imageModel->where('virtual_id', $id)->delete();
        
        $videoModel = new VvideoModel(); 
        $videoModel->where('virtual_id', $id)->delete();

        if ($deleteVirtual->delete($id)) {
            return $this->response->setJSON(['status' => 'success', 'message' => 'IMs unsaved in Virtual Drive successfully']);
        } else {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Failed to unsaved ims']);
        }
    }

    public function library(){
        $user = session('user');
    
        if (!$user || $user['id'] < 1) {
            return redirect()->to('loginAs');
        } else {

            $role = $user['role'];

            if ($role === 'guest' || $role === 'admin' || $role === 'instructor') {
                return redirect()->to('/error')->with('error', 'Access denied: You do not have permission to view this page.');
            }
            $fetchLibrary = new LibraryModel();
            $libraryData = $fetchLibrary->select('library.id AS library_id, library.user_id, library.material_id, materials.title, materials.author, materials.subject, materials.course')
                             ->where('user_id', $user['id'])
                             ->join('materials', 'materials.id = library.material_id', 'left')
                             ->findAll();
            
            $title = 'Student Personal Library';
            $link = base_url('images/student.png');
            $profileLink = isset($user['profile']) && !empty($user['profile']) ? base_url('uploads/' . $user['profile']) : $link;
            $data = [
                'title' => $title,
                'role' => $role,
                'link' => $profileLink,
                'user' => $user,
                'library' => $libraryData
            ];
            return view("student/library", $data);
        }
    }

    public function deleteLibrary($id) {
    
        $deleteLibrary = new LibraryModel();
        
        $item = $deleteLibrary->find($id);
        if (!$item) {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Item not found']);
        }
    
        if ($deleteLibrary->delete($id)) {
            return $this->response->setJSON(['status' => 'success', 'message' => 'IMs unsaved successfully']);
        } else {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Failed to unsaved ims']);
        }
    }
    
    public function collab(){
        $user = session('user');
    
        if (!$user || $user['id'] < 1) {
            return redirect()->to('loginAs');
        } else {

            $role = $user['role'];

            if ($role === 'guest' || $role === 'admin' || $role === 'instructor') {
                return redirect()->to('/error')->with('error', 'Access denied: You do not have permission to view this page.');
            }
            $fetchMaterials = new MaterialsModel();
            $fetchData['materials'] = $fetchMaterials->findAll();
            
            $title = 'Student Collaboration';
            $link = base_url('images/student.png');
            $profileLink = isset($user['profile']) && !empty($user['profile']) ? base_url('uploads/' . $user['profile']) : $link;
            $data = [
                'title' => $title,
                'role' => $role,
                'link' => $profileLink,
                'user' => $user,
                'materials' => $fetchData['materials'],
            ];
            return view("student/collaboration", $data);
        }
    }

    public function viewContent($id){
        $user = session('user');
    
        if (!$user || $user['id'] < 1) {
            return redirect()->to('loginAs');
        } else {
            $role = $user['role'];

            $fetchMaterials = new MaterialsModel();
            $data['materials'] = $fetchMaterials->where('id', $id)->first();
            
            $commentModel = new CommentModel();
            $data1['comments'] = $commentModel->select('comment.*, user.first_name, user.last_name, user.profile, user.email')
                                         ->join('user', 'comment.user_id = user.id')
                                         ->where('material_id', $id)
                                         ->findAll();

            if ($role === 'guest' || $role === 'admin' || $role === 'instructor') {
                return redirect()->to('/error')->with('error', 'Access denied: You do not have permission to view this page.');
            }

            $title = 'Student Collaboration';
            $link = base_url('images/student.png');
            $profileLink = isset($user['profile']) && !empty($user['profile']) ? base_url('uploads/' . $user['profile']) : $link;
            $data = [
                'title' => $title,
                'role' => $role,
                'link' => $profileLink,
                'materials' => $data['materials'],
                'comments' => $data1['comments'],
                'user' => $user,
            ];
            return view('student/collaboration/content', $data);
        }
    }

    public function addComment(){
        $user = session('user');
        $commentModel = new CommentModel();
    
        $materialId = $this->request->getPost('material_id');
        $description = $this->request->getPost('description');

        $data = [
            'user_id' => $user['id'],
            'material_id' => $materialId,
            'description' => $description
        ];
    
        
        if ($commentModel->insert($data)) {
            return $this->response->setJSON(['status' => 'success', 'message' => 'Add comment successfully']);
        } else {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Failed to add comment.']);
        }
    }
}
