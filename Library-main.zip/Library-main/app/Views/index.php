<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>AdapEase Students with E-Library Access</title>
    <meta name="description" content="The small framework with powerful features">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" type="image/png" href="/favicon.ico">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="<?= base_url() ?>css/styles.css">
    
</head>
<body>
    <div class="flex flex-col relative min-h-screen">
        <nav class="flex flex-row relative py-3 px-20 items-center gap-2 w-full mb-10">
            <div class="absolute bg-[#D9D9D9] rounded-full top-12 left-44 w-40 h-40 opacity-60"></div>
            <div class="absolute bg-[#D9D9D9] rounded-full top-20 right-28 w-40 h-40 opacity-60"></div>
            <div class="z-10">
                <a href="<?= base_url('index') ?>" class="btn btn-primary text-2xl font-bold">
                    <img 
                        src="<?php echo base_url('images/logo.png'); ?>" 
                        alt="Logo"
                    >
                </a>
            </div>
            <div class="flex-grow mr-10 z-10">
                <div class="flex justify-end mb-1 gap-8"> 
                    <a href="<?= base_url('index') ?>" class="btn btn-primary text-2xl font-bold">Home</a>
                    <div class="flex flex-row gap-2 font-bold text-2xl items-center">
                        <i class="fa-regular fa-user"></i> 
                        <a href="<?= base_url('loginAs') ?>" class="btn btn-primary">Login</a>
                    </div>
                    <div class="flex flex-row gap-2 font-bold text-2xl items-center">
                        <i class="fa-regular fa-user"></i> 
                        <a href="<?= base_url('registerAs') ?>" class="btn btn-primary">Register</a>
                    </div>
                </div>
                <div class="h-1 bg-black w-full mb-8 "></div> 
                </div>
        </nav>
        <section class="flex relative gap-10 justify-center items-center w-full h-full ">
            <div class="absolute bg-[#D9D9D9] rounded-full -top-12 left-[39%] w-36 h-36 opacity-60"></div>
            <div class="absolute bg-[#D9D9D9] rounded-full top-12 right-[30%] w-36 h-36 opacity-60"></div>
            <div class="absolute bg-[#D9D9D9] rounded-full top-[210px] right-64 w-36 h-36 opacity-60"></div>
            <div class="absolute bg-[#D9D9D9] rounded-full top-[65%] right-[45%] w-40 h-40 opacity-60"></div>
            <div class="absolute bg-[#D9D9D9] rounded-full top-[55%] left-52 w-40 h-40 opacity-60"></div>
            <img 
                src="<?php echo base_url('images/bg.png'); ?>" 
                alt="Logo" 
                class="h-[470px] z-10"
            > 
            <div class="flex flex-col gap-12 items-center z-10">
                <h1 class="font-bold text-6xl text-center">
                    AdapEase Students<br/>
                    with E-Library<br/>
                    Access
                </h1>
                <a href="<?= base_url('/aboutus') ?>" class="text-center text-white font-bold text-3xl bg-[#1ED300] w-max p-2">Getting to know</a>
        </section>
    </div>
</body>
</html>
