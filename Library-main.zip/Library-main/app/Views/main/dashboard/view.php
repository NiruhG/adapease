<?php

$this->extend('layout/layout');
$this->section('body');

?>
<div class="relative h-full">
    <div class="flex flex-col mt-5 gap-1 items-center ">
       
            <div 
                
                class="flex flex-col  px-10 pb-10  w-[35%]  shadow-lg bg-white z-10 items-center"
            >
                <!-- <div class="flex flex-col gap-2 items-center mb-5">
                        <img
                            src="<?= base_url('images/book.png'); ?>" 
                            alt="Material"
                            class="h-20 w-20 object-cover border border-gray-300"
                        >
                </div>
                <div class="flex flex-col items-center text-2xl italic mb-4">
                    <p class="font-semibold">“<?= $materials['title'] ?>”</p>
                </div>
                <div class="flex items-center text-lg">
                    <p class="font-semibold text-gray-800 text-base p-2 bg-gray-100 rounded shadow">Author: <?= $materials['author'] ?></p>
                </div>
                <div class="flex items-center text-lg">
                    <p class="font-semibold text-gray-800 text-base p-2 bg-gray-100 rounded shadow">Subject: <?= $materials['subject'] ?></p>
                </div>
                <div class="flex items-center text-lg mb-4">
                    <p class="font-semibold text-gray-800 text-base p-2 bg-gray-100 rounded shadow">Course: <?= $materials['course'] ?></p>
                </div>
                 <div class="flex items-center mb-2">
                    <div id="pdfContainer" class="relative">
                        <embed
                            id="pdfEmbed"
                            type="application/pdf"
                            src="/uploads/<?= $materials['file'] ?>"
                            alt="File"
                            width="350"
                            height="300"
                        >
                    </div>
                </div>
                <button 
                    onclick="toggleFullScreen()" 
                    class="bg-gray-800 text-white px-3 py-1 text-sm rounded"
                    >
                    Fullscreen the Content
                </button> -->
                <div id="pdfContainer" class="relative mb-4">
                    <canvas id="pdfCanvas" class="border border-gray-300"></canvas>
                </div>
                <div class="flex justify-between w-full">
                    <button id="prevPage" class="bg-gray-800 text-white px-3 py-1 text-sm rounded" disabled>Previous</button>
                    <button id="nextPage" class="bg-gray-800 text-white px-3 py-1 text-sm rounded">Next</button>
                </div>

            </div>
    <div>
    <img 
        src="<?php echo base_url('images/bgMain.png'); ?>" 
        alt="Logo" 
        class="h-[500px] absolute left-[25%] bottom-28 opacity-40 "
    > 
</div>

<script>
    document.addEventListener('contextmenu', function(e) {
        e.preventDefault();
    });
    document.addEventListener('keydown', function(e) {
        if (e.ctrlKey && (e.key === 's' || e.key === 'p' || e.key === 'c' || e.key === 'v' || e.key === 'a')) {
            e.preventDefault(); 
            Swal.fire({
                title: "Warning!",
                text: "This content is confidential. Unauthorized sharing or distribution is prohibited.",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            });
        }

        if (e.altKey && e.metaKey && e.key === 'r') {
            e.preventDefault();
            Swal.fire({
                title: "Warning!",
                text: "This content is confidential. Unauthorized sharing or distribution is prohibited.",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            });
        }

        if(e.key === 'Meta' || e.key === 'Alt' ){
            e.preventDefault(); 
            Swal.fire({
                title: "Warning!",
                text: "This content is confidential. Unauthorized sharing or distribution is prohibited.",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            });
        }

        if (e.key === 'PrintScreen' || (e.ctrlKey && e.key === 'PrintScreen') || (e.altKey && e.key === 'PrintScreen')) {
            Swal.fire({
                title: "Warning!",
                text: "This content is confidential. Unauthorized sharing or screenshots are prohibited.",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            });
        }
    });

    // function toggleFullScreen() {
    //     const pdfContainer = document.getElementById("pdfContainer");
    //     const pdfEmbed = document.getElementById("pdfEmbed");

    //     if (!document.fullscreenElement) {
    //         pdfContainer.style.width = "100%";
    //         pdfContainer.style.height = "100%";
    //         pdfEmbed.style.width = "100%";
    //         pdfEmbed.style.height = "100%";

    //         pdfContainer.requestFullscreen().catch(err => {
    //             alert(`Error attempting to enable full-screen mode: ${err.message}`);
    //         });
    //     } else {
    //         document.exitFullscreen().then(() => {
    //             pdfContainer.style.width = "350px";  
    //             pdfContainer.style.height = "300px"; 
    //             pdfEmbed.style.width = "350px";     
    //             pdfEmbed.style.height = "300px";   
    //         });
    //     }
    // }

    document.addEventListener('DOMContentLoaded', function () {
            const url = '/uploads/<?= $materials['file'] ?>'; 
            const pdfjsLib = window['pdfjs-dist/build/pdf'];
            pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/2.10.377/pdf.worker.min.js';

            let pdfDoc = null;
            let currentPage = 1;

            const pdfCanvas = document.getElementById('pdfCanvas');
            const ctx = pdfCanvas.getContext('2d');

            const renderPage = (pageNum) => {
                pdfDoc.getPage(pageNum).then(page => {
                    const desiredHeight = 900; 
                    const viewport = page.getViewport({ scale: desiredHeight / page.getViewport({ scale: 0.8 }).height });
                    
                    pdfCanvas.height = viewport.height;
                    pdfCanvas.width = viewport.width;

                    const renderContext = {
                        canvasContext: ctx,
                        viewport: viewport
                    };

                    page.render(renderContext).promise.then(() => {
                        console.log(`Page ${pageNum} rendered`);
                    });
                });
            };

            const loadingTask = pdfjsLib.getDocument(url);
            loadingTask.promise.then(pdf => {
                pdfDoc = pdf;
                console.log('PDF loaded');
                renderPage(currentPage); 
            });

            const saveScrollPosition = () => {
                const savedPosition = window.scrollY;
                return savedPosition;
            };  

            document.getElementById('prevPage').addEventListener('click', () => {
                if (currentPage <= 1) return; // Don't go below page 1
                currentPage--;
                renderPage(currentPage);
                updateButtons();
                window.scrollTo(0, saveScrollPosition());
            });

            document.getElementById('nextPage').addEventListener('click', () => {
                if (currentPage >= pdfDoc.numPages) return; 
                currentPage++;
                renderPage(currentPage);
                updateButtons();
                window.scrollTo(0, saveScrollPosition()); 
            });

            const updateButtons = () => {
                document.getElementById('prevPage').disabled = (currentPage <= 1);
                document.getElementById('nextPage').disabled = (currentPage >= pdfDoc.numPages);
            };
    });
</script>


<?php $this->endSection(); ?>