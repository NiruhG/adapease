<?php

$this->extend('layout/layout');
$this->section('body');

?>
<div class="relative h-full">
    <div class="flex flex-col mt-5 gap-1 items-center ">
        <form id="saveToLibraryForm" method="POST" action="/main/materials/content" onsubmit="return handleFormSubmit(event)">
            <input type="hidden" name="material_id" value="<?= $material['id'] ?>">
            <button type="submit" class="absolute top-10 right-28  bg-transparent border-none cursor-pointer z-10 ">
                <i class="fa-regular fa-bookmark text-7xl"></i>
                        
            </button>
        </form>
        <form id="saveToVirtualForm" method="POST" action="/main/materials/content1" onsubmit="return handleFormSubmit1(event)">
            <input type="hidden" name="material_id" value="<?= $material['id'] ?>">
            <input type="hidden" name="material_title" value="<?= $material['title'] ?>">
            <input type="hidden" name="material_author" value="<?= $material['author'] ?>">
            <input type="hidden" name="material_subject" value="<?= $material['subject'] ?>">
            <input type="hidden" name="material_course" value="<?= $material['course'] ?>">
            <input type="hidden" name="material_file" value="<?= $material['file'] ?>">
            <button type="submit" class="absolute top-40 right-[107px] bg-transparent border-none cursor-pointer z-10">
                <i class="fa-regular fa-floppy-disk text-7xl"></i>
            </button>
        </form>
        <?php if (isset($questionsByMaterial[$material['id']]) && !empty($questionsByMaterial[$material['id']])): ?>
            <span class="font-semibold text-lg absolute top-10 left-8">Start Assessment</span>
            <button
                onclick="<?= $hasAnswered ? 'showAlert()' : 'showForm(' . esc($material['id']) . ');' ?>"  
                class="absolute top-20 left-16 bg-transparent border-none cursor-pointer z-10"
            >
                <i class="fa-regular fa-play-circle text-7xl"></i>
            </button>
        <?php endif; ?>
        <div class="flex flex-col relative px-10 pb-10  w-[35%]  shadow-lg bg-white z-10 items-center">
            <div id="pdfContainer" class="relative mb-4">
                <canvas id="pdfCanvas" class="border border-gray-300"></canvas>
            </div>
            <div class="flex justify-between w-full">
                <button id="prevPage" class="bg-gray-800 text-white px-3 py-1 text-sm rounded" disabled>Previous</button>
                <button id="nextPage" class="bg-gray-800 text-white px-3 py-1 text-sm rounded">Next</button>
            </div>
        </div>
    <div>
    <img 
        src="<?php echo base_url('images/bgMain.png'); ?>" 
        alt="Logo" 
        class="h-[500px] absolute left-[25%] bottom-28 opacity-40 "
    > 
</div>

<script>
            document.addEventListener('contextmenu', function (e) {
                e.preventDefault();
            });
            document.addEventListener('keydown', function(e) {
                if (e.ctrlKey && (e.key === 's' || e.key === 'p' || e.key === 'c' || e.key === 'v' || e.key === 'a')) {
                    e.preventDefault(); 
                    Swal.fire({
                        title: "Warning!",
                        text: "This content is confidential. Unauthorized sharing or distribution is prohibited.",
                        icon: "warning",
                        buttons: true,
                        dangerMode: true,
                    });
                }

                if (e.altKey && e.metaKey && e.key === 'r') {
                    e.preventDefault();
                    Swal.fire({
                        title: "Warning!",
                        text: "This content is confidential. Unauthorized sharing or distribution is prohibited.",
                        icon: "warning",
                        buttons: true,
                        dangerMode: true,
                    });
                }

                if(e.key === 'Meta' || e.key === 'Alt' ){
                    e.preventDefault(); 
                    Swal.fire({
                        title: "Warning!",
                        text: "This content is confidential. Unauthorized sharing or distribution is prohibited.",
                        icon: "warning",
                        buttons: true,
                        dangerMode: true,
                    });
                }

                if (e.key === 'PrintScreen' || (e.ctrlKey && e.key === 'PrintScreen') || (e.altKey && e.key === 'PrintScreen')) {
                    Swal.fire({
                        title: "Warning!",
                        text: "This content is confidential. Unauthorized sharing or screenshots are prohibited.",
                        icon: "warning",
                        buttons: true,
                        dangerMode: true,
                    });
                }
            });

            document.addEventListener('DOMContentLoaded', function () {
                    const url = '/uploads/<?= $material['file'] ?>'; 
                    const pdfjsLib = window['pdfjs-dist/build/pdf'];
                    pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/2.10.377/pdf.worker.min.js';

                    let pdfDoc = null;
                    let currentPage = 1;

                    const pdfCanvas = document.getElementById('pdfCanvas');
                    const ctx = pdfCanvas.getContext('2d');

                    const renderPage = (pageNum) => {
                        pdfDoc.getPage(pageNum).then(page => {
                            const desiredHeight = 900; 
                            const viewport = page.getViewport({ scale: desiredHeight / page.getViewport({ scale: 0.8 }).height });
                            
                            pdfCanvas.height = viewport.height;
                            pdfCanvas.width = viewport.width;

                            const renderContext = {
                                canvasContext: ctx,
                                viewport: viewport
                            };

                            page.render(renderContext).promise.then(() => {
                                console.log(`Page ${pageNum} rendered`);
                            });
                        });
                    };

                    const loadingTask = pdfjsLib.getDocument(url);
                    loadingTask.promise.then(pdf => {
                        pdfDoc = pdf;
                        console.log('PDF loaded');
                        renderPage(currentPage); 
                    });

                    const saveScrollPosition = () => {
                        const savedPosition = window.scrollY;
                        return savedPosition;
                    };  

                    document.getElementById('prevPage').addEventListener('click', () => {
                        if (currentPage <= 1) return; // Don't go below page 1
                        currentPage--;
                        renderPage(currentPage);
                        updateButtons();
                        window.scrollTo(0, saveScrollPosition());
                    });

                    document.getElementById('nextPage').addEventListener('click', () => {
                        if (currentPage >= pdfDoc.numPages) return; 
                        currentPage++;
                        renderPage(currentPage);
                        updateButtons();
                        window.scrollTo(0, saveScrollPosition()); 
                    });

                    const updateButtons = () => {
                        document.getElementById('prevPage').disabled = (currentPage <= 1);
                        document.getElementById('nextPage').disabled = (currentPage >= pdfDoc.numPages);
                    };
            });

            async function handleFormSubmit(event) {
                event.preventDefault();

                // Check if there are questions available
                const questionsAvailable = <?= json_encode(isset($questionsByMaterial[$material['id']]) && !empty($questionsByMaterial[$material['id']])) ?>;

                // Check if the user has answered the assessment only if questions are available
                if (questionsAvailable && !<?= json_encode($hasAnswered) ?>) {
                    Swal.fire({
                        icon: 'warning',
                        title: 'Assessment Required',
                        text: 'You need to finish the assessment before saving this to the library.',
                    });
                    return; // Exit the function if they haven't completed the assessment
                }

                const formData = new FormData(event.target);

                const { value: wantToSave } = await Swal.fire({
                    title: 'Save to Library?',
                    text: 'Do you want to save this IM to your Personal Library?',
                    icon: 'question',
                    showCancelButton: true,
                    confirmButtonText: 'Yes',
                    cancelButtonText: 'No',
                });

                if (wantToSave) {
                    try {
                        const response = await fetch(event.target.action, {
                            method: 'POST',
                            body: formData,
                        });
                        const data = await response.json();

                        if (response.ok) {
                            Swal.fire('Success', data.message, 'success').then(() => {
                                window.location.href = '<?= base_url('main/materials') ?>';
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Error',
                                text: `Request failed: ${data.message}`,
                            });
                        }
                    } catch (error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: `Request failed: ${error.message}`,
                        });
                    }
                } else {
                    Swal.fire('Cancelled', 'The IM will not be saved.', 'info');
                }
            }

            async function handleFormSubmit1(event) {
                event.preventDefault();

                // Check if there are questions available
                const questionsAvailable = <?= json_encode(isset($questionsByMaterial[$material['id']]) && !empty($questionsByMaterial[$material['id']])) ?>;

                 // Check if the user has answered the assessment only if questions are available
                if (questionsAvailable && !<?= json_encode($hasAnswered) ?>) {
                    Swal.fire({
                        icon: 'warning',
                        title: 'Assessment Required',
                        text: 'You need to finish the assessment before saving this to the virtual drive.',
                    });
                    return; // Exit the function if they haven't completed the assessment
                }

                const formData = new FormData(event.target);

                const { value: wantToSave1 } = await Swal.fire({
                    title: 'Save to Virtual Drive?',
                    text: 'Do you want to save this IM to your Virtual Drive?',
                    icon: 'question',
                    showCancelButton: true,
                    confirmButtonText: 'Yes',
                    cancelButtonText: 'No',
                });

                if (wantToSave1) {
                    try {
                        const response = await fetch(event.target.action, {
                            method: 'POST',
                            body: formData,
                        });
                        const data = await response.json();

                        if (response.ok) {
                            Swal.fire('Success', data.message, 'success').then(() => {
                                window.location.href = '<?= base_url('main/materials') ?>';
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Error',
                                text: `Request failed: ${data.message}`,
                            });
                        }
                    } catch (error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: `Request failed: ${error.message}`,
                        });
                    }
                } else {
                    Swal.fire('Cancelled', 'The IM will not be saved.', 'info');
                }
            }

            function showForm(materialId) {
                Swal.fire({
                    html: `
                        <div class="flex flex-col gap-5">
                            <p class="font-semibold text-3xl text-black">Assessment</p>
                            <form id="assessment-form" action="/main/materials/assessment" method="POST" class="flex flex-col space-y-4 px-10">
                                <input type="hidden" name="materials_id" value="${materialId}">
                                <?php if (isset($questionsByMaterial[$material['id']])): ?>
                                    <?php 
                                    $questionCount = 0; // Counter for questions
                                    foreach ($questionsByMaterial[$material['id']] as $index => $question): 
                                        if ($questionCount >= 3) break; // Stop after 3 questions
                                        $questionCount++;
                                    ?>
                                        <div class="question-group border border-neutral px-5 py-3">
                                            <div class="flex flex-col gap-2 w-full">
                                                <label class="font-semibold text-lg">Question <?= $questionCount ?></label>
                                                <span class="font-semibold text-xl text-center italic mb-4">"<?= esc($question['question_text']) ?>"</span>
                                            </div>
                                            <div class="flex flex-col gap-2 w-full">
                                                <div class="flex flex-col gap-2">
                                                    <?php if (isset($optionsByQuestion[$question['id']])): ?>
                                                        <?php foreach ($optionsByQuestion[$question['id']] as $optionIndex => $option): ?>
                                                            <div class="flex items-center gap-2">
                                                                <input 
                                                                    type="radio" 
                                                                    name="answer[<?= esc($question['id']) ?>]" 
                                                                    value="<?= esc($option['option_text']) ?>" 
                                                                    required
                                                                >
                                                                <span><?= esc($option['option_text']) ?></span>
                                                            </div>
                                                        <?php endforeach; ?>
                                                    <?php else: ?>
                                                        <span class="font-semibold text-lg text-center">No options available for this question.</span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <span class="font-semibold text-lg text-center">No questions available for this material.</span>
                                <?php endif; ?>
                            </form>
                        </div>
                    `,
                    confirmButtonText: "Submit",
                    customClass: {
                        confirmButton: "w-[250px] inline-flex justify-center rounded-full border border-transparent shadow-sm px-4 py-2 text-base bg-[#1ED300] text-white",
                    },
                    buttonsStyling: false,
                    preConfirm: () => {
                        const form = document.getElementById('assessment-form');
                        const formData = new FormData(form);
                        const answers = {};

                        // Capture the selected answers
                        <?php if (isset($questionsByMaterial[$material['id']])): ?>
                            <?php 
                            foreach ($questionsByMaterial[$material['id']] as $index => $question): 
                                if ($index >= 3) break; // Only process the first 3 questions
                            ?>
                                answers['answer<?= $index + 1 ?>'] = formData.get('answer[<?= esc($question['id'] ) ?>]') || '';
                            <?php endforeach; ?>
                        <?php endif; ?>

                        // Append the answers to FormData
                        for (let key in answers) {
                            formData.append(key, answers[key]);
                        }

                        return fetch(form.action, {
                            method: 'POST',
                            body: formData,
                        }).then(response => {
                            if (!response.ok) {
                                return response.text().then(text => { throw new Error(text); });
                            } else {
                                return response.json();
                            }
                        }).then(data => {
                            Swal.fire('Success', data.message, 'success').then(() => {
                                window.location.href = '/main/materials';
                            });
                        }).catch(error => {
                            Swal.showValidationMessage(`Request failed: ${error.message}`);
                        });
                    }
                });
            }

            function showAlert() {
                Swal.fire({
                    icon: 'warning',
                    title: 'Already Done!',
                    text: 'You have already completed this assessment.',
                });
            }

</script>


<?php $this->endSection(); ?>