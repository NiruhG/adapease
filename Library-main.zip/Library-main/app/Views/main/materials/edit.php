<?php

$this->extend('layout/layout');
$this->section('body');

?>
<div class="relative h-full">
    <div class="flex flex-col mt-5 gap-5 items-center ">
        <p class="font-semibold text-3xl text-black">Edit IM's</p>
            <form 
                id="material-form"
                action="/main/materials/update/<?= $materials['id'] ?>"
                method="POST"
                class="flex flex-col space-y-4 px-10 py-5 w-[35%]  shadow-lg bg-white z-10"
                onsubmit="return handleFormSubmit(event)"
            >
                <div class="flex flex-col items-center">
                    <img
                            src="<?= base_url('images/book.png'); ?>" 
                            alt="Material"
                            class="h-20 w-20 object-cover border border-gray-300"
                        >
                </div>
                <div class="flex items-center">
                    <i class="fa-solid fa-book text-2xl text-black p-2"></i>
                    <input type="text" id="title" name="title" value="<?= $materials['title'] ?>" class="h-10 w-full px-5 border border-black " placeholder="Enter Title">
                 </div>
                <div class="flex items-center">
                    <i class="fa-solid fa-at text-[22px] text-black p-2"></i>
                    <input  type="text" id="author" name="author" value="<?= $materials['author'] ?>" class="h-10 w-full px-5 border border-black" placeholder="Enter Author">
                </div>
                <div class="flex items-center ">
                    <i class="fas fa-book-open text-[20px] text-black p-2"></i>
                    <input type="text" id="subject" name="subject" value="<?= $materials['subject'] ?>" class="h-10 w-full px-5 border border-black" placeholder="Enter Subject">
                </div>
                <div class="flex items-center">
                    <i class="fa fa-building text-[30px] text-black p-2"></i>
                    <select id="college" name="college" class="h-10 w-full px-5 border border-black">
                        <option value="" disabled <?= empty($materials['college']) ? 'selected' : ''; ?>>Select a department</option>
                        <?php foreach ($colleges as $college): ?>
                            <option value="<?= esc($college['name']); ?>" <?= esc($college['name']) === esc($materials['college']) ? 'selected' : ''; ?>>
                                <?= esc($college['name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="flex items-center">
                    <i class="fas fa-graduation-cap text-[18px] text-black p-2"></i>
                    <select id="course" name="course" class="h-10 w-full px-5 border border-black">
                        <option value="" disabled <?= empty($materials['course']) ? 'selected' : ''; ?>>Select a course</option>
                        <?php foreach ($courses as $course): ?>
                            <option value="<?= esc($course['course_name']); ?>" <?= esc($course['course_name']) === esc($materials['course']) ? 'selected' : ''; ?>>
                                <?= esc($course['course_name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="flex flex-row gap-2 items-center">
                    <i class="fa-solid fa-file text-[22px] text-black p-2"></i>
                    <input 
                        type="file" 
                        id="file" 
                        name="courseFile" 
                        accept="application/pdf" 
                        class="border border-black p-1 w-full"
                        
                    >
                    
                </div>
                <div class="flex flex-col items-center">
                    <?php if (!empty($materials['file'])): ?>
                            <a 
                                href="<?= base_url('uploads/' . $materials['file']) ?>" target="_blank"
                                class="w-[250px] flex justify-center rounded-full border border-transparent shadow-sm px-4 py-2 text-base  bg-[#d30051] text-white"
                            >
                                View current file
                            </a>
                    <?php endif; ?>
                </div>
                
                <div class="flex flex-col gap-2 items-center">
                    <button type="submit" class="w-[250px] flex justify-center rounded-full border border-transparent shadow-sm px-4 py-2 text-base  bg-[#1ED300] text-white">
                        Update IM's
                    </button>
                    <a  
                        href="<?= base_url('main/materials') ?>" 
                        class="w-[250px] flex justify-center rounded-full border border-transparent shadow-sm px-4 py-2 text-base  bg-[#0267FF] text-white">
                        Back
                    </a>
                </div>
            </form>
    <div>
    <img 
        src="<?php echo base_url('images/bgMain.png'); ?>" 
        alt="Logo" 
        class="h-[500px] absolute left-[25%] bottom-28 opacity-40 "
    > 
</div>
<script>
    async function handleFormSubmit(event) {
        event.preventDefault(); 

        const formData = new FormData(event.target);

        try {
            const response = await fetch(event.target.action, {
                method: 'POST',
                body: formData,
            });
            const data = await response.json();

            if (response.ok) {
                Swal.fire('Success', data.message, 'success').then(() => {
                window.location.href = '<?= base_url('main/materials') ?>';
            });
            } else {
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: `Request failed: ${data.message}`,
                });
            }
        } catch (error) {
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: `Request failed: ${error.message}`,
            });
        }
    }
</script>
<?php $this->endSection(); ?>