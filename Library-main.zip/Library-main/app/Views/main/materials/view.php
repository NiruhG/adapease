<?php

$this->extend('layout/layout');
$this->section('body');

?>
<div class="relative h-full">
    <div class="flex flex-col mt-5 gap-5 items-center ">
        <p class="font-semibold text-3xl text-black">View IM's Details</p>
        <button 
                onclick="toggleFullScreen()" 
                class="bg-gray-800 text-white px-3 py-1 text-sm rounded"
            >
                    Fullscreen the Content
            </button>
            <form 
                id="material-form"
                action="/main/materials/delete/<?= $materials['id'] ?>"
                method="POST"
                enctype="multipart/form-data"
                class="relative flex flex-col space-y-4 px-10 py-5 w-[50%]  shadow-lg bg-white z-10"
            >
                <div class="flex flex-col gap-2 items-center">
                        <img
                            src="<?= base_url('images/book.png'); ?>" 
                            alt="Material"
                            class="h-20 w-20 object-cover border border-gray-300"
                        >
                </div>
                <div class="flex items-center">
                    <i class="fa-solid fa-book text-2xl text-black p-2"></i>
                    <input disabled type="text" id="title" name="title" value="<?= $materials['title'] ?>" class="h-10 w-full px-5 border border-black " placeholder="Enter Title">
                 </div>
                <div class="flex items-center">
                    <i class="fa-solid fa-at text-[22px] text-black p-2"></i>
                    <input disabled type="text" id="author" name="author" value="<?= $materials['author'] ?>" class="h-10 w-full px-5 border border-black" placeholder="Enter Author">
                </div>
                <div class="flex items-center relative">
                    <i class="fas fa-book-open text-[20px] text-black p-2"></i>
                    <input disabled type="text" id="subject" name="subject"  value="<?= $materials['subject'] ?>" class="h-10 w-full px-5 border border-black" placeholder="Enter Subject">
                </div>
                <div class="flex  relative">
                    <i class="fa fa-building text-[30px] text-black p-2"></i>
                    <input disabled type="text" id="college" name="college"  value="<?= $materials['college'] ?>" class="h-10 w-full px-5 border border-black" placeholder="Enter Course">
                </div>
                <div class="flex  relative">
                    <i class="fas fa-graduation-cap text-[18px] text-black p-2"></i>
                    <input disabled type="text" id="course" name="course"  value="<?= $materials['course'] ?>" class="h-10 w-full px-5 border border-black" placeholder="Enter Course">
                </div>
                <div class="flex flex-row gap-2 items-center">
                    <i class="fa-solid fa-file text-[22px] text-black p-2"></i>
                    <div id="pdfContainer" class="relative">
                        <embed
                            id="pdfEmbed"
                            type="application/pdf"
                            src="/uploads/<?= $materials['file'] ?>"
                            alt="File"
                            width="480"
                            height="300"
                        >
                    </div>
                </div>
                
                <div class="flex flex-col gap-2 items-center">
                    <button type="button" onclick="confirmDelete()" class="w-[250px] flex justify-center rounded-full border border-transparent shadow-sm px-4 py-2 text-base bg-[#FF2001] text-white">
                        Delete Material
                    </button>
                    <a  
                        href="<?= base_url('main/materials') ?>" 
                        class="w-[250px] flex justify-center rounded-full border border-transparent shadow-sm px-4 py-2 text-base  bg-[#0267FF] text-white">
                        Back
                    </a>
                </div>
            </form>
            
    <div>
    <img 
        src="<?php echo base_url('images/bgMain.png'); ?>" 
        alt="Logo" 
        class="h-[500px] absolute left-[25%] bottom-28 opacity-40 "
    > 
</div>
<script>
    function confirmDelete() {
        Swal.fire({
            title: 'Are you sure?',
            text: "This will delete the instructional material permanently!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#FF2001',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes',
            cancelButtonText: 'No',
        }).then((result) => {
            if (result.isConfirmed) {
                // Perform the deletion
                deleteMaterial();
            }
        });
    }

    function deleteMaterial() {
        const form = document.getElementById('material-form');
        
        fetch(form.action, {
            method: 'POST',
            body: new FormData(form)
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                Swal.fire('Success', data.message, 'success').then(() => {
                    window.location.href = '<?= base_url('main/materials') ?>'; // Redirect after success
                });
            } else {
                Swal.fire('Error', data.message, 'error');
            }
        })
        .catch(error => {
            Swal.showValidationMessage(`Request failed: ${error.message}`);
        });
    }
    function toggleFullScreen() {
        const pdfContainer = document.getElementById("pdfContainer");
        const pdfEmbed = document.getElementById("pdfEmbed");

        if (!document.fullscreenElement) {
            pdfContainer.style.width = "100%";
            pdfContainer.style.height = "100%";
            pdfEmbed.style.width = "100%";
            pdfEmbed.style.height = "100%";

            pdfContainer.requestFullscreen().catch(err => {
                alert(`Error attempting to enable full-screen mode: ${err.message}`);
            });
        } else {
            document.exitFullscreen().then(() => {
                pdfContainer.style.width = "480px";  
                pdfContainer.style.height = "300px"; 
                pdfEmbed.style.width = "480px";     
                pdfEmbed.style.height = "300px";   
            });
        }
    }

</script>

<?php $this->endSection(); ?>