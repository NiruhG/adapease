<?php

$this->extend('layout/layout');
$this->section('body');

?>  
<div class="relative">
    <div class="flex justify-evenly pt-20 px-20 w-full ">
        <form 
                id="student-form"
                action="/main/profile/update/<?= $user['id'] ?>"
                method="POST"
                enctype="multipart/form-data"
                class="flex flex-col space-y-4 px-10 py-5 w-[40%]  shadow-lg bg-white z-10"
                onsubmit="return handleFormSubmit(event)"
            >
                <div class="flex flex-col gap-2 items-center">
                    <label for="profile" class="cursor-pointer">
                        <img
                            id="image-preview"
                            src="<?php 
                                if (!empty($user['profile'])) {
                                    echo base_url('uploads/' . $user['profile']);
                                } else {
                                    switch ($user['role'] ?? 'guest') {
                                        case 'student':
                                            echo base_url('images/student.png');
                                            break;
                                        case 'instructor':
                                            echo base_url('images/teacher.png');
                                            break;
                                        case 'admin':
                                            echo base_url('images/admin.png');
                                            break;
                                        default:
                                            echo base_url('images/guest.png');
                                    }
                                }
                            ?>"
                            alt="profile"
                            class="h-28 w-28 object-cover border border-gray-300"
                        >
                    </label>
                    <input 
                        type="file" 
                        id="profile" 
                        name="userProfile" 
                        accept="image/png, image/jpeg, image/jpg" 
                        class="hidden" 
                        onchange="previewImage(event)"
                    >
                </div>
                <div class="flex flex-row gap-12 items-center">
                    <span class="font-semibold text-base whitespace-nowrap">Email: </span>
                    <input 
                        type="text" 
                        id="email" 
                        name="email" 
                        value="<?= !empty($user['email']) ? 
                        $user['email'] :
                        '' ?>" 
                        class="h-10 w-full px-5 border border-black " 
                        placeholder="Enter Email"
                    >
                </div>
                <div class="flex flex-row gap-[18px] items-center">
                    <span class="font-semibold text-base whitespace-nowrap">Password: </span>
                    <input 
                        type="text" 
                        id="password" 
                        name="password" 
                        value="<?= !empty($user['password']) ? '********' : 'No password set' ?>"
                        class="h-10 w-full px-5 border border-black " 
                        placeholder="Enter Password"
                    >
                </div>
                <div class="flex flex-row gap-2 items-center">
                    <span class="font-semibold text-base whitespace-nowrap">First Name: </span>
                    <input 
                        type="text" 
                        id="first_name" 
                        name="firstName" 
                        value="<?= !empty($user['first_name']) ? 
                        $user['first_name'] :
                        '' ?>" 
                        class="h-10 w-full px-5 border border-black " 
                        placeholder="Enter First Name"
                    >
                </div>
                <div class="flex flex-row gap-[10px] items-center">
                    <span class="font-semibold text-base whitespace-nowrap">Last Name: </span>
                    <input 
                        type="text" 
                        id="last_name" 
                        name="lastName" 
                        value="<?= !empty($user['last_name']) ? 
                        $user['last_name'] :
                        '' ?>" 
                        class="h-10 w-full px-5 border border-black " 
                        placeholder="Enter Last Name"
                    >
                </div>
                <button type="submit" class="w-full flex justify-center rounded-full border border-transparent shadow-sm px-4 py-2 text-base  bg-[#1ED300] text-white">
                    Update Profile
                </button>
            </form>
        
    </div>
    <img 
        src="<?php echo base_url('images/bgMain.png'); ?>" 
        alt="Logo" 
        class="h-[500px] absolute left-[25%] top-[30%] opacity-40"
    > 
</div>
<script>
    function previewImage(event) {
        const file = event.target.files[0];
        const preview = document.getElementById('image-preview');

        if (file && (file.type === 'image/png' || file.type === 'image/jpeg' || file.type === 'image/jpg')) {
            const reader = new FileReader();
            
            reader.onload = function(e) {
                preview.src = e.target.result; 
            };
            
            reader.readAsDataURL(file);
        }
    }
    async function handleFormSubmit(event) {
        event.preventDefault(); 

        const formData = new FormData(event.target);

        try {
            const response = await fetch(event.target.action, {
                method: 'POST',
                body: formData,
            });
            const data = await response.json();

            if (response.ok) {
                Swal.fire('Success', data.message, 'success').then(() => {
                window.location.href = '<?= base_url('main/profile') ?>';
            });
            } else {
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: `Request failed: ${data.message}`,
                });
            }
        } catch (error) {
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: `Request failed: ${error.message}`,
            });
        }
    }
</script>

<?php $this->endSection(); ?>