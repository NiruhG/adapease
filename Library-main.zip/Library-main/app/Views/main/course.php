<?php

$this->extend('layout/layout');
$this->section('body');

?>
<div class="relative">
    <div class="flex flex-col gap-20 pt-10 px-20 w-full z-10">
        <div class="flex justify-between items-center ">
            <span></span>
            <p class="font-semibold text-xl">List of Courses</p>
            <button 
                onclick="showForm()"
                class="text-white flex flex-row gap-1 bg-[#1ED300] items-center p-1"
            >
                <i class="fa-solid fa-circle-plus text-white" ></i>
                <p class=" text-xl">Create Courses</p>
            </button>
        </div>
        <div class="grid grid-rows-4 grid-cols-4 gap-5 z-10">
            <?php foreach ($courses as $course): ?>
                <div class="shadow-xl flex flex-col  items-center py-5 px-10 w-48 bg-white">
                    <img
                        src="/uploads/<?= $course['profile']?>"
                        alt="Course"
                        class="h-28 w-28"
                    >
                    <span class="font-semibold text-lg underline"><?= $course['course_name'] ?></span>
                    <span class="text-xs font-semibold mb-2">Course Name</span>
                    <div class="flex flex-row w-full  justify-between">
                        <a 
                            href="/main/course/view/<?= $course['id'] ?>"
                            class="fa-solid fa-eye text-md"
                        >
                        </a>
                        <a 
                            href="/main/course/edit/<?= $course['id'] ?>"
                            class="fa-solid fa-pen-to-square text-md"
                        >
                        </a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
    <img 
        src="<?php echo base_url('images/bgMain.png'); ?>" 
        alt="Logo" 
        class="h-[400px] absolute left-[30%] top-36 opacity-40 "
    > 
</div>

 <script>
        function showForm() {
            Swal.fire({
                html: `
                    <div class="flex flex-col gap-5">
                        <p class="font-semibold text-3xl text-black">Add Course</p>
                        <form 
                            id="course-form"
                            action="/main/course"
                            method="POST"
                            enctype="multipart/form-data"
                            class="flex flex-col space-y-4 px-10"
                        >
                            <div class="flex flex-col gap-2 items-center">
                                <img id="image-preview" class="hidden w-40 h-40 object-cover border border-gray-300">
                                <p class="text-black ">Logo</p>
                                <input type="file" id="profile" name="courseProfile" accept="image/png, image/jpeg, image/jpg" class="border border-black p-1 w-full" onchange="previewImage(event)">
                                <div id="profile_error" class="text-red-500 text-sm hidden">*Profile image is required</div>
                            </div>
                            <div class="flex flex-col gap-2 items-center">
                                 <div class="flex w-full items-center">
                                    <img src="<?php echo base_url('images/course1.png') ?>" class="h-10 w-10">
                                    <input type="text" id="course_name" name="courseName" class="h-10 w-full px-5 border border-black border-l-0" placeholder="Enter Course Fullname">
                                    
                                </div>
                                <div id="course_name_error" class="text-red-500 text-sm hidden">*Course Fullname is required</div>
                            </div>
                            <div class="flex flex-col gap-2 items-center">
                                <div class="flex items-center w-full">
                                    <img src="<?php echo base_url('images/course1.png') ?>" class="h-10 w-10">
                                    <input type="text" id="course_abbre" name="courseAbbre" class="h-10 w-full px-5 border border-black border-l-0" placeholder="Enter Course Abbreviation">
                                </div>
                              <div id="course_abbre_error" class="text-red-500 text-sm hidden">*Course Abbreviation is required</div>
                            </div>
                            <div class="flex flex-col gap-2 items-center">
                                <div class="flex items-center w-full relative">
                                    <img src="<?php echo base_url('images/date.png') ?>" class="h-10 w-10 p-2 border border-black bg-[#d9d9d9]">
                                    <img 
                                        src="<?php echo base_url('images/sched.png') ?>"
                                        class="absolute left-3 h-2"
                                    >
                                    <input type="text" id="schedule" name="courseSchedule" class="h-10 w-full px-5 border border-black" placeholder="Enter Course Schedule">
                                </div>
                                <div id="schedule_error" class="text-red-500 text-sm hidden">*Course Schedule is required</div>
                            </div>
                            <div class="flex flex-col gap-2">
                                <div class="flex items-start w-full relative">
                                    <img src="<?php echo base_url('images/desc.png') ?>" class="h-10 w-11 p-2 bg-[#d9d9d9] border border-black">
                                    <textarea id="description" name="courseDescription" class="h-32 w-full px-5 pt-2 border border-black resize-none" placeholder="Enter Course Description"></textarea>
                                    <img 
                                        src="<?php echo base_url('images/side.png') ?>"
                                        class="absolute left-2 top-[14px] h-3"
                                    >
                                    <i class="fa-solid fa-plus text-xs font-bold text-black absolute h-2 left-[14px] top-[12px]" ></i>  
                                </div>
                                <div id="description_error" class="text-red-500 text-sm hidden">*Course Description is required</div>
                            </div>
                        </form>
                    </div>
                `,
                confirmButtonText: "Add Course",
                customClass: {
                    confirmButton: "w-[250px] inline-flex justify-center rounded-full border border-transparent shadow-sm px-4 py-2 text-base bg-[#1ED300] text-white",
                },
                buttonsStyling: false,
                preConfirm: () => {
                    const courseName = document.getElementById('course_name').value.trim();
                    const courseAbbre = document.getElementById('course_abbre').value.trim();
                    const schedule = document.getElementById('schedule').value.trim();
                    const description = document.getElementById('description').value.trim();
                    const profile = document.getElementById('profile').files.length === 0;

                    document.getElementById('profile_error').classList.add('hidden');
                    document.getElementById('course_name_error').classList.add('hidden');
                    document.getElementById('course_abbre_error').classList.add('hidden');
                    document.getElementById('schedule_error').classList.add('hidden');
                    document.getElementById('description_error').classList.add('hidden');
                   

                    let isValid = true;
                    if (profile) {
                        document.getElementById('profile_error').classList.remove('hidden');
                        isValid = false;
                    }
                    if (!courseName) {
                        document.getElementById('course_name_error').classList.remove('hidden');
                        isValid = false;
                    }
                    if (!courseAbbre) {
                        document.getElementById('course_abbre_error').classList.remove('hidden');
                        isValid = false;
                    }
                    if (!schedule) {
                        document.getElementById('schedule_error').classList.remove('hidden');
                        isValid = false;
                    }
                    if (!description) {
                        document.getElementById('description_error').classList.remove('hidden');
                        isValid = false;
                    }

                    if (!isValid) {
                        Swal.showValidationMessage('Please fill in all required fields.');
                        return false; 
                    }

                    const form = document.getElementById('course-form');
                    const formData = new FormData(form);

                    return fetch(form.action, {
                        method: 'POST',
                        body: formData,
                    }).then(response => {
                        if (!response.ok) {
                            return response.text().then(text => { throw new Error(text); });
                        }
                        return response.json();
                    }).then(data => {
                        Swal.fire('Success', data.message, 'success').then(() => {
                            window.location.href = 'main/course';
                        });
                    }).catch(error => {
                        Swal.showValidationMessage(`Request failed: ${error.message}`);
                    });
                }
            });
        }

        function previewImage(event) {
            const file = event.target.files[0];
            const preview = document.getElementById('image-preview');
            
            if (file && (file.type === 'image/png' || file.type === 'image/jpeg' || file.type === 'image/jpg')) {
                const reader = new FileReader();
                
                reader.onload = function(e) {
                    preview.src = e.target.result;
                    preview.classList.remove('hidden'); // Show the image preview
                };
                
                reader.readAsDataURL(file);
            } else {
                preview.src = '';
                preview.classList.add('hidden'); // Hide the image preview if not valid
            }
        }

    </script>

<?php $this->endSection(); ?>