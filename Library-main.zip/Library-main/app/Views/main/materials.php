<?php

$this->extend('layout/layout');
$this->section('body');

?>
<div class="relative">
    <div class="flex flex-col gap-20 pt-10 px-20 w-full z-10">
            <?php if ($role === 'admin') : ?>
                <div class="flex flex-col gap-5 z-10">
                    <div class="flex justify-between items-center ">
                        <span></span>
                        <p class="font-semibold text-xl">List of Instructional Materials</p>
                        <button 
                            onclick="showForm()"
                            class="text-white flex flex-row gap-1 bg-[#1ED300] items-center p-2"
                        >
                            <i class="fa-solid fa-circle-plus text-white"></i>
                            <p class="text-xl">Create Materials</p>
                        </button>
                    </div>
                    <div class="relative inline-block text-left z-20">
                        <button
                            id="filterButton"
                            class="inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-sm font-medium text-gray-700 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                            onclick="toggleDropdown1()"
                        >

                            <i class="fa-solid fa-filter text-lg"></i>
                        </button>
                        <div id="dropdownMenu1" class=" hidden absolute left-0 mt-2 w-72 bg-white rounded-md shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none">
                            <form action="/main/materials/searchFilter" method="GET">
                                <div class="p-4 space-y-4">
                                    <div>
                                        <label for="college" class="block text-sm font-medium text-gray-700">Department:</label>
                                        <select
                                            id="college"
                                            name="college"
                                            class="block w-full mt-1 p-2 border border-gray-300 rounded-md text-sm shadow-sm focus:ring focus:ring-indigo-300"
                                        >
                                            <option value="">-- Select Department --</option>
                                            <option value="College of Computing in Information Sciences">College of Computing in Information Sciences</option>
                                            <option value="College of Engineering in Information Technology">College of Engineering in Information Technology</option>
                                            <option value="College of Agriculture">College of Agriculture</option>
                                            <option value="College of Education">College of Education</option>
                                            <option value="College of Arts and Science">College of Arts and Science</option>
                                        </select>
                                    </div>
                                    <div>
                                        <label for="course" class="block text-sm font-medium text-gray-700">Course:</label>
                                        <select
                                            id="course"
                                            name="course"
                                            class="block w-full mt-1 p-2 border border-gray-300 rounded-md text-sm shadow-sm focus:ring focus:ring-indigo-300"
                                        >
                                            <option value="">-- Select Course --</option>
                                            <?php foreach ($courses as $course): ?>
                                                <option value="<?= esc($course['course_name']); ?>"><?= esc($course['course_name']); ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    <div>
                                        <label for="subject" class="block text-sm font-medium text-gray-700">Course:</label>
                                        <select
                                            id="subject"
                                            name="subject"
                                            class="block w-full mt-1 p-2 border border-gray-300 rounded-md text-sm shadow-sm focus:ring focus:ring-indigo-300"
                                        >
                                            <option value="">-- Select Subject --</option>
                                            <?php foreach ($subjects as $subject): ?>
                                                <option value="<?= esc($subject['subject']); ?>"><?= esc($subject['subject']); ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    <div class="text-right">
                                        <button
                                            type="submit"
                                            class="inline-flex justify-center px-4 py-2 bg-[#1ED300] text-white text-sm font-medium rounded-md shadow-sm hover:bg-[#17b000]"
                                        >
                                            Apply
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            <?php elseif ($role === 'instructor') : ?>
                <div class="flex flex-col gap-2">
                    <div class="flex justify-between items-center z-10">
                        <span></span>
                        <p class="font-semibold text-xl">List of Instructional Materials</p>
                        <button 
                            onclick="showForm()"
                            class="text-white flex flex-row gap-1 bg-[#1ED300] items-center p-1"
                        >
                            <i class="fa-solid fa-circle-plus text-white"></i>
                            <p class="text-xl">Create Materials</p>
                        </button>
                    </div>
                    <div class="relative inline-block text-left z-20">
                            <button
                                id="filterButton"
                                class="inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-sm font-medium text-gray-700 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                                onclick="toggleDropdown1()"
                            >

                                <i class="fa-solid fa-filter text-lg"></i>
                            </button>
                            <div id="dropdownMenu1" class=" hidden absolute left-0 mt-2 w-72 bg-white rounded-md shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none">
                                <form action="/main/materials/searchFilter" method="GET">
                                    <div class="p-4 space-y-4">
                                        <div>
                                            <label for="course" class="block text-sm font-medium text-gray-700">Course:</label>
                                            <select
                                                id="course"
                                                name="course"
                                                class="block w-full mt-1 p-2 border border-gray-300 rounded-md text-sm shadow-sm focus:ring focus:ring-indigo-300"
                                            >
                                                <option value="">-- Select Course --</option>
                                                <?php foreach ($courses as $course): ?>
                                                    <option value="<?= esc($course['course_name']); ?>"><?= esc($course['course_name']); ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                        <div>
                                            <label for="subject" class="block text-sm font-medium text-gray-700">Subject:</label>
                                            <select
                                                id="subject"
                                                name="subject"
                                                class="block w-full mt-1 p-2 border border-gray-300 rounded-md text-sm shadow-sm focus:ring focus:ring-indigo-300"
                                            >
                                                <option value="">-- Select Subject --</option>
                                                <?php foreach ($subjects as $subject): ?>
                                                    <option value="<?= esc($subject['subject']); ?>"><?= esc($subject['subject']); ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                        <div class="text-right">
                                            <button
                                                type="submit"
                                                class="inline-flex justify-center px-4 py-2 bg-[#1ED300] text-white text-sm font-medium rounded-md shadow-sm hover:bg-[#17b000]"
                                            >
                                                Apply
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                    </div>
                </div>
            <?php elseif ($role === 'student') : ?>
                <div class="flex flex-col gap-5">
                    <form action="/main/materials/search" method="GET">
                        <div class="flex relative">
                            <input 
                                type="search"
                                name="search"
                                class="rounded-full border border-black w-full pl-5 pr-12 py-3"
                                placeholder="Search by title..."
                                disabled
                            >
                            <button type="submit" disabled class="absolute right-5 top-[10%] bg-transparent border-none">
                                <i class="fa-solid fa-magnifying-glass text-3xl"></i>
                            </button>
                        </div>
                    </form>
                    <div class="relative inline-block text-left z-20">
                        <button
                            id="filterButton"
                            class="inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-sm font-medium text-gray-700 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                            onclick="toggleDropdown1()"
                            disabled
                        >

                            <i class="fa-solid fa-filter text-lg"></i>
                        </button>
                        <div id="dropdownMenu1" class=" hidden absolute left-0 mt-2 w-72 bg-white rounded-md shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none">
                            <form action="/main/materials/searchFilter" method="GET">
                                <div class="p-4 space-y-4">
                                    <div>
                                        <label for="course" class="block text-sm font-medium text-gray-700">Course:</label>
                                        <select
                                            id="course"
                                            name="course"
                                            class="block w-full mt-1 p-2 border border-gray-300 rounded-md text-sm shadow-sm focus:ring focus:ring-indigo-300"
                                        >
                                            <option value="">-- Select Course --</option>
                                            <?php foreach ($courses as $course): ?>
                                                <option value="<?= esc($course['course_name']); ?>"><?= esc($course['course_name']); ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    <div>
                                        <label for="subject" class="block text-sm font-medium text-gray-700">Course:</label>
                                        <select
                                            id="subject"
                                            name="subject"
                                            class="block w-full mt-1 p-2 border border-gray-300 rounded-md text-sm shadow-sm focus:ring focus:ring-indigo-300"
                                        >
                                            <option value="">-- Select Subject --</option>
                                            <?php foreach ($subjects as $subject): ?>
                                                <option value="<?= esc($subject['subject']); ?>"><?= esc($subject['subject']); ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    <div class="text-right">
                                        <button
                                            type="submit"
                                            class="inline-flex justify-center px-4 py-2 bg-[#1ED300] text-white text-sm font-medium rounded-md shadow-sm hover:bg-[#17b000]"
                                        >
                                            Apply
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                
            <?php endif; ?>
            <div class="grid grid-rows-4 grid-cols-4 gap-5 z-10">
                <?php foreach ($materials as $material): ?>
                    <?php if ($role === 'admin') : ?>
                        <div class="shadow-xl flex flex-col gap-1 items-center py-5 px-10 w-48 bg-white">
                            <img
                                src="<?= base_url('images/book.png'); ?>" 
                                alt="Material"
                                class="h-20 w-20"
                            >
                            <span class="font-semibold text-lg text-center"><?= esc($material['title']) ?></span>
                            <div class="flex flex-row w-full justify-between">
                                <a 
                                    href="/main/materials/view/<?= esc($material['id']) ?>"
                                    class="fa-solid fa-eye text-md"
                                >
                                </a>
                                <a 
                                    href="/main/materials/edit/<?= esc($material['id']) ?>"
                                    class="fa-solid fa-pen-to-square text-md"
                                >
                                </a>
                                <?php if ($material['status'] == 1) : ?>
                                    <i
                                        onclick="addStudent()" 
                                        class="fa-solid fa-graduation-cap text-md cursor-pointer">
                                    </i>
                                <?php endif; ?>
                            </div>
                            <?php if ($material['status'] == 0) : ?>
                                <button
                                    onclick="updateStatus1(<?= esc($material['id']) ?>)"  
                                    class="mt-3 w-[160px] flex justify-center whitespace-nowrap rounded-full border border-transparent shadow-sm p-2 text-sm  bg-[#1ED300] text-white"
                                >
                                    Click to Approve
                                </button>
                            <?php elseif ($material['status'] == 1) : ?>
                                <button
                                    onclick="updateStatus2(<?= esc($material['id']) ?>)"
                                    class="mt-3 w-[160px] flex justify-center whitespace-nowrap rounded-full border border-transparent shadow-sm p-2 text-sm  bg-[#FF4500] text-white"
                                >
                                    Click to Archive
                                </button>
                            <?php elseif ($material['status'] == 2) : ?>
                                <button
                                    onclick="updateStatus1(<?= esc($material['id']) ?>)"
                                    class="mt-3 w-[160px] flex justify-center whitespace-nowrap rounded-full border border-transparent shadow-sm p-2 text-sm  bg-[#d30051] text-white"
                                >
                                    Click to Unarchive
                                </button>
                            <?php endif; ?>
                        </div>
                    <?php elseif ($role === 'instructor') : ?>
                        <div class="shadow-xl flex flex-col gap-1 items-center py-5 px-10 w-48 bg-white">
                            <img
                                src="<?= base_url('images/book.png'); ?>" 
                                alt="Material"
                                class="h-20 w-20"
                            >
                            <span class="font-semibold text-lg text-center"><?= esc($material['title']) ?></span>
                            <?php if ($material['status'] == 0) : ?>
                                <p class="text-xs font-semibold whitespace-nowrap">Status: Pending for Approval</p>
                            <?php elseif ($material['status'] == 1) : ?>
                                <p class="text-xs font-semibold">Status: Approved</p>
                            <?php elseif ($material['status'] == 2) : ?>
                                <p class="text-xs font-semibold">Status: Archived</p>
                            <?php endif; ?>
                            <p class="text-xs font-semibold">View Count: <?= esc($material['view_count']) ?></p>
                            <div class="flex flex-row w-full justify-between">
                                <a 
                                    href="/main/materials/view/<?= esc($material['id']) ?>"
                                    class="fa-solid fa-eye text-md"
                                >
                                </a>
                                <a 
                                    href="/main/materials/edit/<?= esc($material['id']) ?>"
                                    class="fa-solid fa-pen-to-square text-md"
                                >
                                </a>
                                <?php if ($material['status'] == 1) : ?>
                                    <i
                                        onclick="addStudent()" 
                                        class="fa-solid fa-graduation-cap text-md cursor-pointer">
                                    </i>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php elseif ($role === 'student') : ?>
                        <a
                            onclick="updateViewCount(<?= esc($material['id']) ?>)"
                            href="/main/materials/content/<?= esc($material['id']) ?>"
                        >
                        <div class="shadow-xl flex flex-col gap-1 items-center py-5 px-10 w-52 bg-white">
                            <img src="<?= base_url('images/book.png'); ?>" alt="Material" class="h-20 w-20">
                            <span class="font-semibold text-2xl text-center italic mb-4">"<?= esc($material['title']) ?>"</span>
                            <span class="font-semibold text-sm text-center ">Author: <?= esc($material['author']) ?></span>
                            <span class="font-semibold text-sm text-center ">Subject: <?= esc($material['subject']) ?></span>
                            <span class="font-semibold text-sm text-center ">Course: <?= esc($material['course']) ?></span>
                        </div>
                        </a>
                    <?php endif; ?>
                <?php endforeach; ?>
            </div>
    </div>
    <img 
        src="<?php echo base_url('images/bgMain.png'); ?>" 
        alt="Logo" 
        class="h-[400px] absolute left-[30%] top-[20%] opacity-40 "
    > 
</div>

 <script>
        function showForm() {
            Swal.fire({
                html: `
                    <div class="flex flex-col gap-5">
                        <p class="font-semibold text-3xl text-black">Add IM's</p>
                        <form id="material-form" action="/main/materials" method="POST" class="flex flex-col space-y-4 px-10">
                            <div class="flex flex-col gap-2 items-center">
                                 <div class="flex w-full items-center">
                                    <i class="fa-solid fa-book text-2xl text-black p-2"></i>
                                    <input type="text" id="title" name="title" class="h-10 w-full px-5 border border-black " placeholder="Enter Title">
                                </div>
                                <div id="title_error" class="text-red-500 text-sm hidden">*Title is required</div>
                            </div>
                            <div class="flex flex-col gap-2 items-center">
                                <div class="flex items-center w-full">
                                    <i class="fa-solid fa-at text-[22px] text-black p-2"></i>
                                    <input type="text" id="author" name="author" class="h-10 w-full px-5 border border-black " placeholder="Enter Author">
                                </div>
                              <div id="author_error" class="text-red-500 text-sm hidden">*Author is required</div>
                            </div>
                            <div class="flex flex-col gap-2 items-center">
                                <div class="flex items-center w-full">
                                    <i class="fas fa-book-open text-[20px] text-black p-2"></i>
                                    <input type="text" id="subject1" name="subject" class="h-10 w-full px-5 border border-black" placeholder="Enter Subject">
                                </div>
                                <div id="subject_error" class="text-red-500 text-sm hidden">*Subject is required</div>
                            </div>
                            <div class="flex flex-col gap-2">
                                <div class="flex items-start w-full relative">
                                    <i class="fa fa-building text-[30px] text-black p-2"></i>
                                    <select id="college" name="college" class="h-10 w-full px-5 border border-black">
                                        <option value="" disabled selected>Select a department</option>
                                        <?php foreach($colleges as $college): ?>
                                            <option value="<?= esc($college['name']); ?>"><?= esc($college['name']); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="flex flex-col gap-2">
                                <div class="flex items-start w-full relative">
                                    <i class="fas fa-graduation-cap text-[18px] text-black p-2"></i>
                                    <select id="course" name="course" class="h-10 w-full px-5 border border-black">
                                        <option value="" disabled selected>Select a course</option>
                                        <?php foreach($courses as $course): ?>
                                            <option value="<?= esc($course['course_name']); ?>"><?= esc($course['course_name']); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div id="course_error" class="text-red-500 text-sm hidden">*Course is required</div>
                            </div>
                            <div class="flex flex-row gap-2 items-center">
                                <i class="fa-solid fa-file text-[22px] text-black p-2"></i>
                                <input type="file" id="file" name="courseFile" accept="application/pdf" class="border border-black p-1 w-full" onchange="previewFile(event)">
                                <div id="file_error" class="text-red-500 text-sm hidden">*PDF File is required</div>
                            </div>
                        </form>
                    </div>
                `,
                confirmButtonText: "Add IM's",
                customClass: {
                    confirmButton: "w-[250px] inline-flex justify-center rounded-full border border-transparent shadow-sm px-4 py-2 text-base bg-[#1ED300] text-white",
                },
                buttonsStyling: false,
                preConfirm: () => {
                    const title = document.getElementById('title').value.trim();
                    const author = document.getElementById('author').value.trim();
                    const subject = document.getElementById('subject1').value.trim();
                    const file = document.getElementById('file').files.length === 0;

                    document.getElementById('file_error').classList.add('hidden');
                    document.getElementById('title_error').classList.add('hidden');
                    document.getElementById('author_error').classList.add('hidden');
                    document.getElementById('subject_error').classList.add('hidden');

                    let isValid = true;
                    if (file) {
                        document.getElementById('file_error').classList.remove('hidden');
                        isValid = false;
                    }
                    if (!title) {
                        document.getElementById('title_error').classList.remove('hidden');
                        isValid = false;
                    }
                    if (!author) {
                        document.getElementById('author_error').classList.remove('hidden');
                        isValid = false;
                    }
                    if (!subject) {
                        document.getElementById('subject_error').classList.remove('hidden');
                        isValid = false;
                    }
                    if (!isValid) {
                        Swal.showValidationMessage('Please fill in all required fields.');
                        return false; 
                    }

                    const form = document.getElementById('material-form');
                    const formData = new FormData(form);

                    return fetch(form.action, {
                        method: 'POST',
                        body: formData,
                    }).then(response => {
                        if (!response.ok) {
                            return response.text().then(text => { throw new Error(text); });
                        }
                        return response.json();
                    }).then(data => {
                        Swal.fire('Success', data.message, 'success').then(() => {
                            window.location.href = 'main/materials';
                        });
                    }).catch(error => {
                        Swal.showValidationMessage(`Request failed: ${error.message}`);
                    });
                }
            });
        }

        function addStudent() {
            Swal.fire({
                html: `
                    <div class="flex flex-col gap-5">
                        <p class="font-semibold text-3xl text-black">Add/Remove Students</p>
                        <div class="flex flex-col w-full px-10">
                            <?php foreach($emails as $email): ?>
                                <div class="flex flex-row w-full items-center gap-5 py-2 border-b border-gray-200 text-black">
                                    <input type="checkbox" id="<?= esc($email); ?>" name="emails[]" value="<?= esc($email); ?>" class="mr-2" onchange="updateDisplay()">
                                    <label for="<?= esc($email); ?>"><?= esc($email); ?></label>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        <div class="flex flex-col gap-5">
                            <div>
                                <span class="text-black text-xl">Active Students:<span>
                                <?php foreach($materials as $material): ?>
                                    <?php $emails = explode(',', $material['emails']); ?>
                                        <?php foreach($emails as $email): ?>
                                            <div class="flex flex-col gap-1 text-black text-sm">
                                                <?= esc(trim($email)); ?>
                                            <div>
                                        <?php endforeach; ?>
                                <?php endforeach; ?>
                            </div>
                            <div>
                                <p class="mt-3 text-black text-xl">Selected Students:</p>
                                <div id="display-div" class="text-black text-sm gap-1">
                                    <span id="selected-students"></span>
                                </div>
                            </div>
                        </div>
                        
                        
                    </div>
                `,
                confirmButtonText: "Update Students",
                customClass: {
                    confirmButton: "w-[250px] inline-flex justify-center rounded-full border border-transparent shadow-sm px-4 py-2 text-base bg-[#1ED300] text-white",
                },
                buttonsStyling: false,
                preConfirm: () => {
                    const checkboxes = document.querySelectorAll('input[name="emails[]"]');
                    const selectedValues = [];
                    checkboxes.forEach(checkbox => {
                        if (checkbox.checked) {
                            selectedValues.push(checkbox.value);
                        }
                    });
                    return fetch('main/materials/update/<?= $material['id']; ?>', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                        body: `emails=${selectedValues.join(',')}`,
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.status === 'success') {
                            Swal.fire({
                                title: 'Success',
                                text: data.message,
                                icon: 'success',
                                confirmButtonText: 'OK',
                            });
                            window.location.href = '/main/materials';
                        } else {
                            Swal.fire({
                                title: 'Error',
                                text: data.message,
                                icon: 'error',
                                confirmButtonText: 'OK',
                            });
                        }
                    })
                    .catch(error => console.error(error));
                },
            });
        }

        function updateDisplay() {
            const checkboxes = document.querySelectorAll('input[name="emails[]"]');
            const selectedValues = [];
            checkboxes.forEach(checkbox => {
                if (checkbox.checked) {
                    selectedValues.push(checkbox.value);
                }
            });
            document.getElementById('selected-students').innerText = selectedValues.join(', ');
        }

        function toggleDropdown1() {
            const dropdown = document.getElementById('dropdownMenu1');
            dropdown.classList.toggle('hidden');
        }

        function updateStatus1(id) {
            Swal.fire({
                title: 'Are you sure?',
                text: 'You are about to approve this material.',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, approve it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    fetch(`/main/materials/updateStatus1/${id}`, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-Requested-With': 'XMLHttpRequest',
                        },
                        body: JSON.stringify({ id: id })
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.status === 'success') {
                            Swal.fire({
                                title: 'Approved!',
                                text: data.message,
                                icon: 'success',
                            }).then(() => {
                                location.reload(); 
                            });
                        } else {
                            Swal.fire({
                                title: 'Error!',
                                text: data.message,
                                icon: 'error',
                            });
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        Swal.fire({
                            title: 'Error!',
                            text: 'An error occurred. Please try again.',
                            icon: 'error',
                        });
                    });
                }
            });
        }

        function updateStatus2(id) {
            Swal.fire({
                title: 'Are you sure?',
                text: 'You are about to archive this material.',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, archive it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    fetch(`/main/materials/updateStatus2/${id}`, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-Requested-With': 'XMLHttpRequest',
                        },
                        body: JSON.stringify({ id: id })
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.status === 'success') {
                            Swal.fire({
                                title: 'Approved!',
                                text: data.message,
                                icon: 'success',
                            }).then(() => {
                                location.reload(); 
                            });
                        } else {
                            Swal.fire({
                                title: 'Error!',
                                text: data.message,
                                icon: 'error',
                            });
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        Swal.fire({
                            title: 'Error!',
                            text: 'An error occurred. Please try again.',
                            icon: 'error',
                        });
                    });
                }
            });
        }

        function updateViewCount(materialId) {
            fetch(`/main/materials/updateCount/${materialId}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                }
            }).then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    console.log('View count updated successfully');
                } else {
                    console.error('Failed to update view count');
                }
            }).catch(error => console.error('Error:', error));
        }
</script>

<?php $this->endSection(); ?>