<?php

$this->extend('layout/layout');
$this->section('body');

?>
<div class="relative h-full">
    <div class="flex flex-col mt-5 gap-5 items-center ">
        <p class="font-semibold text-3xl text-black">Edit Course </p>
            <form 
                id="course-form"
                action="/main/course/update/<?= $course['id'] ?>"
                method="POST"
                enctype="multipart/form-data"
                class="flex flex-col space-y-4 px-10 py-5 w-[35%]  shadow-lg bg-white z-10"
                onsubmit="return handleFormSubmit(event)"
            >
                <div class="flex flex-col gap-2 items-center">
                    <label for="profile" class="cursor-pointer">
                        <img
                            id="image-preview"
                            src="/uploads/<?= $course['profile'] ?>"
                            alt="Course"
                            class="h-28 w-28 object-cover border border-gray-300"
                        >
                    </label>
                    <input 
                        type="file" 
                        id="profile" 
                        name="courseProfile" 
                        accept="image/png, image/jpeg, image/jpg" 
                        class="hidden" 
                        onchange="previewImage(event)"
                    >
                </div>
                <div class="flex items-center">
                    <img 
                        src="<?php echo base_url('images/course1.png') ?>"
                        class="h-10 w-10"
                    >
                    <input type="text" id="course_name" name="courseName" value="<?= $course['course_name'] ?>" class="h-10 w-full px-5 border border-black border-l-0" placeholder="Enter Course Fullname">
                 </div>
                <div class="flex items-center">
                    <img 
                        src="<?php echo base_url('images/course1.png') ?>"
                        class="h-10 w-10"
                    >
                    <input type="text" id="course_abbre" name="courseAbbre" value="<?= $course['course_abbre'] ?>" class="h-10 w-full px-5 border border-black border-l-0" placeholder="Enter Course Abbreviation">
                </div>
                <div class="flex items-center bg-[#d9d9d9] relative">
                    <img 
                        src="<?php echo base_url('images/date.png') ?>"
                        class="h-10 w-10 p-2 border border-black"
                    >
                    <img 
                        src="<?php echo base_url('images/sched.png') ?>"
                        class="absolute left-3 h-2"
                    >
                    <input type="text" id="schedule" name="courseSchedule"  value="<?= $course['schedule'] ?>" class="h-10 w-full px-5 border border-black" placeholder="Enter Course Schedule">
                </div>
                <div class="flex  relative">
                    <img 
                        src="<?php echo base_url('images/desc.png') ?>"
                        class="h-10 w-11 p-2 bg-[#d9d9d9] border border-black "
                    >
                    <img 
                        src="<?php echo base_url('images/side.png') ?>"
                        class="absolute left-2 top-[14px] h-3"
                    >
                    <i class="fa-solid fa-plus text-xs font-bold text-black absolute h-2 left-[14px] top-[12px]" ></i>           
                    <textarea id="description" name="courseDescription" class="h-32 w-full px-5 pt-2 border border-black resize-none" placeholder="Enter Course Description"><?= $course['description'] ?></textarea>
                </div>
                <div class="flex flex-col gap-2 items-center">
                    <button type="submit" class="w-[250px] flex justify-center rounded-full border border-transparent shadow-sm px-4 py-2 text-base  bg-[#1ED300] text-white">
                        Update Course
                    </button>
                    <a  
                        href="<?= base_url('main/course') ?>" 
                        class="w-[250px] flex justify-center rounded-full border border-transparent shadow-sm px-4 py-2 text-base  bg-[#0267FF] text-white">
                        Back
                    </a>
                </div>
            </form>
    <div>
    <img 
        src="<?php echo base_url('images/bgMain.png'); ?>" 
        alt="Logo" 
        class="h-[500px] absolute left-[25%] bottom-28 opacity-40 "
    > 
</div>
<script>
    function previewImage(event) {
        const file = event.target.files[0];
        const preview = document.getElementById('image-preview');

        if (file && (file.type === 'image/png' || file.type === 'image/jpeg' || file.type === 'image/jpg')) {
            const reader = new FileReader();
            
            reader.onload = function(e) {
                preview.src = e.target.result; // Update preview to new image
            };
            
            reader.readAsDataURL(file);
        }
    }
    async function handleFormSubmit(event) {
        event.preventDefault(); 

        const formData = new FormData(event.target);

        try {
            const response = await fetch(event.target.action, {
                method: 'POST',
                body: formData,
            });
            const data = await response.json();

            if (response.ok) {
                Swal.fire('Success', data.message, 'success').then(() => {
                window.location.href = '<?= base_url('main/course') ?>';
            });
            } else {
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: `Request failed: ${data.message}`,
                });
            }
        } catch (error) {
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: `Request failed: ${error.message}`,
            });
        }
    }
</script>
<?php $this->endSection(); ?>