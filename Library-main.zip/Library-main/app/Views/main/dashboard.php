<?php

$this->extend('layout/layout');
$this->section('body');

?>  
    <div class="relative">
    <?php if ($role === 'admin') : ?>
        <div class="flex flex-col gap-20 pt-10 px-20 w-full relative z-10">
            <div class="flex justify-evenly ">
                <div class="shadow-xl flex flex-col bg-white items-center py-5 px-10">
                    <img
                        src="<?= base_url('images/teacher.png') ?>"
                        alt="Teacher"
                        class="h-20 w-20 mb-2"
                    >
                    <span class="font-semibold text-lg">Instructor</span>
                    <span class="font-semibold"><?= $instructorCount ?></span>
                </div>
                <div class="shadow-xl flex flex-col bg-white items-center py-5 px-10">
                    <img
                        src="<?= base_url('images/student.png') ?>"
                        alt="Student"
                        class="h-20 w-20 mb-2"
                    >
                    <span class="font-semibold text-lg">Student</span>
                    <span class="font-semibold"><?= $studentCount ?></span>
                </div>
                <div class="shadow-xl flex flex-col bg-white items-center py-5 px-10">
                    <img
                        src="<?= base_url('images/guest.png') ?>"
                        alt="Guest"
                        class="h-20 w-20 mb-2"
                    >
                    <span class="font-semibold text-lg">Guest</span>
                    <span class="font-semibold"><?= $guestCount ?></span>
                </div>
                <div class="shadow-xl flex flex-col bg-white items-center py-5 px-10">
                    <img
                        src="<?= base_url('images/course.png') ?>"
                        alt="Course"
                        class="h-20 w-20 mb-2"
                    >
                    <span class="font-semibold text-lg">Courses</span>
                    <span class="font-semibold"><?= $courseCount ?></span>
                </div>
            </div>
            <div class="shadow-xl w-full h-80 flex flex-col gap-2 border border-blue-400 bg-white">
                <p class="font-semibold text-xl text-center text-white py-2 bg-[#1ED300]">Announcement Board</p>
            </div>
        </div>
    <?php elseif ($role === 'instructor') : ?>
        <div class="flex flex-col gap-20 pt-10 px-20 w-full relative z-10">
            <div class="flex justify-evenly ">
                <div class="shadow-xl flex flex-col bg-white items-center py-5 px-10">
                    <img
                        src="<?= base_url('images/course.png') ?>"
                        alt="Course"
                        class="h-20 w-20 mb-2"
                    >
                    <span class="font-semibold text-lg">Courses</span>
                    <span class="font-semibold"><?= $courseCount ?></span>
                </div>
                <div class="shadow-xl flex flex-col bg-white items-center py-5 px-10">
                    <img
                        src="<?= base_url('images/book.png') ?>"
                        alt="IM's"
                        class="h-20 w-20 mb-2"
                    >
                    <span class="font-semibold text-lg">IM's</span>
                    <span class="font-semibold"><?= $materialCount ?></span>
                </div>
                
                <div class="shadow-xl flex flex-col bg-white items-center py-5 px-10">
                    <img
                        src="<?= base_url('images/student.png') ?>"
                        alt="Student"
                        class="h-20 w-20 mb-2"
                    >
                    <span class="font-semibold text-lg">Student</span>
                    <span class="font-semibold"><?= $studentCount ?></span>
                </div>
                
            </div>
            <div class="shadow-xl w-full h-80 flex flex-col gap-2 border border-blue-400 bg-white">
                <p class="font-semibold text-xl text-center text-white py-2 bg-[#1ED300]">Announcement Board</p>
            </div>
        </div>
    <?php elseif ($role === 'student') : ?>
        <div class="flex flex-col gap-20 pt-10 px-20 w-full relative z-10">
            <div class="flex justify-evenly ">
                <div class="shadow-xl flex flex-col bg-white items-center py-5 px-10">
                    <img
                        src="<?= base_url('images/library.png') ?>"
                        alt="Library"
                        class="h-20 w-20 mb-2"
                    >
                    <span class="font-semibold text-lg">Library</span>
                    <span class="font-semibold"><?= $libraryCount ?></span>
                </div>
                <div class="shadow-xl flex flex-col bg-white items-center py-5 px-10">
                    <img
                        src="<?= base_url('images/book.png') ?>"
                        alt="IM's"
                        class="h-20 w-20 mb-2"
                    >
                    <span class="font-semibold text-lg">IM's</span>
                    <span class="font-semibold"><?= $materialCount ?></span>
                </div>
                
                <div class="shadow-xl flex flex-col bg-white items-center py-5 px-10">
                    <img
                        src="<?= base_url('images/collab.png') ?>"
                        alt="Collaboration"
                        class="h-20 w-20 mb-2"
                    >
                    <span class="font-semibold text-lg">Collaboration</span>
                    <span class="font-semibold"><?= $materialCount ?></span>
                </div>
                
            </div>
            <div class="shadow-xl w-full h-80 flex flex-col gap-2 border border-blue-400 bg-white">
                <p class="font-semibold text-xl text-center text-white py-2 bg-[#1ED300]">Announcement Board</p>
            </div>
        </div>
    <?php elseif ($role === 'guest') : ?>
        <div class="flex flex-col gap-10 pt-10 px-20 w-full relative z-10 ">
        <form action="/main/dashboard/search" method="GET">
                <div class="flex relative">
                    <input 
                        type="search"
                        name="search"
                        class="rounded-full border border-black w-full pl-5 pr-12 py-3"
                        placeholder="Search by title..."
                    >
                    <button type="submit" class="absolute right-5 top-[10%] bg-transparent border-none">
                        <i class="fa-solid fa-magnifying-glass text-3xl"></i>
                    </button>
                </div>
            </form>
            <div class="grid grid-rows-4 grid-cols-4 gap-5 z-10">
                <?php if (!empty($materials)): ?>
                    <?php foreach ($materials as $material): ?>
                        <a href="/main/dashboard/view/<?= esc($material['id']) ?>">
                            <div class="shadow-xl flex flex-col gap-1 items-center py-5 px-10 w-52 bg-white">
                                <img src="<?= base_url('images/book.png'); ?>" alt="Material" class="h-20 w-20">
                                <span class="font-semibold text-2xl text-center italic mb-4">"<?= esc($material['title']) ?>"</span>
                                <span class="font-semibold text-sm text-center ">Author: <?= esc($material['author']) ?></span>
                                <span class="font-semibold text-sm text-center ">Subject: <?= esc($material['subject']) ?></span>
                                <span class="font-semibold text-sm text-center ">Course: <?= esc($material['course']) ?></span>
                            </div>
                        </a>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p class="text-center col-span-4">No materials found for your search.</p>
                <?php endif; ?>
            </div>

        </div>
    <?php endif; ?>
    <img 
        src="<?php echo base_url('images/bgMain.png'); ?>" 
        alt="Logo" 
        class="h-[400px] absolute left-[30%] top-[30%] opacity-40"
    > 
    </div>

<?php $this->endSection(); ?>