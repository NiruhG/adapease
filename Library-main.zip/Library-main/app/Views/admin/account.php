<?php

$this->extend('layout/layout');
$this->section('body');

?>
<div class="relative">
    <div class="flex flex-col gap-10 pt-5 px-20 w-full  relative z-10">
            <p class="font-semibold text-xl text-center">Manage Account</p>
            <div class="flex justify-evenly">
                <div class="flex flex-col gap-2">
                    <div class="shadow-xl flex flex-col bg-white items-center py-5 w-48 px-10">
                        <img
                            src="<?= base_url('images/teacher.png') ?>"
                            alt="Teacher"
                            class="h-20 w-20 mb-2"
                        >
                        <span class="font-semibold text-lg">Instructor</span>
                        <span class="font-semibold"><?= $instructorCount ?></span>
                        <a 
                            href="admin/account/instructor/list"
                            class="flex flex-row w-full gap-2 mt-3 items-center justify-center">
                            <i class="fa-solid fa-eye text-md" ></i>
                            <p class="text-sm font-semibold">View All</p>
                        </a>
                    </div>
                    <a 
                        href="admin/account/instructor/add"
                        class="justify-center text-white flex flex-row gap-1 bg-[#1ED300] items-center p-1 w-48 rounded-full"
                    >
                        <i class="fa-solid fa-circle-plus text-white" ></i>
                        <p class=" text-sm">Create Instructor Account</p>
                    </a>
                </div>
                <div class="flex flex-col gap-2">
                    <div class="shadow-xl flex flex-col bg-white items-center py-5 w-48 px-10">
                        <img
                            src="<?= base_url('images/student.png') ?>"
                            alt="Student"
                            class="h-20 w-20 mb-2"
                        >
                        <span class="font-semibold text-lg">Student</span>
                        <span class="font-semibold"><?= $studentCount ?></span>
                        <a
                            href="admin/account/student/list" 
                            class="flex flex-row w-full gap-2 mt-3 items-center justify-center">
                            <i class="fa-solid fa-eye text-md" ></i>
                            <p class="text-sm font-semibold">View All</p>
                        </a>
                    </div>
                    <a 
                        href="admin/account/student/add"
                        class="justify-center text-white flex flex-row gap-1 bg-[#1ED300] items-center p-1 w-48 rounded-full"
                    >
                        <i class="fa-solid fa-circle-plus text-white" ></i>
                        <p class=" text-sm">Create Student Account</p>
                    </a>
                </div>
                <div class="flex flex-col gap-2">
                    <div class="shadow-xl flex flex-col bg-white items-center py-5 w-48 px-10">
                        <img
                            src="<?= base_url('images/guest.png') ?>"
                            alt="Guest"
                            class="h-20 w-20 mb-2"
                        >
                        <span class="font-semibold text-lg">Guest</span>
                        <span class="font-semibold"><?= $guestCount ?></span>
                        <a
                            href="admin/account/guest/list" 
                            class="flex flex-row w-full gap-2 mt-3 items-center justify-center">
                            <i class="fa-solid fa-eye text-md" ></i>
                            <p class="text-sm font-semibold">View All</p>
                        </a>
                    </div>
                    <a 
                        href="admin/account/guest/add"     
                        class="justify-center text-white flex flex-row gap-1 bg-[#1ED300] items-center p-1 w-48 rounded-full"
                    >
                        <i class="fa-solid fa-circle-plus text-white" ></i>
                        <p class=" text-sm">Create Guest Account</p>
                    </a>
                </div> 
            </div>
            <div class="shadow-xl w-full max-h-screen flex flex-col gap-2 border border-blue-400 bg-white">
                <p class="font-semibold text-xl text-center text-white py-2 bg-[#1ED300]">Top Active Users of the System</p>
                <div class="overflow-y-auto h-[250px]">
                    <?php if (!empty($freq_user)): ?>
                        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 my-3">
                            <?php foreach ($freq_user as $frequently): ?>
                                <div class="mx-5 p-3 shadow-xl w-[300px] flex flex-row gap-3 border border-blue-400 h-[68px]">
                                    <img
                                            src="<?= !empty($frequently['profile']) && file_exists('uploads/' . $frequently['profile']) 
                                                ? base_url('uploads/' . $frequently['profile']) 
                                                : ($frequently['role'] === 'instructor' 
                                                    ? base_url('images/teacher.png') 
                                                    : ($frequently['role'] === 'student' 
                                                        ? base_url('images/student.png')
                                                        : ($frequently['role'] == 'guest'
                                                            ? base_url('images/guest.png')
                                                            : base_url('images/admin.png')))) ?>"
                                            alt="Profile"
                                            class="h-12 w-12"
                                        />
                                    <div class="flex flex-col text-black">
                                        <p class="font-semibold text-md capitalize">
                                            <?= htmlspecialchars($frequently['last_name']) ?>, <?= htmlspecialchars($frequently['first_name']) ?>
                                        </p>
                                        <p class="font-semibold text-sm">
                                            <?= htmlspecialchars($frequently['email']) ?>
                                        </p>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <p class="text-center font-semibold my-5">No users found</p>
                    <?php endif; ?>
                </div>
            </div>
    </div>
    <img 
        src="<?php echo base_url('images/bgMain.png'); ?>" 
        alt="Logo" 
        class="h-[400px] absolute left-[30%] top-36 opacity-40 "
    > 
</div>

<?php $this->endSection(); ?>