<?php

$this->extend('layout/layout');
$this->section('body');

?>
<div class="relative h-full">
    <div class="flex flex-col mt-5 gap-5 items-center ">
        <p class="font-semibold text-3xl text-black">View Student Details</p>
            <form 
                id="student-form"
                action="/admin/account/student/delete/<?= $student['id'] ?>"
                method="POST"
                enctype="multipart/form-data"
                class="flex flex-col space-y-4 px-10 py-5 w-[30%]  shadow-lg bg-white z-10"
            >
                <div class="flex flex-col gap-2 items-center">
                        <img
                            id="image-preview"
                            src="<?= !empty($student['profile']) ?
                            base_url('uploads/' . $student['profile']):
                            base_url('images/student.png') ?>"
                            alt="student"
                            class="h-28 w-28 object-cover border border-gray-300"
                        >
                </div>
                <div class="flex flex-row gap-2">
                    <span class="font-semibold text-base">Name: </span>
                    <p class="font-semibold text-base underline">
                        <?= (!empty($student['first_name']) && !empty($student['last_name'])) ? 
                            $student['first_name'] . ' ' . $student['last_name'] : 
                            'No name'; ?>
                    </p>
                </div>
                <div class="flex flex-row gap-2">
                    <span class="font-semibold text-base">Email: </span>
                    <p class="font-semibold text-base underline">
                        <?= $student['email'] ?>
                    </p>
                </div>
                <div class="flex flex-row gap-2">
                    <span class="font-semibold text-base">Password: </span>
                    <p class="font-semibold text-base underline">
                        <?= !empty($student['password']) ? '********' : 'No password set' ?>
                    </p>
                </div>
                <div class="flex flex-row justify-between">
                    <?php 
                        $isChecked = $student['status'] == 0; 
                        $isFocused = $isChecked ? 'peer-focus:ring-yellow-300' : ''; 
                    ?>
                    <div class="flex items-center">
                        <label class="relative inline-flex items-center cursor-pointer">
                            <input 
                                type="checkbox" 
                                onclick="confirmStatus(<?= $student['id'] ?>, this)"
                                id="status-checkbox-<?= $student['id'] ?>"
                                name="status"
                                class="sr-only peer" 
                                <?= $isChecked ? 'checked' : '' ?>
                            >
                            <div class="w-11 h-6 bg-gray-200 <?= $isFocused ?> peer-focus:outline-none peer-focus:ring-4 rounded-full peer dark:bg-gray-700 peer-checked:bg-yellow-500"></div>
                            <span class="absolute left-1 top-1 bg-white w-4 h-4 rounded-full transition-transform peer-checked:translate-x-5"></span>
                        </label>
                        <span class="ml-3 text-md font-semibold ">
                            <?= $isChecked ? 'Active' : 'Inactive' ?>
                        </span>
                    </div>
                    <i 
                        onclick="confirmDelete()"
                        class="fa-solid fa-trash text-xl text-[#FF2001]"
                    ></i>
                </div>
                <a  
                        href="<?= base_url('admin/account/student/list') ?>" 
                        class="w-full flex justify-center rounded-full border border-transparent shadow-sm px-4 py-2 text-base  bg-[#0267FF] text-white">
                        Back
                    </a>
            </form>
    <div>
    <img 
        src="<?php echo base_url('images/bgMain.png'); ?>" 
        alt="Logo" 
        class="h-[400px] absolute left-[30%] top-36 opacity-40 "
    > 
</div>
<script>
    function confirmStatus(studentId, checkbox) { 
        const originalStatus = checkbox.checked; 
        const newStatus = originalStatus ? 1 : 0; 
        const actionText = originalStatus ? "activate" : "deactivate"; 
        const warningText = originalStatus ? "This will activate this account permanently!" : "This will deactivate this account permanently!";

        Swal.fire({
            title: 'Are you sure?',
            text: warningText,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#1ED300',
            cancelButtonColor: '#FF2001',
            confirmButtonText: 'Yes',
            cancelButtonText: 'No',
        }).then((result) => {
            if (result.isConfirmed) {
                updateStatus(studentId, newStatus); 
            } else {
                checkbox.checked = !originalStatus; 
            }
        });
    }

    function updateStatus(studentId, newStatus) {
        const url = `/admin/account/student/updateStatus/${studentId}`;

        fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ status: newStatus })
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                Swal.fire('Success', data.message, 'success').then(() => {
                    window.location.href = 'admin/account/student/list';
                });
            } else {
                Swal.fire('Error', data.message, 'error');
            }
        })
        .catch(error => {
            console.error('Error:', error); 
            Swal.fire('Error', `Request failed: ${error.message}`, 'error');
        });
    }

    function confirmDelete() {
        Swal.fire({
            title: 'Are you sure?',
            text: "This will delete the student permanently!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#1ED300',
            cancelButtonColor: '#FF2001',
            confirmButtonText: 'Yes',
            cancelButtonText: 'No',
        }).then((result) => {
            if (result.isConfirmed) {
                deleteStudent();
            }
        });
    }

    function deleteStudent() {
        const form = document.getElementById('student-form');
        
        fetch(form.action, {
            method: 'POST',
            body: new FormData(form)
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                Swal.fire('Success', data.message, 'success').then(() => {
                    window.location.href = '<?= base_url('admin/account/student/list') ?>';
                });
            } else {
                Swal.fire('Error', data.message, 'error');
            }
        })
        .catch(error => {
            Swal.showValidationMessage(`Request failed: ${error.message}`);
        });
    }
</script>

<?php $this->endSection(); ?>