<?php

$this->extend('layout/layout');
$this->section('body');

?>
<div class="relative">
    <div class="flex flex-col gap-20 pt-10 px-20 w-full relative z-10">
        <p class="font-semibold text-xl text-center">List of Student</p>
        <div class="grid grid-rows-4 grid-cols-4 gap-5 z-10">
            <?php foreach ($students as $student): ?>
                <div class="shadow-xl flex flex-col  items-center py-5 px-10 w-52 bg-white">
                    <img
                        src="<?= !empty($student['profile']) ? base_url('uploads/' . $student['profile']) : base_url('images/student.png') ?>"
                        alt="student"
                        class="h-28 w-28"
                    >
                    <p class="font-semibold text-base underline whitespace-nowrap">
                        <?= (!empty($student['first_name']) && !empty($student['last_name'])) ? 
                            $student['first_name'] . ' ' . $student['last_name'] : 
                            'No name'; ?>
                    </p>
                    <span class="text-xs font-semibold mb-2">Name</span>
                    <div class="flex flex-row w-full  justify-between">
                        <a 
                            href="/admin/account/student/view/<?= $student['id'] ?>"
                            class="fa-solid fa-eye text-md"
                        >
                        </a>
                        <a 
                            href="/admin/account/student/edit/<?= $student['id'] ?>"
                            class="fa-solid fa-pen-to-square text-md"
                        >
                        </a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>      
    </div>
    <img 
        src="<?php echo base_url('images/bgMain.png'); ?>" 
        alt="Logo" 
        class="h-[400px] absolute left-[30%] top-36 opacity-40 "
    > 
</div>

<?php $this->endSection(); ?>