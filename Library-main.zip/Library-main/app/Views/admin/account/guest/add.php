<?php

$this->extend('layout/layout');
$this->section('body');

?>
<div class="relative">
    <div class="flex flex-col gap-5 pt-10 px-20 w-full relative z-10 items-center">
        <p class="font-bold text-3xl text-center">Manage Account</p>
        <a 
                href="admin/account/guest/upload"
                class="text-white flex flex-row gap-1 bg-[#1ED300] items-center p-1 "
            >
                <i class="fa-solid fa-circle-plus text-white" ></i>
                <p class=" text-md font-semibold text-white">Import CSV File for Multiple Creation of Account</p>
            </a>
        <div class="flex flex-col gap-7 w-[45%] px-5 h-full pb-4 pt-4 bg-[#EAEEE9] z-10">        
            <div class="flex flex-col relative gap-8 text-center flex-grow pt-6 ">
                <p class="font-bold text-4xl ">Create Guest</p>
                <p class="text-base font-semibold ">
                    Guests are welcome to browse a limited selection<br/>
                    from our e-Library collection. Register as a guest<br/> 
                    to sample our digital resources.
                </p>
                <img 
                    src="<?php echo base_url('images/guest.png'); ?>" 
                    alt="Guest" 
                    class="h-28 w-28 absolute -left-[2%] -top-[6%]"
                >
            </div>   
            <form 
                id="guest-form"
                action="<?= base_url('admin/account/guest/add') ?>" 
                method="POST"
                onsubmit="return handleFormSubmit(event)"
                class="flex flex-col gap-4 px-10 text-black"
            >  
                <div class="flex flex-col gap-4 px-10 text-black">
                    <div class="flex flex-col">
                        <div class="relative">
                            <span class="absolute left-3 top-3 text-black">
                                <i class="fas fa-envelope text-md "></i>
                            </span>
                            <input 
                                type="email" 
                                name="email"
                                id="email"
                                class="w-full h-12 bg-white px-10 font-semibold" 
                                placeholder="Enter your Email"
                            >
                        </div>
                        
                        <div id="email_error" class="text-red-500 text-sm hidden">*Email is required</div>
                    </div>
                    <div class="flex flex-col">
                        <div class="relative">
                            <span class="absolute left-3 top-3 text-black">
                                <i class="fas fa-lock text-md "></i>
                            </span>
                            <input 
                                type="password" 
                                name="password"
                                id="password"
                                class="w-full h-12 bg-white px-10 font-semibold"
                                placeholder="Enter your Password"
                            >
                        </div>
                        <div id="pass_error" class="text-red-500 text-sm hidden">*Password is required</div>
                    </div>
                    <div class="flex flex-col gap-5">
                        <div class="flex flex-col">
                            <div class="relative">
                                <span class="absolute left-3 top-3 text-black">
                                    <i class="fas fa-lock text-md "></i>
                                </span>
                                <input 
                                    type="password" 
                                    name="cPassword"
                                    id="cPassword"
                                    class="w-full h-12 bg-white px-10 font-semibold"
                                    placeholder="Confirm your Password"
                                >   
                            </div>
                            <div id="cpass_error" class="text-red-500 text-sm hidden">*Please retype the password</div>
                            <div id="cpass_error1" class="text-red-500 text-sm hidden">*Passwords do not match</div>
                    </div>
                        <button 
                                type="submit"
                                class="w-full h-10 px-5 text-base text-white font-semibold bg-[#1ED300]"
                            >
                                Create
                            </button>
                            <a  
                                href="<?= base_url('admin/account') ?>" 
                                class="w-full h-10 px-5 text-base text-white font-semibold text-center pt-2 bg-[#0267FF] ">
                                Back
                            </a>
                </div> 
            </form> 
        </div>
    </div>
    <img 
        src="<?php echo base_url('images/bgMain.png'); ?>" 
        alt="Logo" 
        class="h-[400px] absolute left-[30%] top-36 opacity-40 "
    >
</div>

<script>
    async function handleFormSubmit(event) {
        event.preventDefault();
        const email = document.getElementById('email').value.trim();
        const password = document.getElementById('password').value.trim();
        const cPassword = document.getElementById('cPassword').value.trim();

        document.getElementById('email_error').classList.add('hidden');
        document.getElementById('pass_error').classList.add('hidden');
        document.getElementById('cpass_error').classList.add('hidden');
        document.getElementById('cpass_error1').classList.add('hidden');

        let isValid = true;

        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        if (!email || !emailPattern.test(email)) {
            document.getElementById('email_error').classList.remove('hidden');
            isValid = false;
        } else if (!emailPattern.test(email)) {
            document.getElementById('email_error').textContent = '*Invalid email format';
            document.getElementById('email_error').classList.remove('hidden');
            isValid = false;
        }

        if (!password) {
            document.getElementById('pass_error').textContent = '*Password is required';
            document.getElementById('pass_error').classList.remove('hidden');
            isValid = false;
        } else if (password.length < 8) {
            document.getElementById('pass_error').textContent = '*Password must be at least 8 characters';
            document.getElementById('pass_error').classList.remove('hidden');
            isValid = false;
        }

        if (!cPassword) {
            document.getElementById('cpass_error').classList.remove('hidden');
            isValid = false;
        } else if (password !== cPassword) {
            document.getElementById('cpass_error1').classList.remove('hidden');
            isValid = false;
        }

        if (!isValid) {
            return false;
        }


        const formData = new FormData(event.target);

        try {
            const response = await fetch(event.target.action, {
                method: 'POST',
                body: formData,
            });

            if (!response.ok) {
                const errorText = await response.text();
                throw new Error(errorText);
            }

            const data = await response.json();

            if (data.status === 'success') {
                Swal.fire('Success', 'Guest Registered Successfully', 'success').then(() => {
                    window.location.href = '<?= base_url('admin/account') ?>';
                });
            } 
            else {
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: `Request failed: ${data.message}`,
                });
            }
        } catch (error) {
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: `Request failed: ${error.message}`,
            });
        }
    }
</script>

<?php $this->endSection(); ?>