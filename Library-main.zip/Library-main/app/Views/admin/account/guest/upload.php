<?php

$this->extend('layout/layout');
$this->section('body');

?>
<div class="relative">
    <div class="flex flex-col gap-5 pt-10 px-20 w-full relative z-10 items-center">
        <p class="font-bold text-3xl text-center">Manage Account</p>
        <div class="flex flex-col gap-7 w-[45%] px-5 h-full pb-11 pt-4 bg-[#EAEEE9] z-10">
            <div class="flex flex-col relative gap-4 text-center flex-grow pt-3 ">
                    <p class="pl-8 font-bold text-4xl ">Create Multiple Guests</p>
                    <p class="text-base font-semibold pl-8 ">
                            Import CSV File with exact columns of first_name,<br/>
                            last_name, email, and password to Create Multiple<br/> 
                            Guests account. 
                            
                    </p>
                    <img 
                        src="<?php echo base_url('images/guest.png'); ?>" 
                        alt="Guest" 
                        class="h-28 w-28 absolute -left-[2%] -top-[6%]"
                    >
            </div>
            <form 
                action="<?= base_url('admin/account/guest/upload') ?>" 
                method="POST" 
                enctype="multipart/form-data"
                class="flex flex-col w-full items-center gap-5"
                id="uploadForm"
                >
                <div class="flex flex-row gap-2 items-center">
                    <label for="csv_file">Choose CSV file:</label>
                    <input 
                        type="file" 
                        name="csv_file" 
                        id="csv_file" 
                        accept=".csv"
                        class="border border-gray-300 w-52" 
                        required>
                </div>
                
                <button 
                                type="submit"
                                class=" h-10 px-5 w-60 text-base text-white font-semibold bg-[#1ED300]"
                            >
                                Upload
                            </button>
                            <a  
                                href="<?= base_url('admin/account/guest/add') ?>" 
                                class=" h-10 px-5 w-60 text-base text-white font-semibold text-center pt-2 bg-[#0267FF] ">
                                Back
                            </a>
            </form>      
        </div>
    </div>
    <img 
        src="<?php echo base_url('images/bgMain.png'); ?>" 
        alt="Logo" 
        class="h-[400px] absolute left-[30%] top-36 opacity-40 "
    >
</div>

<script>
document.getElementById('uploadForm').addEventListener('submit', async function(e) {
    e.preventDefault();  // Prevent the default form submission

    const formData = new FormData(this);
    const response = await fetch(this.action, {
        method: 'POST',
        body: formData
    });

    const result = await response.json();
    if (result.status === 'success') {
        Swal.fire({
            icon: 'success',
            title: 'Success!',
            text: result.message,
            confirmButtonText: 'OK'
        }).then(() => {
            window.location.href = '<?= base_url('admin/account') ?>';
        });
    } else {
        Swal.fire({
            icon: 'error',
            title: 'Error!',
            text: result.message,
            confirmButtonText: 'OK'
        });
    }
});
</script>

<?php $this->endSection(); ?>