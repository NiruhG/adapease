<?php

$this->extend('layout/layout');
$this->section('body');

?>
<div class="relative h-full">
    <div class="flex flex-col mt-5 gap-5 items-center ">
        <p class="font-semibold text-3xl text-black">Edit Guest Details</p>
            <form 
                id="guest-form"
                action="/admin/account/guest/update/<?= $guest['id'] ?>"
                method="POST"
                enctype="multipart/form-data"
                class="flex flex-col space-y-4 px-10 py-5 w-[35%]  shadow-lg bg-white z-10"
                onsubmit="return handleFormSubmit(event)"
            >
                <div class="flex flex-col gap-2 items-center">
                    <label for="profile" class="cursor-pointer">
                        <img
                            id="image-preview"
                            src="<?= !empty($guest['profile']) ?
                            base_url('uploads/' . $guest['profile']):
                            base_url('images/guest.png') ?>"
                            alt="guest"
                            class="h-28 w-28 object-cover border border-gray-300"
                        >
                    </label>
                    <input 
                        type="file" 
                        id="profile" 
                        name="userProfile" 
                        accept="image/png, image/jpeg, image/jpg" 
                        class="hidden" 
                        onchange="previewImage(event)"
                    >
                </div>
                <div class="flex flex-row gap-12 items-center">
                    <span class="font-semibold text-base whitespace-nowrap">Email: </span>
                    <input 
                        type="text" 
                        id="email" 
                        name="email" 
                        value="<?= !empty($guest['email']) ? 
                        $guest['email'] :
                        '' ?>" 
                        class="h-10 w-full px-5 border border-black " 
                        placeholder="Enter Email"
                    >
                </div>
                <div class="flex flex-row gap-[18px] items-center">
                    <span class="font-semibold text-base whitespace-nowrap">Password: </span>
                    <input 
                        type="text" 
                        id="password" 
                        name="password" 
                        value="<?= !empty($guest['password']) ? '********' : 'No password set' ?>"
                        class="h-10 w-full px-5 border border-black " 
                        placeholder="Enter Password"
                    >
                </div>
                <div class="flex flex-row gap-2 items-center">
                    <span class="font-semibold text-base whitespace-nowrap">First Name: </span>
                    <input 
                        type="text" 
                        id="first_name" 
                        name="firstName" 
                        value="<?= !empty($guest['first_name']) ? 
                        $guest['first_name'] :
                        '' ?>" 
                        class="h-10 w-full px-5 border border-black " 
                        placeholder="Enter First Name"
                    >
                </div>
                <div class="flex flex-row gap-[10px] items-center">
                    <span class="font-semibold text-base whitespace-nowrap">Last Name: </span>
                    <input 
                        type="text" 
                        id="last_name" 
                        name="lastName" 
                        value="<?= !empty($guest['last_name']) ? 
                        $guest['last_name'] :
                        '' ?>" 
                        class="h-10 w-full px-5 border border-black " 
                        placeholder="Enter Last Name"
                    >
                </div>
                <button type="submit" class="w-full flex justify-center rounded-full border border-transparent shadow-sm px-4 py-2 text-base  bg-[#1ED300] text-white">
                    Update Guest
                </button>
                <a  
                    href="<?= base_url('admin/account/guest/list') ?>" 
                    class="w-full flex justify-center rounded-full border border-transparent shadow-sm px-4 py-2 text-base  bg-[#0267FF] text-white">
                    Back
                </a>
            </form>
    <div>
    <img 
        src="<?php echo base_url('images/bgMain.png'); ?>" 
        alt="Logo" 
        class="h-[400px] absolute left-[30%] top-36 opacity-40 "
    > 
</div>
<script>
    function previewImage(event) {
        const file = event.target.files[0];
        const preview = document.getElementById('image-preview');

        if (file && (file.type === 'image/png' || file.type === 'image/jpeg' || file.type === 'image/jpg')) {
            const reader = new FileReader();
            
            reader.onload = function(e) {
                preview.src = e.target.result; // Update preview to new image
            };
            
            reader.readAsDataURL(file);
        }
    }
    async function handleFormSubmit(event) {
        event.preventDefault(); 

        const formData = new FormData(event.target);

        try {
            const response = await fetch(event.target.action, {
                method: 'POST',
                body: formData,
            });
            const data = await response.json();

            if (response.ok) {
                Swal.fire('Success', data.message, 'success').then(() => {
                window.location.href = '<?= base_url('admin/account/guest/list') ?>';
            });
            } else {
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: `Request failed: ${data.message}`,
                });
            }
        } catch (error) {
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: `Request failed: ${error.message}`,
            });
        }
    }
</script>

<?php $this->endSection(); ?>