<?php

$this->extend('layout/subMain');
$this->section('body');

?>
<nav class="flex flex-row  py-3 px-20 items-center gap-5 w-full mb-10">
            <div>
                <a href="<?= base_url('registerAs') ?>" class="btn btn-primary text-2xl font-bold">
                    <img 
                        src="<?php echo base_url('images/logo.png'); ?>" 
                        alt="Logo"
                    >
                </a>
            </div>
            <div class="flex-grow mr-10">
                <p class="font-bold text-5xl my-5">AdapEase Students with E-Library Access</p>
                <div class="h-1 bg-black w-full mb-8 "></div> 
                </div>
</nav>
<section class="flex flex-row w-full h-full px-40 gap-5 relative -top-[82px]">
    <div class="w-[55%] flex justify-center items-center relative ">
        <img 
            src="<?php echo base_url('images/bg.png'); ?>" 
            alt="Logo" 
            class="h-[400px] z-10 opacity-40 mt-20"
        > 
        <div class="absolute bg-[#D9D9D9] rounded-full top-[17%] right-[18%] w-28 h-28 opacity-60"></div>
        <div class="absolute bg-[#D9D9D9] rounded-full bottom-[23%] left-[12%] w-28 h-28 opacity-60"></div>
        <div class="absolute bg-[#D9D9D9] rounded-full top-[10%] left-[14%] w-28 h-28 opacity-60"></div>
        <div class="absolute bg-[#D9D9D9] rounded-full bottom-[15%] right-[13%] w-28 h-28 opacity-60"></div>
    </div>
    <div class="flex flex-col gap-7 w-[45%] px-5 h-full pb-11 pt-4 bg-[#EAEEE9]">        
        <div class="flex flex-col relative gap-8 pl-5 text-center flex-grow pt-6 ">
            <p class="font-bold text-4xl ">Admin Register</p>
            <p class="text-base font-semibold ">
                Creating a Admin account in AdapEase <br/>
                Students with E-Library Access have full <br/>
                access privileges to manage the system and <br/>
                other user accounts.
            </p>
            <img 
                src="<?php echo base_url('images/admin.png'); ?>" 
                alt="Admin" 
                class="h-32 w-32 absolute -left-[2%] top-2"
            >
        </div>   
        <form 
            id="admin-form"
            action="/admin/register"
            method="POST"
            onsubmit="return handleFormSubmit(event)"
            class="flex flex-col gap-4 px-10 text-black"
        >  
            <div class="flex flex-col gap-4 px-10 text-black">
                <div class="flex flex-col">
                    <input 
                        type="email" 
                        name="email"
                        id="email"
                        class="w-full h-12 bg-white px-5 font-semibold"
                        placeholder="Enter your Email"
                    >
                    <div id="email_error" class="text-red-500 text-sm hidden">*Email is required</div>
                </div>
                <div class="flex flex-col">
                    <input 
                        type="password" 
                        name="password"
                        id="password"
                        class="w-full h-12 bg-white px-5  font-semibold"
                        placeholder="Enter your Password"
                    >
                    <div id="pass_error" class="text-red-500 text-sm hidden">*Password is required</div>
                </div>
                <div class="flex flex-col gap-5">
                    <div class="flex flex-col">
                        <input 
                            type="password" 
                            name="cPassword"
                            id="cPassword"
                            class="w-full h-12 bg-white px-5 font-semibold"
                            placeholder="Confirm your Password"
                        >
                        <div id="cpass_error" class="text-red-500 text-sm hidden">*Please retype the password</div>
                        <div id="cpass_error1" class="text-red-500 text-sm hidden">*Passwords do not match</div>
                    </div>
                        <div class="flex flex-row gap-2 items-center">
                        <input 
                            type="checkbox" 
                            name="check"
                            class="w-5 h-5 bg-white px-5"
                        >
                        <span class="font-semibold text-base">Remember me</span>
                    </div>
                </div>
                <div class="flex flex-col gap-2">
                    <button 
                        type="submit"
                        class="w-full h-12 px-5 text-base text-white font-semibold bg-[#0267FF]"
                    >
                        Register
                    </button>
                    <p class="text-base font-semibold">Already have an account? 
                        <a 
                            href="<?= base_url('admin/login') ?>"
                            class="text-base text-[#0267FF]" 
                        >
                            Login
                        </a>
                    </p>
                </div>
            </div> 
        </form> 
    </div>
</section>

<script>
    async function handleFormSubmit(event) {
        event.preventDefault();
        const email = document.getElementById('email').value.trim();
        const password = document.getElementById('password').value.trim();
        const cPassword = document.getElementById('cPassword').value.trim();

        document.getElementById('email_error').classList.add('hidden');
        document.getElementById('pass_error').classList.add('hidden');
        document.getElementById('cpass_error').classList.add('hidden');
        document.getElementById('cpass_error1').classList.add('hidden');

        let isValid = true;
        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        if (!email) {
            document.getElementById('email_error').textContent = '*Email is required';
            document.getElementById('email_error').classList.remove('hidden');
            isValid = false;
        } else if (!emailPattern.test(email)) {
            document.getElementById('email_error').textContent = '*Invalid email format';
            document.getElementById('email_error').classList.remove('hidden');
            isValid = false;
        }

        if (!password) {
            document.getElementById('pass_error').textContent = '*Password is required';
            document.getElementById('pass_error').classList.remove('hidden');
            isValid = false;
        } else if (password.length < 8) {
            document.getElementById('pass_error').textContent = '*Password must be at least 8 characters';
            document.getElementById('pass_error').classList.remove('hidden');
            isValid = false;
        }

        if (!cPassword) {
            document.getElementById('cpass_error').classList.remove('hidden');
            isValid = false;
        } else if (password !== cPassword) {
            document.getElementById('cpass_error1').classList.remove('hidden');
            isValid = false;
        }

        if (!isValid) {
            return false;
        }

        const formData = new FormData(event.target);
        const submitButton = event.target.querySelector('button[type="submit"]');
        submitButton.disabled = true;

        try {
            const response = await fetch(event.target.action, {
                method: 'POST',
                body: formData,
            });

            if (!response.ok) {
                const errorText = await response.text();
                throw new Error(errorText);
            }

            const data = await response.json();

            if (data.status === 'success') {
                Swal.fire('Success', 'Admin Registered Successfully', 'success').then(() => {
                    window.location.href = '<?= base_url('admin/login') ?>';
                });
            } else {
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: `Request failed: ${data.message}`,
                });
            }
        } catch (error) {
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: `Request failed: ${error.message}`,
            });
        } finally {
            submitButton.disabled = false;
        }
    }
</script>


<?php $this->endSection(); ?>
