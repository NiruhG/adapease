<?php

$this->extend('layout/main');
$this->section('body');

?>

<section class="flex flex-col  relative gap-10 justify-center items-center w-full h-full">
    <img 
        src="<?php echo base_url('images/bg.png'); ?>" 
        alt="Logo" 
        class="h-[450px] absolute left-[15%] top-[20%] opacity-40 z-10"
    > 
    <div class="absolute bg-[#D9D9D9] rounded-full top-5 right-72 w-28 h-28 opacity-60"></div>
    <div class="absolute bg-[#D9D9D9] rounded-full top-36 right-[33%] w-36 h-36 opacity-60"></div>
    <div class="absolute bg-[#D9D9D9] rounded-full top-20 left-[41%] w-28 h-28 opacity-60"></div>
    <div class="absolute bg-[#D9D9D9] rounded-full top-[70%] right-[47%] w-28 h-28 opacity-60"></div>
    <div class="absolute bg-[#D9D9D9] rounded-full top-[10%] left-64 w-28 h-28 opacity-60"></div>
    <p class="text-5xl font-bold text-center z-10"><?= $title; ?></p>
    <div class="flex flex-row justify-evenly gap-10">
        <?php 
        foreach ($roles as $role) {
            echo "
                <a href='{$role['link']}' class='flex flex-col items-center justify-center gap-5 cursor-pointer shadow-xl hover:shadow-sky-800 z-20'>
                    <img src='{$role['image']}' alt='{$role['subTitle']}' class='w-44 h-44 object-fit mt-2'>
                    <div class='flex flex-col gap-6  p-4 w-[260px]'>
                        <p class='font-bold text-3xl text-center'>{$role['subTitle']}</p>
                        <p>{$role['description']}</p>
                    </div>
                </a>
            ";
        }
        ?>
    </div>
</section>



<?php $this->endSection(); ?>
