<header class="flex items-center justify-between gap-5 w-full px-10 py-2 bg-[#1ED300]">
    <p class="font-semibold text-white text-3xl "><?= $title ?></p>
    <div class="relative">
        
        <div 
            class="rounded-full bg-white items-center p-1 cursor-pointer"
            onclick="toggleDropdown()"  
        >
            <img 
                src="<?= $link; ?>" 
                alt="profile" 
                class="h-10 w-10 rounded-full"
            >
        </div>

      
        <div id="dropdownMenu" class="hidden absolute right-0 mt-1 w-32 bg-white rounded-lg shadow-lg z-50">
            <ul class="py-1">
                <li>
                    <a href="<?= base_url('main/profile') ?>" class="block px-4 py-2 text-black hover:bg-gray-200">
                        <i class="fa-solid fa-user"></i>
                        Profile
                    </a>
                </li>
                <li>
                    <a href="<?= base_url('main/settings') ?>" class="block px-4 py-2 text-black hover:bg-gray-200">
                    <i class="fa-solid fa-gear"></i>
                        Settings
                    </a>
                </li>
                <li>
                    <a href="<?= base_url($user['role'] . '/logout') ?>" class="block px-4 py-2 text-black hover:bg-gray-200">
                        <i class="fa-solid fa-arrow-right-from-bracket"></i>
                        Logout
                    </a>
                </li>
            </ul>
        </div>
    </div>
</header>

<script>
    function toggleDropdown() {
    var dropdown = document.getElementById("dropdownMenu");
    dropdown.classList.toggle("hidden");
}
</script>