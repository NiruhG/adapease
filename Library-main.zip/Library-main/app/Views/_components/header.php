<header class="flex flex-row  py-3 px-20 items-center gap-5 w-full mb-10">
            <div>
                <a href="<?= base_url('index') ?>" class="btn btn-primary text-2xl font-bold">
                    <img 
                        src="<?php echo base_url('images/logo.png'); ?>" 
                        alt="Logo"
                    >
                </a>
            </div>
            <div class="flex-grow mr-10">
                <p class="font-bold text-5xl my-5">AdapEase Students with E-Library Access</p>
                <div class="h-1 bg-black w-full mb-8 "></div> 
                </div>
</header>