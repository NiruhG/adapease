<?php

$this->extend('layout/subMain');
$this->section('body');

?>
<nav class="flex flex-row  py-3 px-20 items-center gap-5 w-full mb-10">
            <div>
                <a href="<?= base_url('loginAs') ?>" class="btn btn-primary text-2xl font-bold">
                    <img 
                        src="<?php echo base_url('images/logo.png'); ?>" 
                        alt="Logo"
                    >
                </a>
            </div>
            <div class="flex-grow mr-10">
                <p class="font-bold text-5xl my-5">AdapEase Students with E-Library Access</p>
                <div class="h-1 bg-black w-full mb-8 "></div> 
                </div>
</nav>
<section class="flex flex-row w-full h-full px-40 gap-5 relative -top-[82px]">
    <div class="w-[55%] flex justify-center items-center relative ">
        <img 
            src="<?php echo base_url('images/bg.png'); ?>" 
            alt="Logo" 
            class="h-[400px] z-10 opacity-40 mt-20"
        > 
        <div class="absolute bg-[#D9D9D9] rounded-full top-[17%] right-[18%] w-28 h-28 opacity-60"></div>
        <div class="absolute bg-[#D9D9D9] rounded-full bottom-[23%] left-[12%] w-28 h-28 opacity-60"></div>
        <div class="absolute bg-[#D9D9D9] rounded-full top-[10%] left-[14%] w-28 h-28 opacity-60"></div>
        <div class="absolute bg-[#D9D9D9] rounded-full bottom-[15%] right-[13%] w-28 h-28 opacity-60"></div>
    </div>
    <div class="flex flex-col gap-7 w-[45%] px-5 h-full pb-11 pt-4 bg-[#EAEEE9]">        
        <div class="flex flex-col relative gap-8 pl-5 text-center flex-grow pt-6 ">
            <p class="pl-5 font-bold text-4xl ">Account Verification</p>
            <p class="text-base font-semibold ">
                Check your email to see the code<br/>
                with subject of "Verification Code"<br/> 
                If you don't see it check the Spam.  
            </p>
            <img 
                src="<?php echo base_url('images/guest.png'); ?>" 
                alt="Guest" 
                class="h-32 w-32 absolute -left-[2%] top-2"
            >
        </div>
        <form 
            id="code-form"
            action="/guest/verification"
            method="POST"
            
            class="flex flex-col gap-4 px-10 text-black"
        >     
            <div class="flex flex-col gap-4 px-10 text-black">
                <div class="flex flex-col">
                    <input 
                        type="text" 
                        name="code"
                        id="code"
                        class="w-full h-12 bg-white px-5 font-semibold"
                        placeholder="Enter the Code"
                    >
                    <div id="code_error" class="text-red-500 text-sm hidden">*Code is required</div>
                </div>
                    <button 
                        type="button"
                         id="submitBtn"
                        class="w-full h-12 px-5 text-base text-white font-semibold bg-[#0267FF] "
                    >
                        Submit
                    </button>

            </div>  
        </form>
    </div>
</section>

<script>
    document.getElementById('submitBtn').addEventListener('click', function (e) {
        e.preventDefault();
        let code = document.getElementById('code').value;
        
        let valid = true;

        document.getElementById('code_error').classList.add('hidden');

        if (code.trim() === '') {
            document.getElementById('code_error').classList.remove('hidden');
            valid = false;
        }

        // If validation passes
        if (valid) {
            document.getElementById('code-form').submit();
        }
    });
</script>

<?php $this->endSection(); ?>