<?php

$this->extend('layout/layout');
$this->section('body');

?>
<div class="relative">
<div class="flex flex-col gap-20 pt-10 px-20 w-full z-10">
        
        <div class="grid grid-rows-4 grid-cols-4 gap-5 z-10">
            <?php foreach ($virtual as $index => $item): ?>
               
                <form 
                    class="shadow-xl flex flex-col gap-1 items-center py-5 px-10 w-52 bg-white"
                    method="POST"
                    id="virtual-form-<?= esc($item['vdrive_id']) ?>"
                    action="/student/virtual-drive/all/delete/<?= esc($item['vdrive_id']) ?>"
                >
                    <img
                        src="<?= base_url('images/book.png'); ?>" 
                        alt="Material"
                        class="h-20 w-20"
                    >
                    <span class="font-semibold text-2xl text-center italic mb-4">"<?= esc($item['title']) ?>"</span>
                    <span class="font-semibold text-sm text-center ">Author: <?= esc($item['author']) ?></span>
                    <span class="font-semibold text-sm text-center ">Subject: <?= esc($item['subject']) ?></span>
                    <span class="font-semibold text-sm text-center mb-2">Course: <?= esc($item['course']) ?></span>
                    <div class="flex flex-row w-full  justify-between">
                        <a
                            href="/student/virtual-drive/view/<?= esc($item['vdrive_id']) ?>" 
                            class="fa-solid fa-eye text-md"
                        >
                        </a>
                        <a
                            href="/student/virtual-drive/content/<?= esc($item['vdrive_id']) ?>" 
                            class="fa-solid fa-pen-to-square text-md"
                        >
                        </a>
                        <i
                            onclick="confirmDelete('virtual-form-<?= esc($item['vdrive_id']) ?>')" 
                            class="fa-solid fa-trash cursor-pointer"
                        ></i>
                    </div>
                </form>
            <?php endforeach; ?>
        </div>
    </div>
    <img 
        src="<?php echo base_url('images/bgMain.png'); ?>" 
        alt="Logo" 
        class="h-[400px] absolute left-[30%] top-36 opacity-40 "
    >
</div>

<script>
    function confirmDelete(formId) {
        Swal.fire({
            title: 'Are you sure?',
            text: "This will delete the material permanently in your virtual drive!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#FF2001',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes',
            cancelButtonText: 'No',
        }).then((result) => {
            if (result.isConfirmed) {
                unsavedVirtual(formId);  
            }
        });
    }

    function unsavedVirtual(formId) {
        const form = document.getElementById(formId);  
        
        fetch(form.action, {
            method: 'POST',
            body: new FormData(form)
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok ' + response.statusText);
            }
            return response.json();
        })
        .then(data => {
            if (data.status === 'success') {
                Swal.fire('Success', data.message, 'success').then(() => {
                    window.location.href = '<?= base_url('student/virtual-drive/all') ?>'; 
                });
            } else {
                Swal.fire('Error', data.message, 'error');
            }
        })
        .catch(error => {
            console.error('There has been a problem with your fetch operation:', error);
            Swal.showValidationMessage(`Request failed: ${error.message}`);
        });

    }

</script>
<?php $this->endSection(); ?>