<?php

$this->extend('layout/layout');
$this->section('body');

?>
<div class="relative h-full ">
    <div class="flex flex-col mt-5 gap-1 items-center ">
            <div id="pdfContainer" class="relative mb-4 flex flex-row gap-4">
                <div class="flex flex-col gap-2">
                    <canvas id="pdfCanvas" class="border border-gray-300"></canvas>
                    <div class="flex justify-evenly w-full z-10">
                        <button id="prevPage" class="bg-gray-800 text-white px-3 py-1 text-sm rounded" disabled>Previous</button>
                        <button id="nextPage" class="bg-gray-800 text-white px-3 py-1 text-sm rounded">Next</button>
                    </div>
                </div>
                   
                <div class="flex flex-col gap-5 w-[350px]">
                    <div class="flex flex-col gap-1 w-[350px] bg-black p-2 z-10">
                        <span class="text-yellow-200 font-semibold text-lg text-center">Assessment</span>
                        <?php if (!empty($questions)): ?>
                            <?php foreach ($questions as $index => $question): ?>
                                <?php if ($index < 3): ?>
                                    <div class="font-bold text-md py-1 px-5 bg-yellow-300 rounded"> 
                                        Question <?= $index + 1; ?>
                                    </div>
                                <?php endif; ?>

                                <div class="py-1 px-5 font-bold text-md bg-yellow-200 border border-yellow-400 rounded shadow-md">
                                    "<?= esc($question['question_text']); ?>"
                                </div>

                                <?php if (!empty($question['options'])): ?> 
                                    <div class="pl-10 py-2 bg-yellow-200">
                                        <ul class="list-disc">
                                            <?php foreach ($question['options'] as $option): ?>
                                                <?php
                                                   
                                                    $userAnswer = null;
                                                    if ($index === 0) {
                                                        $userAnswer = $user_answers['answer1'];
                                                    } elseif ($index === 1) {
                                                        $userAnswer = $user_answers['answer2'];
                                                    } elseif ($index === 2) {
                                                        $userAnswer = $user_answers['answer3'];
                                                    }
                                                    $isHighlighted = ($option['option_text'] === $userAnswer);
                                                ?>
                                                <li class="text-sm text-black <?= $isHighlighted ? 'font-bold' : ''; ?>">
                                                    <?= esc($option['option_text']); ?>
                                                </li>
                                            <?php endforeach; ?>
                                        </ul>
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="p-2 bg-red-200 border border-red-400 rounded shadow-md">
                                No questions available.
                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="flex flex-col gap-2 relative  px-10 pt-5 pb-10  w-full shadow-lg bg-black z-10 ">
                        <button 
                                onclick="showForm()"
                                class="text-black flex flex-row items-center gap-1 bg-white rounded-full border cursor-pointer justify-center border-white p-2 z-10"
                            >
                                <i class="fa-regular fa-comment text-xl"></i>

                                <p class="text-xl text-black font-semibold">Add Text</p>
                        </button>
                        <button 
                                onclick="showForm1()"
                                class="text-black flex flex-row items-center gap-1 bg-white rounded-full border cursor-pointer justify-center border-white p-2 z-10"
                            >
                                <i class="fa-regular fa-image text-xl"></i>
                                <p class="text-xl text-black font-semibold">Add Image</p>
                        </button>
                        <button 
                                onclick="showForm2()"
                                class="text-black flex flex-row items-center gap-1 bg-white rounded-full border cursor-pointer justify-center border-white p-2 z-10"
                            >
                                <i class="fa-solid fa-video text-xl"></i>
                                <p class="text-xl text-black font-semibold">Add Video</p>
                        </button>
                        <div class="flex flex-col gap-5  mt-5">
                                <span class="text-xl text-white font-semibold" >Annotation Section</span>
                                <?php 
                                    
                                    $combined = [];
                                    foreach ($texts as $text) {
                                        $combined[] = [
                                            'type' => 'text',
                                            'content' => esc($text['description']),
                                            'created_at' => $text['created_at'], 
                                        ];
                                    }

                                    foreach ($images as $image) {
                                        $combined[] = [
                                            'type' => 'image',
                                            'content' => '/uploads/' . $image['image'],
                                            'created_at' => $image['created_at'], 
                                        ];
                                    }

                                    foreach ($videos as $video) {
                                        $combined[] = [
                                            'type' => 'video',
                                            'content' => '/uploads/' . $video['video'],
                                            'created_at' => $video['created_at'], 
                                        ];
                                    }

                                    usort($combined, function($a, $b) {
                                        return strtotime($b['created_at']) - strtotime($a['created_at']);
                                    });
                                    ?>

                                    <?php if (!empty($combined)): ?>
                                        <ul>
                                            <?php foreach ($combined as $item): ?>
                                                <li class="flex flex-col gap-0 rounded-md bg-white w-full mb-5">
                                                    <?php if ($item['type'] === 'text'): ?>
                                                        <div class="p-3">
                                                            <?= $item['content'] ?>
                                                        </div>
                                                    <?php elseif ($item['type'] === 'image'): ?>
                                                        <div class="items-center justify-center flex w-full h-full">
                                                            <img src="<?= $item['content'] ?>" alt="Image" class="h-32 w-32">
                                                        </div>
                                                       
                                                    <?php elseif ($item['type'] === 'video'): ?>
                                                        <video controls class="w-80 h-[173px] p-3">
                                                            <source src="<?= $item['content'] ?>" type="video/mp4">
                                                            Your browser does not support the video tag.
                                                        </video>
                                                    <?php endif; ?>
                                                </li>
                                            <?php endforeach; ?>
                                        </ul>
                                    <?php else: ?>
                                        <p class="text-white">No annotation available for this material.</p>
                                    <?php endif; ?>

                        </div>
                    </div> 
                </div>
                
            </div>   
    <div>
</div>

<script>
            document.addEventListener('contextmenu', function (e) {
                e.preventDefault();
            });

            document.addEventListener('keydown', function(e) {
                if (e.ctrlKey && (e.key === 's' || e.key === 'p' || e.key === 'c' || e.key === 'v' || e.key === 'a')) {
                    e.preventDefault(); 
                    Swal.fire({
                        title: "Warning!",
                        text: "This content is confidential. Unauthorized sharing or distribution is prohibited.",
                        icon: "warning",
                        buttons: true,
                        dangerMode: true,
                    });
                }

                if (e.altKey && e.metaKey && e.key === 'r') {
                    e.preventDefault();
                    Swal.fire({
                        title: "Warning!",
                        text: "This content is confidential. Unauthorized sharing or distribution is prohibited.",
                        icon: "warning",
                        buttons: true,
                        dangerMode: true,
                    });
                }

                if(e.key === 'Meta' || e.key === 'Alt' ){
                    e.preventDefault(); 
                    Swal.fire({
                        title: "Warning!",
                        text: "This content is confidential. Unauthorized sharing or distribution is prohibited.",
                        icon: "warning",
                        buttons: true,
                        dangerMode: true,
                    });
                }

                if (e.key === 'PrintScreen' || (e.ctrlKey && e.key === 'PrintScreen') || (e.altKey && e.key === 'PrintScreen')) {
                    Swal.fire({
                        title: "Warning!",
                        text: "This content is confidential. Unauthorized sharing or screenshots are prohibited.",
                        icon: "warning",
                        buttons: true,
                        dangerMode: true,
                    });
                }
            });

            document.addEventListener('DOMContentLoaded', function () {
                    const url = '/uploads/<?= $virtuals['file'] ?>'; 
                    const pdfjsLib = window['pdfjs-dist/build/pdf'];
                    pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/2.10.377/pdf.worker.min.js';

                    let pdfDoc = null;
                    let currentPage = 1;

                    const pdfCanvas = document.getElementById('pdfCanvas');
                    const ctx = pdfCanvas.getContext('2d');

                    const renderPage = (pageNum) => {
                        pdfDoc.getPage(pageNum).then(page => {
                            const desiredHeight = 900; 
                            const viewport = page.getViewport({ scale: desiredHeight / page.getViewport({ scale: 0.8 }).height });
                            
                            pdfCanvas.height = viewport.height;
                            pdfCanvas.width = viewport.width;

                            const renderContext = {
                                canvasContext: ctx,
                                viewport: viewport
                            };

                            page.render(renderContext).promise.then(() => {
                                console.log(`Page ${pageNum} rendered`);
                            });
                        });
                    };

                    const loadingTask = pdfjsLib.getDocument(url);
                    loadingTask.promise.then(pdf => {
                        pdfDoc = pdf;
                        console.log('PDF loaded');
                        renderPage(currentPage); 
                    });

                    const saveScrollPosition = () => {
                        const savedPosition = window.scrollY;
                        return savedPosition;
                    };  

                    document.getElementById('prevPage').addEventListener('click', () => {
                        if (currentPage <= 1) return; // Don't go below page 1
                        currentPage--;
                        renderPage(currentPage);
                        updateButtons();
                        window.scrollTo(0, saveScrollPosition());
                    });

                    document.getElementById('nextPage').addEventListener('click', () => {
                        if (currentPage >= pdfDoc.numPages) return; 
                        currentPage++;
                        renderPage(currentPage);
                        updateButtons();
                        window.scrollTo(0, saveScrollPosition()); 
                    });

                    const updateButtons = () => {
                        document.getElementById('prevPage').disabled = (currentPage <= 1);
                        document.getElementById('nextPage').disabled = (currentPage >= pdfDoc.numPages);
                    };
            });

            function showForm() {
                Swal.fire({
                    html: `
                        <div class="flex flex-col gap-5">
                            <p class="font-semibold text-3xl text-black">Add Text</p>
                            <form 
                                id="comment-form"
                                action="/student/virtual-drive/content"
                                method="POST"
                                class="flex flex-col space-y-4 px-10"
                            >
                                <div class="flex flex-col gap-2">
                                    <div class="flex items-start w-full ">
                                        <textarea id="description" name="description" class="h-40 w-full px-5 pt-2 border border-black resize-none" placeholder="Type here..."></textarea>
                                    </div>
                                    <div id="description_error" class="text-red-500 text-sm hidden">*Text is required</div>
                                </div>
                                <input type="hidden" name="virtual_id" value="<?= $virtuals['id'] ?>">
                            </form>
                        </div>
                    `,
                    confirmButtonText: "Add Text",
                    customClass: {
                        confirmButton: "w-[250px] inline-flex justify-center rounded-full border border-transparent shadow-sm px-4 py-2 text-base bg-[#1ED300] text-white",
                    },
                    buttonsStyling: false,
                    preConfirm: () => {
                        
                        const description = document.getElementById('description').value.trim();
                        document.getElementById('description_error').classList.add('hidden');
                    

                        let isValid = true;
                        if (!description) {
                            document.getElementById('description_error').classList.remove('hidden');
                            isValid = false;
                        }

                        if (!isValid) {
                            Swal.showValidationMessage('Please fill in all required fields.');
                            return false; 
                        }

                        const form = document.getElementById('comment-form');
                        const formData = new FormData(form);

                        return fetch(form.action, {
                            method: 'POST',
                            body: formData,
                        }).then(response => {
                            if (!response.ok) {
                                return response.text().then(text => { throw new Error(text); });
                            }
                            return response.json();
                        }).then(data => {
                            Swal.fire('Success', data.message, 'success').then(() => {
                                window.location.href = 'student/virtual-drive/all';
                            });
                        }).catch(error => {
                            Swal.showValidationMessage(`Request failed: ${error.message}`);
                        });
                    }
                });
            }

            function showForm1() {
                Swal.fire({
                    html: `
                        <div class="flex flex-col gap-5">
                            <p class="font-semibold text-3xl text-black">Add Image</p>
                            <form 
                                id="image-form"
                                action="/student/virtual-drive/content1"
                                method="POST"
                                class="flex flex-col space-y-4 px-10"
                            >
                                <div class="flex flex-col gap-2 items-center">
                                    <img id="image-preview" class="hidden w-40 h-40 object-cover border border-gray-300">
                                    <input type="file" id="image" name="vImage" accept="image/png, image/jpeg, image/jpg" class="border border-black p-1 w-full" onchange="previewImage(event)">
                                    <div id="image_error" class="text-red-500 text-sm hidden">*Image is required</div>
                                </div>
                                <input type="hidden" name="virtual_id" value="<?= $virtuals['id'] ?>">
                            </form>
                        </div>
                    `,
                    confirmButtonText: "Add Image",
                    customClass: {
                        confirmButton: "w-[250px] inline-flex justify-center rounded-full border border-transparent shadow-sm px-4 py-2 text-base bg-[#1ED300] text-white",
                    },
                    buttonsStyling: false,
                    preConfirm: () => {
                        const image = document.getElementById('image').files.length === 0;
                        document.getElementById('image_error').classList.add('hidden');
                    

                        let isValid = true;
                        if (image) {
                            document.getElementById('image_error').classList.remove('hidden');
                            isValid = false;
                        }

                        if (!isValid) {
                            Swal.showValidationMessage('Please fill in all required fields.');
                            return false; 
                        }

                        const form = document.getElementById('image-form');
                        const formData = new FormData(form);

                        return fetch(form.action, {
                            method: 'POST',
                            body: formData,
                        }).then(response => {
                            if (!response.ok) {
                                return response.text().then(text => { throw new Error(text); });
                            }
                            return response.json();
                        }).then(data => {
                            Swal.fire('Success', data.message, 'success').then(() => {
                                window.location.href = 'student/virtual-drive/all';
                            });
                        }).catch(error => {
                            Swal.showValidationMessage(`Request failed: ${error.message}`);
                        });
                    }
                });
            }

            function previewImage(event) {
                const file = event.target.files[0];
                const preview = document.getElementById('image-preview');
                
                if (file && (file.type === 'image/png' || file.type === 'image/jpeg' || file.type === 'image/jpg')) {
                    const reader = new FileReader();
                    
                    reader.onload = function(e) {
                        preview.src = e.target.result;
                        preview.classList.remove('hidden'); // Show the image preview
                    };
                    
                    reader.readAsDataURL(file);
                } else {
                    preview.src = '';
                    preview.classList.add('hidden'); // Hide the image preview if not valid
                }
            }

            function showForm2() {
                Swal.fire({
                    html: `
                        <div class="flex flex-col gap-5">
                            <p class="font-semibold text-3xl text-black">Add Video</p>
                            <form 
                                id="video-form"
                                action="/student/virtual-drive/content2"
                                method="POST"
                                class="flex flex-col space-y-4 px-10"
                            >
                                <div class="flex flex-col gap-2 items-center">
                                    <div id="video-preview" class="hidden w-80 h-[173px] object-cover border border-gray-300"></div>
                                    <input type="file" id="video" name="vVideo" accept="video/mp4, video/mov, video/avi" class="border border-black p-1 w-full" onchange="previewVideo(event)">
                                    <div id="video_error" class="text-red-500 text-sm hidden">*Video is required</div>
                                </div>
                                <input type="hidden" name="virtual_id" value="<?= $virtuals['id'] ?>">
                            </form>
                        </div>
                    `,
                    confirmButtonText: "Add Video",
                    customClass: {
                        confirmButton: "w-[250px] inline-flex justify-center rounded-full border border-transparent shadow-sm px-4 py-2 text-base bg-[#1ED300] text-white",
                    },
                    buttonsStyling: false,
                    preConfirm: () => {
                        const video = document.getElementById('video').files.length === 0;
                        document.getElementById('video_error').classList.add('hidden');
                    

                        let isValid = true;
                        if (video) {
                            document.getElementById('video_error').classList.remove('hidden');
                            isValid = false;
                        }

                        if (!isValid) {
                            Swal.showValidationMessage('Please fill in all required fields.');
                            return false; 
                        }

                        const form = document.getElementById('video-form');
                        const formData = new FormData(form);

                        return fetch(form.action, {
                            method: 'POST',
                            body: formData,
                        }).then(response => {
                            if (!response.ok) {
                                return response.text().then(text => { throw new Error(text); });
                            }
                            return response.json();
                        }).then(data => {
                            Swal.fire('Success', data.message, 'success').then(() => {
                                window.location.href = 'student/virtual-drive/all';
                            });
                        }).catch(error => {
                            Swal.showValidationMessage(`Request failed: ${error.message}`);
                        });
                    }
                });
            }

            function previewVideo(event) {
                const file = event.target.files[0];
                const previewContainer = document.getElementById('video-preview');
                const videoError = document.getElementById('video_error');

                if (file) {
                    // Ensure the file is a video
                    if (file.type.startsWith('video/')) {
                        videoError.classList.add('hidden');
                        
                        // Create video element
                        const videoElement = document.createElement('video');
                        videoElement.src = URL.createObjectURL(file);
                        videoElement.controls = true;  // Add controls (play, pause, etc.)
                        videoElement.width = 500;  // Set a fixed width for preview
                        videoElement.height = 500;  // Set a fixed height for preview

                        // Clear any previous previews
                        previewContainer.innerHTML = '';
                        previewContainer.appendChild(videoElement);
                        previewContainer.classList.remove('hidden');
                    } else {
                        videoError.textContent = '*Selected file is not a valid video';
                        videoError.classList.remove('hidden');
                        previewContainer.innerHTML = '';
                    }
                } else {
                    videoError.textContent = '*Video is required';
                    videoError.classList.remove('hidden');
                    previewContainer.innerHTML = '';
                }
            }


</script>


<?php $this->endSection(); ?>