<?php

$this->extend('layout/layout');
$this->section('body');

?>
<div class="relative h-full">
    <div class="flex flex-col mt-5 gap-1 items-center ">
        <div class="flex flex-col relative  px-10 pb-10  w-[35%]  shadow-lg bg-white z-10 items-center">   
            <div id="pdfContainer" class="relative mb-4">
                <canvas id="pdfCanvas" class="border border-gray-300"></canvas>
                    
            </div>
            <div class="flex justify-between w-full">
                <button id="prevPage" class="bg-gray-800 text-white px-3 py-1 text-sm rounded" disabled>Previous</button>
                <button id="nextPage" class="bg-gray-800 text-white px-3 py-1 text-sm rounded">Next</button>
            </div>
        </div>
    <div>
    <img 
        src="<?php echo base_url('images/bgMain.png'); ?>" 
        alt="Logo" 
        class="h-[500px] absolute left-[25%] bottom-28 opacity-40 "
    > 
</div>

<script>
            document.addEventListener('contextmenu', function (e) {
                e.preventDefault();
            });
            document.addEventListener('keydown', function(e) {
                if (e.ctrlKey && (e.key === 's' || e.key === 'p' || e.key === 'c' || e.key === 'v' || e.key === 'a')) {
                    e.preventDefault(); 
                    Swal.fire({
                        title: "Warning!",
                        text: "This content is confidential. Unauthorized sharing or distribution is prohibited.",
                        icon: "warning",
                        buttons: true,
                        dangerMode: true,
                    });
                }

                if (e.altKey && e.metaKey && e.key === 'r') {
                    e.preventDefault();
                    Swal.fire({
                        title: "Warning!",
                        text: "This content is confidential. Unauthorized sharing or distribution is prohibited.",
                        icon: "warning",
                        buttons: true,
                        dangerMode: true,
                    });
                }

                if(e.key === 'Meta' || e.key === 'Alt' ){
                    e.preventDefault(); 
                    Swal.fire({
                        title: "Warning!",
                        text: "This content is confidential. Unauthorized sharing or distribution is prohibited.",
                        icon: "warning",
                        buttons: true,
                        dangerMode: true,
                    });
                }

                if (e.key === 'PrintScreen' || (e.ctrlKey && e.key === 'PrintScreen') || (e.altKey && e.key === 'PrintScreen')) {
                    Swal.fire({
                        title: "Warning!",
                        text: "This content is confidential. Unauthorized sharing or screenshots are prohibited.",
                        icon: "warning",
                        buttons: true,
                        dangerMode: true,
                    });
                }
            });

            document.addEventListener('DOMContentLoaded', function () {
                    const url = '/uploads/<?= $virtuals['file'] ?>'; 
                    const pdfjsLib = window['pdfjs-dist/build/pdf'];
                    pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/2.10.377/pdf.worker.min.js';

                    let pdfDoc = null;
                    let currentPage = 1;

                    const pdfCanvas = document.getElementById('pdfCanvas');
                    const ctx = pdfCanvas.getContext('2d');

                    const renderPage = (pageNum) => {
                        pdfDoc.getPage(pageNum).then(page => {
                            const desiredHeight = 900; 
                            const viewport = page.getViewport({ scale: desiredHeight / page.getViewport({ scale: 0.8 }).height });
                            
                            pdfCanvas.height = viewport.height;
                            pdfCanvas.width = viewport.width;

                            const renderContext = {
                                canvasContext: ctx,
                                viewport: viewport
                            };

                            page.render(renderContext).promise.then(() => {
                                console.log(`Page ${pageNum} rendered`);
                            });
                        });
                    };

                    const loadingTask = pdfjsLib.getDocument(url);
                    loadingTask.promise.then(pdf => {
                        pdfDoc = pdf;
                        console.log('PDF loaded');
                        renderPage(currentPage); 
                    });

                    const saveScrollPosition = () => {
                        const savedPosition = window.scrollY;
                        return savedPosition;
                    };  

                    document.getElementById('prevPage').addEventListener('click', () => {
                        if (currentPage <= 1) return; // Don't go below page 1
                        currentPage--;
                        renderPage(currentPage);
                        updateButtons();
                        window.scrollTo(0, saveScrollPosition());
                    });

                    document.getElementById('nextPage').addEventListener('click', () => {
                        if (currentPage >= pdfDoc.numPages) return; 
                        currentPage++;
                        renderPage(currentPage);
                        updateButtons();
                        window.scrollTo(0, saveScrollPosition()); 
                    });

                    const updateButtons = () => {
                        document.getElementById('prevPage').disabled = (currentPage <= 1);
                        document.getElementById('nextPage').disabled = (currentPage >= pdfDoc.numPages);
                    };
            });

</script>


<?php $this->endSection(); ?>