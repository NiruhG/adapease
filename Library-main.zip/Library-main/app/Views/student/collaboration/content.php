<?php

$this->extend('layout/layout');
$this->section('body');

?>
<div class="relative h-full ">
    <div class="flex flex-col mt-5 gap-1 items-center ">
            <!-- <div class="flex flex-col relative  px-10 pt-5 pb-10  w-[35%]  shadow-lg bg-white z-10 items-center">
                <div class="flex flex-col gap-2 items-center mb-5">
                        <img
                            src="<?= base_url('images/book.png'); ?>" 
                            alt="Material"
                            class="h-20 w-20 object-cover border border-gray-300"
                        >
                </div>
                
                <div class="flex  items-center text-lg ">
                    <p class="font-semibold"><?= $materials['title'] ?></p>
                 </div>
                <div class="flex items-center text-lg">
                    <p class="font-semibold"><?= $materials['author'] ?></p>
                </div>
                <div class="flex items-center text-lg">
                    <p class="font-semibold"><?= $materials['subject'] ?></p>
                </div>
                <div class="flex items-center text-lg">
                    <p class="font-semibold"><?= $materials['course'] ?></p>
                </div>
                
            </div> -->
            <div id="pdfContainer" class="relative mb-4 flex flex-row gap-4">
                <div class="flex flex-col gap-2">
                    <canvas id="pdfCanvas" class="border border-gray-300"></canvas>
                    <div class="flex justify-evenly w-full z-10">
                        <button id="prevPage" class="bg-gray-800 text-white px-3 py-1 text-sm rounded" disabled>Previous</button>
                        <button id="nextPage" class="bg-gray-800 text-white px-3 py-1 text-sm rounded">Next</button>
                    </div>
                </div>
                   
                    <div class="flex flex-col gap-1 ">
                        <div class="flex flex-col gap-10 relative  px-10 pt-5 pb-10  w-full shadow-lg bg-black z-10 ">
                            <button 
                                onclick="showForm()"
                                class="text-black flex flex-row items-center gap-1 bg-white rounded-full border cursor-pointer justify-center border-white p-2 z-10"
                            >
                                <i class="fa-regular fa-comment text-xl"></i>
                                <p class="text-xl text-black font-semibold">Add Comment</p>
                            </button>

                            <div class="flex flex-col gap-5 ">
                                <span class="text-xl text-white font-semibold" >Comment Section</span>
                                
                                <?php if (!empty($comments)): ?>
                                    <ul>
                                        <?php foreach ($comments as $comment): ?>
                                            <li class="flex flex-row gap-3 mb-5">
                                                <img src="<?= !empty($comment['profile']) ? base_url('/uploads/' . $comment['profile']) : base_url('images/student.png'); ?>" class="h-10 w-10 inline-block" alt="User Profile">
                                                <div class="flex flex-col gap-0 rounded-md bg-white w-full px-3 pb-3 pt-1 ">
                                                    <span class="text-black text-md font-semibold">
                                                        <?= !empty($comment['first_name']) || !empty($comment['last_name']) 
                                                                ? ($comment['first_name'] . ' ' . $comment['last_name']) 
                                                                : $comment['email']; ?>
                                                    </span>
                                                    <?= esc($comment['description']) ?> 
                                                </div>

                                    
                                            
                                            
                                            </li>
                                        <?php endforeach; ?>
                                    </ul>
                                <?php else: ?>
                                    <p>No comments available for this material.</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
            </div>
            
    <div>

   
</div>

<script>
            document.addEventListener('contextmenu', function (e) {
                e.preventDefault();
            });

            document.addEventListener('keydown', function(e) {
                if (e.ctrlKey && (e.key === 's' || e.key === 'p' || e.key === 'c' || e.key === 'v' || e.key === 'a')) {
                    e.preventDefault(); 
                    Swal.fire({
                        title: "Warning!",
                        text: "This content is confidential. Unauthorized sharing or distribution is prohibited.",
                        icon: "warning",
                        buttons: true,
                        dangerMode: true,
                    });
                }

                if (e.altKey && e.metaKey && e.key === 'r') {
                    e.preventDefault();
                    Swal.fire({
                        title: "Warning!",
                        text: "This content is confidential. Unauthorized sharing or distribution is prohibited.",
                        icon: "warning",
                        buttons: true,
                        dangerMode: true,
                    });
                }

                if(e.key === 'Meta' || e.key === 'Alt' ){
                    e.preventDefault(); 
                    Swal.fire({
                        title: "Warning!",
                        text: "This content is confidential. Unauthorized sharing or distribution is prohibited.",
                        icon: "warning",
                        buttons: true,
                        dangerMode: true,
                    });
                }

                if (e.key === 'PrintScreen' || (e.ctrlKey && e.key === 'PrintScreen') || (e.altKey && e.key === 'PrintScreen')) {
                    Swal.fire({
                        title: "Warning!",
                        text: "This content is confidential. Unauthorized sharing or screenshots are prohibited.",
                        icon: "warning",
                        buttons: true,
                        dangerMode: true,
                    });
                }
            });

            document.addEventListener('DOMContentLoaded', function () {
                    const url = '/uploads/<?= $materials['file'] ?>'; 
                    const pdfjsLib = window['pdfjs-dist/build/pdf'];
                    pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/2.10.377/pdf.worker.min.js';

                    let pdfDoc = null;
                    let currentPage = 1;

                    const pdfCanvas = document.getElementById('pdfCanvas');
                    const ctx = pdfCanvas.getContext('2d');

                    const renderPage = (pageNum) => {
                        pdfDoc.getPage(pageNum).then(page => {
                            const desiredHeight = 900; 
                            const viewport = page.getViewport({ scale: desiredHeight / page.getViewport({ scale: 0.8 }).height });
                            
                            pdfCanvas.height = viewport.height;
                            pdfCanvas.width = viewport.width;

                            const renderContext = {
                                canvasContext: ctx,
                                viewport: viewport
                            };

                            page.render(renderContext).promise.then(() => {
                                console.log(`Page ${pageNum} rendered`);
                            });
                        });
                    };

                    const loadingTask = pdfjsLib.getDocument(url);
                    loadingTask.promise.then(pdf => {
                        pdfDoc = pdf;
                        console.log('PDF loaded');
                        renderPage(currentPage); 
                    });

                    const saveScrollPosition = () => {
                        const savedPosition = window.scrollY;
                        return savedPosition;
                    };  

                    document.getElementById('prevPage').addEventListener('click', () => {
                        if (currentPage <= 1) return; // Don't go below page 1
                        currentPage--;
                        renderPage(currentPage);
                        updateButtons();
                        window.scrollTo(0, saveScrollPosition());
                    });

                    document.getElementById('nextPage').addEventListener('click', () => {
                        if (currentPage >= pdfDoc.numPages) return; 
                        currentPage++;
                        renderPage(currentPage);
                        updateButtons();
                        window.scrollTo(0, saveScrollPosition()); 
                    });

                    const updateButtons = () => {
                        document.getElementById('prevPage').disabled = (currentPage <= 1);
                        document.getElementById('nextPage').disabled = (currentPage >= pdfDoc.numPages);
                    };
            });

            function showForm() {
            Swal.fire({
                html: `
                    <div class="flex flex-col gap-5">
                        <p class="font-semibold text-3xl text-black">Add Comment</p>
                        <form 
                            id="comment-form"
                            action="/student/collaboration/content"
                            method="POST"
                            class="flex flex-col space-y-4 px-10"
                        >
                            <div class="flex flex-col gap-2">
                                <div class="flex items-start w-full ">
                                    <textarea id="description" name="description" class="h-40 w-full px-5 pt-2 border border-black resize-none" placeholder="Type your comment..."></textarea>
                                </div>
                                <div id="description_error" class="text-red-500 text-sm hidden">*Comment is required</div>
                            </div>
                             <input type="hidden" name="material_id" value="<?= $materials['id'] ?>">
                            <div class="flex flex-col gap-2 items-center px-10">
                                <div class="flex items-center w-full gap-5">
                                    <img src="<?= !empty($user['profile']) ? base_url('/uploads/' . $user['profile']) : base_url('images/student.png'); ?>" class="h-10 w-10">
                                    <p class="text-black text-md font-semibold">
                                        <?= !empty($user['first_name']) || !empty($user['last_name']) 
                                            ? ($user['first_name'] . ' ' . $user['last_name']) 
                                            : $user['email']; ?>
                                    </p>
                                </div>
                            
                            </div>
                        </form>
                    </div>
                `,
                confirmButtonText: "Add Comment",
                customClass: {
                    confirmButton: "w-[250px] inline-flex justify-center rounded-full border border-transparent shadow-sm px-4 py-2 text-base bg-[#1ED300] text-white",
                },
                buttonsStyling: false,
                preConfirm: () => {
                    
                    const description = document.getElementById('description').value.trim();
                    document.getElementById('description_error').classList.add('hidden');
                   

                    let isValid = true;
                    if (!description) {
                        document.getElementById('description_error').classList.remove('hidden');
                        isValid = false;
                    }

                    if (!isValid) {
                        Swal.showValidationMessage('Please fill in all required fields.');
                        return false; 
                    }

                    const form = document.getElementById('comment-form');
                    const formData = new FormData(form);

                    return fetch(form.action, {
                        method: 'POST',
                        body: formData,
                    }).then(response => {
                        if (!response.ok) {
                            return response.text().then(text => { throw new Error(text); });
                        }
                        return response.json();
                    }).then(data => {
                        Swal.fire('Success', data.message, 'success').then(() => {
                            window.location.href = 'student/collaboration';
                        });
                    }).catch(error => {
                        Swal.showValidationMessage(`Request failed: ${error.message}`);
                    });
                }
            });
        }

</script>


<?php $this->endSection(); ?>