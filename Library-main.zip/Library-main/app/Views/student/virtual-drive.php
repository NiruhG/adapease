<?php

$this->extend('layout/layout');
$this->section('body');

?>
<div class="relative">
    <div class="flex justify-evenly pt-10 px-20 w-full ">
        <a 
             href="<?= base_url('student/virtual-drive/all') ?>"
            class="shadow-xl flex flex-col gap-1 items-center py-5 px-10 w-48 bg-white z-10"
        >
            <img
                src="<?= base_url('images/drive.png'); ?>" 
                alt="Material"
                class="h-20 w-20"
            >
            <span class="font-semibold text-lg text-center">Virtual Drive</span>
            <span class="font-semibold text-md text-center"><?= $virtualCount ?></span>
        </a>
        <a
            href="<?= base_url('student/library') ?>"
            class="shadow-xl flex flex-col gap-1 items-center py-5 px-10 w-48 bg-white z-10"
        >
            <img
                src="<?= base_url('images/file.png'); ?>" 
                alt="Material"
                class="h-20 w-20"
            >
            <span class="font-semibold text-lg text-center">IM's</span>
            <span class="font-semibold text-md text-center"><?= $libraryCount ?></span>
        </a>
    </div>
    <img 
        src="<?php echo base_url('images/bgMain.png'); ?>" 
        alt="Logo" 
        class="h-[400px] absolute left-[30%] top-36 opacity-40 "
    >
</div>
<?php $this->endSection(); ?>