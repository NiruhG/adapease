<?php

$this->extend('layout/layout');
$this->section('body');

?>
<div class="relative">
    <div class="flex flex-col gap-20 pt-10 px-20 w-full z-10">
        <div class="grid grid-rows-4 grid-cols-4 gap-5 z-10">
            <?php foreach ($materials as $material): ?>
                    <div class="shadow-xl flex flex-col gap-1 items-center py-5 px-10 w-52 bg-white">
                    <img src="<?= base_url('images/book.png'); ?>" alt="Material" class="h-20 w-20">
                                <span class="font-semibold text-2xl text-center italic mb-4">"<?= esc($material['title']) ?>"</span>
                                <span class="font-semibold text-sm text-center ">Author: <?= esc($material['author']) ?></span>
                                <span class="font-semibold text-sm text-center ">Subject: <?= esc($material['subject']) ?></span>
                                <span class="font-semibold text-sm text-center ">Course: <?= esc($material['course']) ?></span>
                        <div class="flex flex-row w-full justify-between mt-2">
                            <a 
                                href="/main/materials/content/<?= esc($material['id']) ?>"
                                class="fa-solid fa-eye text-md"
                            >
                            </a>
                            <a 
                                href="/student/collaboration/content/<?= esc($material['id']) ?>"
                                class="fa-solid fa-users text-md"
                            >
                            </a>
                            
                        </div>
                    </div>
                    
                
            <?php endforeach; ?>   
        </div>
    </div>
    <img 
        src="<?php echo base_url('images/bgMain.png'); ?>" 
        alt="Logo" 
        class="h-[400px] absolute left-[30%] top-36 opacity-40 "
    >
</div>

<?php $this->endSection(); ?>