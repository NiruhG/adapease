<?php

$this->extend('layout/layout');
$this->section('body');

?>
<div class="relative">
    <div class="flex flex-col gap-20 pt-10 px-20 w-full z-10">
        <div class="flex flex-col gap-10 z-10 mb-10">
            <?php foreach ($materials as $material): ?>
                <div class="flex flex-row gap-12 justify-between">
                    <div class="shadow-xl relative flex flex-col gap-1 items-center py-5 px-10 w-52 bg-white">
                        <img src="<?= base_url('images/book.png'); ?>" alt="Material" class="h-20 w-20">
                        <span class="font-semibold text-2xl text-center italic mb-4">"<?= esc($material['title']) ?>"</span>
                        <span class="font-semibold text-sm text-center ">Author: <?= esc($material['author']) ?></span>
                        <span class="font-semibold text-sm text-center ">Subject: <?= esc($material['subject']) ?></span>
                        <span class="font-semibold text-sm text-center ">Course: <?= esc($material['course']) ?></span>
                        <div class="flex flex-row w-full justify-between mt-5">           
                                <?php if (isset($questionsByMaterial[$material['id']]) && count($questionsByMaterial[$material['id']]) > 0): ?>
                                    <div class="flex flex-row justify-between w-40 items-center absolute right-6">
                                        <button 
                                            onclick="editForm()"
                                            class=" text-white flex flex-row gap-1 bg-[#1ED300] items-center p-2 rounded-full"
                                        >
                                            <i class="fa-solid fa-pen-to-square text-white"></i>
                                            
                                        </button>
                                        <p class="text-md whitespace-nowrap font-semibold">Assessment</p>
                                        <button 
                                            onclick="deleteForm(<?= $material['id'] ?>)"
                                            class="ml-1 text-white flex flex-row gap-1 bg-[#1ED300] items-center p-2 rounded-full"
                                        >
                                            <i class="fa-solid fa-trash text-white"></i>
                                           
                                        </button>
                                    </div>
                                <?php else: ?>
                                    <button 
                                         onclick="showForm(<?= $material['id'] ?>)"
                                        class="ml-1 text-white flex flex-row gap-1 bg-[#1ED300] items-center p-2 rounded-full"
                                    >
                                        <i class="fa-solid fa-plus text-white"></i>
                                        <p class="text-md whitespace-nowrap">Assessment</p>
                                    </button>
                                <?php endif; ?>
                        </div>
                    </div>
                    <div class="flex flex-col gap-5 w-80">
                        <button 
                            onclick="toggleFullScreen()" 
                            class="bg-gray-800 text-white px-3 py-1 text-sm rounded"
                        >
                            Fullscreen the Content
                        </button>
                        <div id="pdfContainer" class="relative">
                            <embed
                                id="pdfEmbed"
                                type="application/pdf"
                                src="/uploads/<?= $material['file'] ?>"
                                alt="File"
                                width="320"
                                height="300"
                            >
                        </div>
                    </div>
                    
                    <div class="flex flex-col gap-5 bg-white py-3 px-10 z-10 shadow-xl items-center">
                        <p class="font-bold text-3xl text-center mb-4">Assessment Questions</p>
                        <div class="flex flex-row gap-2 ">
                            <?php if (isset($questionsByMaterial[$material['id']])): ?>
                                <?php foreach ($questionsByMaterial[$material['id']] as $question): ?>
                                    <div class="flex flex-col gap-5 border border-neutral px-5">
                                        <span class="font-semibold text-xl text-center italic mb-4">"<?= esc($question['question_text']) ?>"</span>
                                        <?php if (isset($optionsByQuestion[$question['id']])): ?>
                                            <?php foreach ($optionsByQuestion[$question['id']] as $option): ?>
                                                <?php 
                                                    $isCorrect = isset($correctAnswersByQuestion[$question['id']]) && 
                                                                $correctAnswersByQuestion[$question['id']]['correct_option_id'] == $option['id']; // Adjust this if your correct answer structure is different
                                                ?>
                                                <span class="font-semibold text-md text-center mb-4 <?= $isCorrect ? 'bg-green-300' : '' ?>">
                                                    <?= esc($option['option_text']) ?>
                                                </span>
                                            <?php endforeach; ?>
                                        <?php endif; ?>  
                                    </div> 
                                <?php endforeach; ?>
                            <?php else: ?>
                                <span class="font-semibold text-lg text-center">No questions available for this material.</span>
                            <?php endif; ?>   
                        </div>
                    </div>
                </div> 
            <?php endforeach; ?>   
        </div>
    </div>
    <img 
        src="<?= base_url('images/bgMain.png') ?>" 
        alt="Background" 
        class="h-[400px] absolute left-[30%] top-36 opacity-40 "
    >
</div>

<script>
    function toggleFullScreen() {
        const pdfContainer = document.getElementById("pdfContainer");
        const pdfEmbed = document.getElementById("pdfEmbed");

        if (!document.fullscreenElement) {
            pdfContainer.style.width = "100%";
            pdfContainer.style.height = "100%";
            pdfEmbed.style.width = "100%";
            pdfEmbed.style.height = "100%";

            pdfContainer.requestFullscreen().catch(err => {
                alert(`Error attempting to enable full-screen mode: ${err.message}`);
            });
        } else {
            document.exitFullscreen().then(() => {
                pdfContainer.style.width = "480px";  
                pdfContainer.style.height = "300px"; 
                pdfEmbed.style.width = "480px";     
                pdfEmbed.style.height = "300px";   
            });
        }
    }

    function showForm(materialId) {
        Swal.fire({
            html: `
                <div class="flex flex-col gap-5">
                    <p class="font-semibold text-3xl text-black">Add Assessments</p>
                    <form id="assessment-form" action="<?= base_url('instructor/assessment/create') ?>" method="POST" class="flex flex-col space-y-4 px-10">
                        <input type="hidden" name="material_id" value="${materialId}">
                        <div id="questions-container">
                            ${generateQuestionFields(1)} <!-- Start with the first question -->
                        </div>
                        <button type="button" id="add-question" class="w-full inline-flex justify-center rounded-full border border-transparent shadow-sm px-4 py-2 text-base bg-gray-800 text-white items-center">Add Question</button>
                    </form>
                </div>
            `,
            confirmButtonText: "Submit Assessments",
            customClass: {
                confirmButton: "w-[250px] inline-flex justify-center rounded-full border border-transparent shadow-sm px-4 py-2 text-base bg-[#1ED300] text-white",
            },
            buttonsStyling: false,
            preConfirm: () => {
                const form = document.getElementById('assessment-form');
                const formData = new FormData(form);
                return fetch(form.action, {
                    method: 'POST',
                    body: formData,
                }).then(response => {
                    if (!response.ok) {
                        return response.text().then(text => { throw new Error(text); });
                    }
                    return response.json();
                }).then(data => {
                    Swal.fire('Success', data.message, 'success').then(() => {
                        window.location.href = '/instructor/assessment';
                    });
                }).catch(error => {
                    Swal.showValidationMessage(`Request failed: ${error.message}`);
                });
            }
        });

            document.getElementById('add-question').addEventListener('click', function () {
                const questionsContainer = document.getElementById('questions-container');
                const questionCount = questionsContainer.querySelectorAll('.question-group').length + 1; // Increment question number
                questionsContainer.insertAdjacentHTML('beforeend', generateQuestionFields(questionCount));
            });
        }


    function generateQuestionFields(index) {
        return `
            <div class="question-group">
                <div class="flex flex-col gap-2 w-full">
                    <label class="font-semibold text-lg">Question ${index}</label>
                    <textarea name="question_text[${index}]" class="border border-black p-2 w-full" required></textarea>
                </div>
                <div class="flex flex-col gap-2 w-full">
                    <div class="flex flex-row gap-2 justify-center items-center">
                        <label class="font-semibold text-lg">Options</label>
                        <i class="fa-solid fa-plus try text-md cursor-pointer"></i>
                    </div>
                    <!-- New container for dynamically added options -->
                    <div class="options-container"></div>
                </div>
            </div>
        `;
    }

    document.addEventListener("DOMContentLoaded", function () {
        document.addEventListener("click", function (event) {
            if (event.target.classList.contains("try")) {
                const questionGroup = event.target.closest(".question-group");
                const optionsContainer = questionGroup.querySelector(".options-container");
                const questionIndex = questionGroup.querySelector("textarea").name.match(/\d+/)[0];

                // Count existing options
                const existingOptions = optionsContainer.querySelectorAll(".flex.items-center.gap-2").length;
                const newOptionIndex = existingOptions; // Zero-based index

                // Create new option HTML
                const newOptionHTML = `
                    <div class="flex items-center gap-2">
                        <input type="radio" name="correct_option[${questionIndex}]" value="${newOptionIndex}">
                        <input type="text" name="option[${questionIndex}][]" placeholder="Option ${newOptionIndex + 1}" class="border border-black p-2 w-full" required>
                    </div>
                `;

                // Append new option
                optionsContainer.insertAdjacentHTML("beforeend", newOptionHTML);
            }
        });
    });

    function editForm() {
        Swal.fire({
            title: 'Edit Form',
            text: 'This form is currently not available.',
            icon: 'info',
            confirmButtonText: 'OK'
        });
    }

    function deleteForm(materialId) {
        Swal.fire({
            title: 'Are you sure?',
            text: "Do you really want to delete the assessment questions for this material?",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#3085d6',
            confirmButtonText: 'Yes',
            cancelButtonText: 'No'
        }).then((result) => {
            if (result.isConfirmed) {
                fetch(`instructor/assessment/delete/${materialId}`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-Requested-With': 'XMLHttpRequest'
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 'success') {
                        Swal.fire({
                            title: 'Deleted!',
                            text: data.message,
                            icon: 'success'
                        }).then(() => {
                            // Redirect to a specific URL instead of reloading the page
                            window.location.href = 'instructor/assessment'; // Replace with your desired URL
                        });
                    } else {
                        Swal.fire({
                            title: 'Error!',
                            text: data.message,
                            icon: 'error'
                        });
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    Swal.fire({
                        title: 'Error!',
                        text: 'An error occurred while deleting questions.',
                        icon: 'error'
                    });
                });
            }
        });
    }

</script>

<?php $this->endSection(); ?>
