<?php

use App\Controllers\AdminController;
use App\Controllers\InstructorController;
use App\Controllers\StudentController;
use App\Controllers\GuestController;
use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'MainController::index');
$routes->get('/index', 'MainController::index');
$routes->get('/loginAs', 'MainController::loginAs');
$routes->get('/registerAs', 'MainController::registerAs');

// Logout
$routes->get('admin/logout', 'MainController::logout');
$routes->get('instructor/logout', 'MainController::logout');
$routes->get('student/logout', 'MainController::logout');
$routes->get('guest/logout', 'MainController::logout');

// Group routes for Admin
$routes->group('admin', function($routes) {
    $routes->get('register', 'AdminController::register');
    $routes->post('register', 'AdminController::storeAdmin');
    $routes->get('login', 'AdminController::login');
    $routes->post('login', 'AdminController::doLogin');
    $routes->get('account', 'AdminController::accountManagement');
    $routes->get('verification', 'AdminController::verify');
    $routes->post('verification', 'AdminController::doVerify');
    
    
    // RESTful-like routes for Instructor
    $routes->get('account/instructor/list', 'AdminController::allInstructor');
    $routes->get('account/instructor/add', 'AdminController::registerInstructor');
    $routes->post('account/instructor/add', 'InstructorController::storeInstructor');
    $routes->get('account/instructor/upload', 'AdminController::viewUploadInstructors');
    $routes->post('account/instructor/upload', 'AdminController::uploadInstructors');
    $routes->get('account/instructor/edit/(:num)', 'AdminController::editInstructor/$1');
    $routes->get('account/instructor/view/(:num)', 'AdminController::viewInstructor/$1');
    $routes->post('account/instructor/update/(:num)', 'AdminController::updateInstructor/$1');
    $routes->post('account/instructor/updateStatus/(:num)', 'AdminController::updateStatusInstructor/$1');
    $routes->post('account/instructor/delete/(:num)', 'AdminController::deleteInstructor/$1');

    // RESTful-like routes for Student
    $routes->get('account/student/list', 'AdminController::allStudent');
    $routes->get('account/student/add', 'AdminController::registerStudent');
    $routes->post('account/student/add', 'StudentController::storeStudent');
    $routes->get('account/student/upload', 'AdminController::viewUploadStudents');
    $routes->post('account/student/upload', 'AdminController::uploadStudents');
    $routes->get('account/student/edit/(:num)', 'AdminController::editStudent/$1');
    $routes->get('account/student/view/(:num)', 'AdminController::viewStudent/$1');
    $routes->post('account/student/update/(:num)', 'AdminController::updateStudent/$1');
    $routes->post('account/student/updateStatus/(:num)', 'AdminController::updateStatusStudent/$1');
    $routes->post('account/student/delete/(:num)', 'AdminController::deleteStudent/$1');

    // RESTful-like routes for Guest
    $routes->get('account/guest/list', 'AdminController::allGuest');
    $routes->get('account/guest/add', 'AdminController::registerGuest');
    $routes->post('account/guest/add', 'GuestController::storeGuest');
    $routes->get('account/guest/upload', 'AdminController::viewUploadGuests');
    $routes->post('account/guest/upload', 'AdminController::uploadGuests');
    $routes->get('account/guest/edit/(:num)', 'AdminController::editGuest/$1');
    $routes->get('account/guest/view/(:num)', 'AdminController::viewGuest/$1');
    $routes->post('account/guest/update/(:num)', 'AdminController::updateGuest/$1');
    $routes->post('account/guest/updateStatus/(:num)', 'AdminController::updateStatusGuest/$1');
    $routes->post('account/guest/delete/(:num)', 'AdminController::deleteGuest/$1');
});


// Group routes for Instructors
$routes->group('instructor', function($routes) {
    $routes->get('register', 'InstructorController::register');
    $routes->post('register', 'InstructorController::storeInstructor');
    $routes->get('login', 'InstructorController::login');
    $routes->post('login', 'InstructorController::doLogin');
    $routes->get('verification', 'InstructorController::verify');
    $routes->post('verification', 'InstructorController::doVerify');
    $routes->get('assessment', 'InstructorController::assessment');
    $routes->post('assessment/create', 'InstructorController::storeAssessment');
    $routes->post('assessment/delete/(:num)', 'InstructorController::deleteAssessment/$1');
});

// Group routes for Students
$routes->group('student', function($routes) {
    $routes->get('register', 'StudentController::register');
    $routes->post('register', 'StudentController::storeStudent');
    $routes->get('login', 'StudentController::login');
    $routes->post('login', 'StudentController::doLogin');
    $routes->get('verification', 'StudentController::verify');
    $routes->post('verification', 'StudentController::doVerify');
    $routes->get('virtual-drive', 'StudentController::virtual');
    $routes->get('virtual-drive/all', 'StudentController::virtualAll');
    $routes->post('virtual-drive/all/delete/(:num)', 'StudentController::deleteVirtual/$1');
    $routes->get('virtual-drive/view/(:num)', 'StudentController::viewVirtual/$1');
    $routes->get('virtual-drive/content/(:num)', 'StudentController::contentVirtual/$1');
    $routes->post('virtual-drive/content/', 'StudentController::addText');
    $routes->post('virtual-drive/content1/', 'StudentController::addImage');
    $routes->post('virtual-drive/content2/', 'StudentController::addVideo');
    $routes->get('library', 'StudentController::library');
    $routes->get('collaboration', 'StudentController::collab');
    $routes->post('library/delete/(:num)', 'StudentController::deleteLibrary/$1');
    $routes->get('collaboration/content/(:num)', 'StudentController::viewContent/$1');
    $routes->post('collaboration/content/', 'StudentController::addComment');
});

// Group routes for Guests
$routes->group('guest', function($routes) {
    $routes->get('register', 'GuestController::register');
    $routes->post('register', 'GuestController::storeGuest');
    $routes->get('login', 'GuestController::login');
    $routes->post('login', 'GuestController::doLogin');
    $routes->get('verification', 'GuestController::verify');
    $routes->post('verification', 'GuestController::doVerify');
   
});

// Main dashboard and course management
$routes->group('main', function($routes) {
    $routes->get('dashboard', 'MainController::dashboard');
    $routes->get('course', 'MainController::course');
    $routes->post('course', 'MainController::storeCourse');
    $routes->get('dashboard/view/(:num)', 'MainController::viewMaterialsDash/$1');
    $routes->get('profile', 'MainController::viewProfile');
    $routes->post('profile/update/(:num)', 'MainController::updateProfile/$1');
    // RESTful-like routes for course management
    $routes->get('course/edit/(:num)', 'MainController::editCourse/$1');
    $routes->get('course/view/(:num)', 'MainController::viewCourse/$1');
    $routes->post('course/update/(:num)', 'MainController::updateCourse/$1');
    $routes->post('course/delete/(:num)', 'MainController::deleteCourse/$1');

    $routes->get('materials', 'MainController::materials');
    $routes->post('materials', 'MainController::storeMaterials');
    $routes->post('materials/update/(:num)', 'MainController::updateStudents/$1');
    $routes->get('materials/search', 'MainController::search1');
    $routes->get('materials/searchFilter', 'MainController::searchFilter');
    // RESTful-like routes for instructional materials
    $routes->get('materials/edit/(:num)', 'MainController::editMaterials/$1');
    $routes->get('materials/view/(:num)', 'MainController::viewMaterials/$1');
    $routes->post('materials/updateStatus1/(:num)', 'MainController::updateMaterialsStatus1/$1');
    $routes->post('materials/updateStatus2/(:num)', 'MainController::updateMaterialsStatus2/$1');
    $routes->post('materials/updateCount/(:num)', 'MainController::updateMaterialsCount/$1');
    $routes->post('materials/update/(:num)', 'MainController::updateMaterials/$1');
    $routes->post('materials/delete/(:num)', 'MainController::deleteMaterials/$1');
    $routes->get('materials/content/(:num)', 'MainController::viewMaterialsContent/$1');
    $routes->post('materials/content', 'MainController::saveToLibrary');
    $routes->post('materials/content1', 'MainController::saveToVdrive');
    $routes->post('materials/assessment', 'MainController::storeAssessment');
    $routes->get('dashboard/search', 'MainController::search');
});

// Optional: Add middleware for authentication on certain routes
// $routes->group('admin', ['filter' => 'auth'], function($routes) {
//     // protected routes here
// });